(async()=>{const {JSDOM}=require('jsdom');const fs=require('fs');
const dom=new JSDOM(fs.readFileSync('/home/claude/rpg/labo-rpgmasters.html','utf8'),{url:'https://labo.test/',runScripts:'dangerously',pretendToBeVisual:true,beforeParse(w){w.Worker=undefined;}});
const w=dom.window;w.addEventListener('error',e=>console.log('ERR',e.message));
await new Promise(r=>setTimeout(r,2500));const $=s=>w.document.querySelector(s);
const d=JSON.parse(fs.readFileSync(process.argv[2]||'imp4/export.json','utf8'));for(const k of ['journal','turnLogs','texts'])delete d[k];
// simule des gains réels sur quelques combats
if(process.argv[3])d.fights.forEach((f,i)=>{if(i%2)f.xp=250000;if(f.ctx&&f.ctx.huntZone===806)f.items=(i%10?[]:['Coiffe d\'Hel Munster'])});
$('#importBox').value=JSON.stringify(d);$('#importBtn').click();await new Promise(r=>setTimeout(r,1500));
console.log($('#importMsg').textContent.slice(0,140));
$('#t-farm').click();await new Promise(r=>setTimeout(r,500));
console.log('KPI:',$('#fKpis').textContent.replace(/\s+/g,' '));
const rows=[...$('#fZones').querySelectorAll('tr')].slice(0,6).map(r=>[...r.children].map(c=>c.textContent.replace(/\s+/g,' ').trim()).join(' | '));console.log(rows.join('\n'));
const opt=$('#fItemList').options;console.log('objets dans la liste',opt.length);
$('#fItem').value=process.argv[4]||"Coiffe d'Hel Munster";$('#fItem').dispatchEvent(new w.Event('input'));await new Promise(r=>setTimeout(r,200));
console.log('RECHERCHE:',$('#fItemOut').textContent.replace(/\s+/g,' ').slice(0,700));
process.exit(0)})();
