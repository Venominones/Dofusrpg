(async()=>{const {JSDOM}=require('jsdom');const fs=require('fs');
const dom=new JSDOM(fs.readFileSync('/home/claude/rpg/labo-rpgmasters.html','utf8'),{url:'https://labo.test/',runScripts:'dangerously',pretendToBeVisual:true,beforeParse(w){w.Worker=undefined;}});
const w=dom.window;w.addEventListener('error',e=>console.log('ERR',e.message));
await new Promise(r=>setTimeout(r,3000));
const $=s=>w.document.querySelector(s);
const eff=$('#oEffort [data-v="1"]');if(eff)eff.click();
$('#oRun').click();
for(let i=0;i<600;i++){await new Promise(r=>setTimeout(r,500));if(!$('#oRun').disabled&&/Terminé|échoué/.test($('#oStatus').textContent))break}
await new Promise(r=>setTimeout(r,300));
console.log('opt marqués',[...$('#oPack').options].filter(o=>o.textContent.startsWith('✓')).map(o=>o.textContent.slice(0,50)),'|',$('#oReady').textContent);
const t=Date.now();$('#aDiff').dispatchEvent(new w.Event('change',{bubbles:true}));console.log('marquage asc',Date.now()-t,'ms, options',$('#aPack').options.length);
const t2=Date.now();$('#oDiff').dispatchEvent(new w.Event('change',{bubbles:true}));console.log('marquage opt',Date.now()-t2,'ms, options',$('#oPack').options.length);
// change effort -> plus marqué
const e2=$('#oEffort [data-v="2"]');if(e2)e2.click();await new Promise(r=>setTimeout(r,4000));console.log('après changement d effort, marqués',[...$('#oPack').options].filter(o=>o.textContent.startsWith('✓')).length);
process.exit(0)})();
