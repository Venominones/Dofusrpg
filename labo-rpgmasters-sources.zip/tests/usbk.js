const {JSDOM}=require('jsdom');const fs=require('fs');
const src=fs.readFileSync('/home/claude/rpg/labo-rpgmasters.user.js','utf8');
const dom=new JSDOM('<!doctype html><body></body>',{url:'https://rpgmasters.houk.fr/chasse',runScripts:'outside-only'});
const w=dom.window;w.localStorage.setItem('labo-profile','saison');let dl=null;w.URL.createObjectURL=b=>{dl=b;return 'blob:x'};w.URL.revokeObjectURL=()=>{};
const fights=[];for(let i=0;i<250;i++)fights.push({t:Date.now()-i*6000,kind:'pve',mons:['A#1'],status:'won',rounds:1,xp:10,kamas:1,items:[],card:null,ctx:{}});
w.localStorage.setItem('labo-rec-v1-saison',JSON.stringify({fights,monsters:{},seen:[],floors:{},bossLogs:[]}));
w.eval(src);
(async()=>{await new Promise(r=>setTimeout(r,300));const P=w.document.getElementById('labo-panel');
console.log('nag:',/Aucune sauvegarde/.test(P.textContent));
P.querySelector('[data-a="backup"]').click();await new Promise(r=>setTimeout(r,50));console.log('view:',P.textContent.replace(/\s+/g,' ').slice(0,120));
P.querySelector('[data-a="bkdl"]').click();await new Promise(r=>setTimeout(r,50));const txt=await new Promise(r=>{const fr=new w.FileReader();fr.onload=()=>r(fr.result);fr.readAsText(dl)});const b=JSON.parse(txt);console.log('fichier:',b.kind,Object.keys(b.data),P.querySelector('#labo-msg').textContent);
w.localStorage.removeItem('labo-rec-v1-saison');
// restore
const ev=P.querySelector('#labo-bkfile');Object.defineProperty(ev,'files',{value:[new w.File([txt],'s.json')]});ev.onchange();await new Promise(r=>setTimeout(r,200));
console.log('restauré:',P.querySelector('#labo-msg').textContent,JSON.parse(w.localStorage.getItem('labo-rec-v1-saison')).fights.length);
P.querySelector('[data-a="back"]').click();console.log('nag après:',/Aucune sauvegarde|Dernière sauvegarde il y a/.test(P.textContent));process.exit(0)})();
