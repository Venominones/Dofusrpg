const {JSDOM}=require('jsdom');const fs=require('fs');
const html=fs.readFileSync('/home/claude/rpg/labo.html','utf8');
const dom=new JSDOM('<!doctype html><html><head></head><body>'+html+'</body></html>',{runScripts:'dangerously',pretendToBeVisual:true});
const w=dom.window;w.addEventListener('error',e=>console.log('ERR',e.message));
setTimeout(()=>{
  const $=s=>w.document.querySelector(s);
  console.log('kpis',$('#charKpis').textContent.slice(0,200));
  console.log('stats',$('#charStats').textContent.slice(0,120));
  console.log('prec',$('#statPrecision').textContent);
  console.log('packs',[...$('#simPack').options].map(o=>o.textContent));
  console.log('decks',[...$('#simDeck').options].map(o=>o.textContent));
  setTimeout(()=>{console.log('sim',$('#simKpis').textContent);console.log('hist cols',$('#simHist').children.length,'cards',$('#simCards').children.length);
    // test renderOpt path without worker: run optimize directly via window.OPT
    process.exit(0)},3000);
},500);
