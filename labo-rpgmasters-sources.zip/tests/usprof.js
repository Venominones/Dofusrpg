const {JSDOM}=require('jsdom');const fs=require('fs');
const src=fs.readFileSync('/home/claude/rpg/labo-rpgmasters.user.js','utf8');
const dom=new JSDOM('<!doctype html><body></body>',{url:'https://rpgmasters.houk.fr/combat',runScripts:'outside-only'});
const w=dom.window;w.localStorage.setItem('labo-profile','saison');w.localStorage.setItem('labo-profile-lock','1');
w.fetch=async()=>({clone(){return{text:async()=>'0:{"x":1,"seasonChar":null}'}},headers:{get:()=> 'text/x-component'},text:async()=>''});
w.GM_info={};w.unsafeWindow=w;
try{w.eval(src)}catch(e){console.log('load err',e.message)}
(async()=>{await w.fetch('/x',{method:'POST'});await new Promise(r=>setTimeout(r,200));
console.log('profile',w.localStorage.getItem('labo-profile'),'lock',w.localStorage.getItem('labo-profile-lock'));
console.log((w.document.body.textContent.match(/Corrigé[^.]*\./)||['(pas de message affiché)'])[0]);process.exit(0)})();
