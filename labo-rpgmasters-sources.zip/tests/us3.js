const fs=require('fs');const src=fs.readFileSync('/home/claude/rpg/labo-rpgmasters.user.js','utf8');
const store={'labo-floor':'18'};global.localStorage={getItem:k=>store[k]??null,setItem:(k,v)=>store[k]=v,removeItem:k=>delete store[k]};
let fetchImpl=null;const appended=[];
const mkEl=()=>({setAttribute(){},addEventListener(){},remove(){},querySelector:()=>({textContent:''}),set innerHTML(v){this._h=v},get innerHTML(){return this._h},dataset:{}});
global.window={fetch:(...a)=>fetchImpl(...a)};global.navigator={};global.location={pathname:'/combat'};global.setInterval=()=>0;
global.document={readyState:'loading',addEventListener(){},createElement:mkEl,documentElement:{contains:()=>true,appendChild(e){appended.push(e)}}};
eval(src);
const B=(id,name)=>({id,kind:'monster',name,grade:1,maxHp:20000,atk:900,element:1,pattern:['attack'],stats:{},isBoss:true});
const st=(status,round,log)=>({screen:{onAscension:true},state:{kind:'pve',status,round,order:['p','m0','m1'],logCount:log.length,hint:status==='lost'?'Ce boss retourne tes soins contre toi à partir du tour 4.':null,fighters:{p:{kind:'player',hp:0,maxHp:4800,cards:{c0:{name:'Secourisme',eff:[{k:'healPct'}]},c1:{name:'Berserk',eff:[{k:'buff'}]}}},m0:B('m0','Shogun Tofugawa'),m1:B('m1','Grolloum')},log}});
const L=[{t:'round',round:1},{t:'turn',who:'p'},{t:'play',who:'p',card:'Berserk'},{t:'dmg',who:'p',v:300},{t:'round',round:4},{t:'turn',who:'p'},{t:'play',who:'p',card:'Secourisme'},{t:'dmg',who:'p',v:900},{t:'death',who:'m0'},{t:'round',round:5},{t:'turn',who:'p'},{t:'play',who:'p',card:'Secourisme'},{t:'dmg',who:'p',v:900}];
(async()=>{
 fetchImpl=async()=>({clone:()=>({text:async()=>'1:'+JSON.stringify(st('lost',5,L))+'\n'})});await window.fetch('/combat',{method:'POST'});await new Promise(r=>setTimeout(r,500));
 const db=window.LaboRec.db;for(const k of ['Shogun Tofugawa#1','Grolloum#1'])console.log(k,JSON.stringify(db.monsters[k].mech&&db.monsters[k].mech.parsed),db.monsters[k].mech&&db.monsters[k].mech.hints);
 console.log('floor',JSON.stringify(db.floors[18]));
 fetchImpl=async()=>({clone:()=>({text:async()=>'1:'+JSON.stringify(st('active',1,[]))+'\n'})});await window.fetch('/combat',{method:'POST'});
 const b=appended.find(e=>e._h&&e._h.includes('Labo ·')&&e._h.includes('étage'));console.log(b?b._h.replace(/<[^>]+>/g,' ').replace(/\s+/g,' ').slice(0,600):'NO BANNER');
})();
