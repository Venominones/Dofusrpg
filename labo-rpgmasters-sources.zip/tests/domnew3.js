(async()=>{const {JSDOM}=require('jsdom');const fs=require('fs');
const dom=new JSDOM(fs.readFileSync('/home/claude/rpg/labo-rpgmasters.html','utf8'),{url:'https://venominones.github.io/Dofusrpg/',runScripts:'dangerously',pretendToBeVisual:true,beforeParse(w){w.Worker=undefined;w.URL.createObjectURL=()=>'blob:x';w.URL.revokeObjectURL=()=>{};
 const s=JSON.parse(fs.readFileSync('/tmp/claude-0/imp8/export.json','utf8'));w.localStorage.setItem('labo-data-saison',JSON.stringify(s));w.localStorage.setItem('labo-lprofile','saison');}});
const w=dom.window;let errs=0;w.addEventListener('error',e=>{errs++;console.log('ERR',e.message)});
await new Promise(r=>setTimeout(r,2500));const $=s=>w.document.querySelector(s);
// import newer export -> diff
const t9=fs.readFileSync('/tmp/claude-0/imp10/full.json','utf8');w.eval('void 0');
$('#importBox').value=t9;$('#importBtn').click();await new Promise(r=>setTimeout(r,800));
$('#t-data').click();console.log('CHANGES',$('#changesOut').textContent.slice(0,500));
for(let i=0;i<240;i++){await new Promise(r=>setTimeout(r,500));if(!/Vérification/.test($('#healthOut').textContent)&&$('#healthOut').textContent!=='—')break}
console.log('HEALTH',$('#healthOut').textContent.slice(0,400));
console.log('PRED',[...w.document.querySelectorAll('#fPredict tr')].slice(0,8).map(r=>r.textContent).join('\n'),'\n',($('#fPredict p')||{}).textContent);
$('#t-items').click();await new Promise(r=>setTimeout(r,500));console.log('BANK',[...w.document.querySelectorAll('#bank2Out tr')].slice(1,6).map(r=>r.textContent).join('\n'));
$('#bkDl').click();console.log('BK',$('#bkMsg').textContent);
console.log('erreurs',errs);process.exit(0)})();
