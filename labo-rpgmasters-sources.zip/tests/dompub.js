(async()=>{const {JSDOM}=require('jsdom');const fs=require('fs');
const dom=new JSDOM(fs.readFileSync('/home/claude/rpg/site/index.html','utf8'),{url:'https://venominones.github.io/Dofusrpg/',runScripts:'dangerously',pretendToBeVisual:true,beforeParse(w){w.Worker=undefined;}});
const w=dom.window;let errs=0;w.addEventListener('error',e=>{errs++;console.log('ERR',e.message)});
await new Promise(r=>setTimeout(r,2500));const $=s=>w.document.querySelector(s);
console.log('bandeau exemple visible:',!$('#exampleBanner').hidden,'| lien installation visible:',!$('#installUserscript').hidden,$('#installUserscript').getAttribute('href'));
console.log('perso:',$('#charSub').textContent.slice(0,120));
for(const t of ['sim','opt','asc','best','farm','form','data']){$('#t-'+t).click();await new Promise(r=>setTimeout(r,200))}
console.log('farm:',$('#fZones').textContent.slice(0,120));
const e1=$('#oEffort [data-v="1"]');if(e1)e1.click();$('#t-opt').click();$('#oRun').click();
for(let i=0;i<120;i++){await new Promise(r=>setTimeout(r,500));if(!$('#oRun').disabled&&/Terminé|échoué|Coche/.test($('#oStatus').textContent))break}
console.log('opti:',$('#oStatus').textContent.slice(0,100),'| erreurs',errs);process.exit(0)})();
