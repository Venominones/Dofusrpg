import json,sys,itertools
a=json.load(open(sys.argv[1]));mons={m['name']+'#'+str(m['grade']):m for m in a['monsters']}
B=a['builds'];fights=a['fights']
RP=['resPctNeutre','resPctTerre','resPctFeu','resPctEau','resPctAir'];RF=['resNeutre','resTerre','resFeu','resEau','resAir']
IM={'attack':1,'heavy':1.7,'drain':0.8}
hits=[]
for j in a['journal']:
  f=min(fights,key=lambda x:abs(x['t']-j['t']));
  if abs(f['t']-j['t'])>5000: continue
  b=B.get(f.get('bsig'))
  if not b: continue
  S=b['stats'];cur=None;intent=None;glaces={}
  for e in j['ev']:
    if e[2]=='passive' and 'Glaces' in str(e[3]):
      nm=str(e[3]).split(': ')[1].split(' frappe')[0];glaces[nm]=e[0]+1
    if e[2]=='turn' and e[1]!='moi': cur=e[1]
    if e[2]=='turn' and e[1]=='moi': cur=None
    if e[2]=='intent': intent=e[3]
    if e[2]=='dmg' and e[1]=='moi' and cur and intent in IM and 'crit' not in e:
      ab=[x for x in e[5:] if isinstance(x,str) and x.startswith('abs')];tot=e[3]+(int(ab[0][3:]) if ab else 0)
      mk=[k for k in j['mons'] if k.startswith(cur+'#')];m=mons.get(mk[0]) if mk else None
      if not m or m.get('isBoss'): continue
      el=int(e[4][2:]);g=glaces.get(cur,-1)>=e[0]
      hits.append(dict(S=S,atk=m['atk'],int=intent,el=el,obs=tot,g=g,name=cur,rage=0))
print(len(hits),'coups')
def pred(h,mode,hm,gl):
  S=h['S'];mel=S.get('resPctMelee',0);dist=S.get('resPctDistance',0)
  red={'sum':min(50,mel+dist),'dist':dist,'mel':mel,'none':0,'max':max(mel,dist)}[mode]/100
  rp=min(50,S.get(RP[h['el']],0))/100;rf=S.get(RF[h['el']],0)
  mult={'attack':1,'heavy':hm,'drain':0.8}[h['int']]*(0.9 if (gl and h['g']) else 1)
  return mult,red,rp,rf
for mode in ['sum','dist','mel','none','max']:
 for order in ['fix_first','fix_last']:
  for hm in [1.65,1.7]:
   for gl in [0,1]:
    err=[]
    for h in hits:
      mult,red,rp,rf=pred(h,mode,hm,gl)
      p=(h['atk']*mult*(1-red)-rf)*(1-rp) if order=='fix_first' else h['atk']*mult*(1-red)*(1-rp)-rf
      err.append(abs(p-h['obs'])/max(1,h['obs']))
    print(f'{mode:5} {order:9} heavy{hm} glaces{gl}  erreur {100*sum(err)/len(err):5.1f}%')
