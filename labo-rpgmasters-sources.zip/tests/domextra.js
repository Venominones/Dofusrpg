(async()=>{const {JSDOM}=require('jsdom');const fs=require('fs');
const dom=new JSDOM(fs.readFileSync('/home/claude/rpg/labo-rpgmasters.html','utf8'),{url:'https://venominones.github.io/Dofusrpg/',runScripts:'dangerously',pretendToBeVisual:true,beforeParse(w){w.Worker=undefined;w.localStorage.setItem('labo-data-saison',fs.readFileSync('/tmp/claude-0/imp9/export.json','utf8'));w.localStorage.setItem('labo-lprofile','saison')}});
const w=dom.window;let errs=0;w.addEventListener('error',e=>{errs++;console.log('ERR',e.message)});await new Promise(r=>setTimeout(r,2500));const $=s=>w.document.querySelector(s);
$('#t-best').click();w.document.querySelector('#bView [data-v="extra"]').click();await new Promise(r=>setTimeout(r,300));
console.log($('#bOut p').textContent.slice(0,80));console.log([...w.document.querySelectorAll('#bOut tr')].slice(0,7).map(r=>r.textContent.slice(0,160)).join('\n'));
$('#bxQ').value='dofus';$('#bxQ').dispatchEvent(new w.Event('input'));console.log('filtre dofus:',w.document.querySelectorAll('#bOut tr').length-1);console.log(($('#bOut h3')||{}).textContent,'erreurs',errs);process.exit(0)})();
