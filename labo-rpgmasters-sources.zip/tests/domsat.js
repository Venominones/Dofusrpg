(async()=>{const {JSDOM}=require('jsdom');const fs=require('fs');
const dom=new JSDOM(fs.readFileSync('/home/claude/rpg/labo-rpgmasters.html','utf8'),{url:'https://venominones.github.io/Dofusrpg/',runScripts:'dangerously',pretendToBeVisual:true,beforeParse(w){w.Worker=undefined;w.localStorage.setItem('labo-data-saison',fs.readFileSync('/tmp/claude-0/imp10/full.json','utf8'));w.localStorage.setItem('labo-lprofile','saison')}});
const w=dom.window;let errs=0;w.addEventListener('error',e=>{errs++;console.log('ERR',e.message)});await new Promise(r=>setTimeout(r,2500));const $=s=>w.document.querySelector(s);
$('#t-opt').click();const e1=$('#oEffort [data-v="1"]');if(e1)e1.click();$('#oRun').click();
for(let i=0;i<200;i++){await new Promise(r=>setTimeout(r,500));if(!$('#oRun').disabled&&$('#oStatus').textContent.length>5&&!/Démarrage|essais \d/.test($('#oStatus').textContent))break}
console.log('1',$('#oDetails').textContent.slice(0,160),'| bouton',!!$('#oForce'));
if($('#oForce')){$('#oForce').click();for(let i=0;i<400;i++){await new Promise(r=>setTimeout(r,500));if(!$('#oRun').disabled&&/Terminé/.test($('#oStatus').textContent))break}
console.log('2',$('#oStatus').textContent.slice(0,120),'|',$('#oKpis')?$('#oKpis').textContent.slice(0,160):'',[...w.document.querySelectorAll('#oDetails h3')].map(h=>h.textContent).join(' / '))}
console.log('erreurs',errs);process.exit(0)})();
