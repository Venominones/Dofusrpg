(async()=>{const {JSDOM}=require('jsdom');const fs=require('fs');
const dom=new JSDOM(fs.readFileSync('/home/claude/rpg/labo-rpgmasters.html','utf8'),{url:'https://labo.test/',runScripts:'dangerously',pretendToBeVisual:true,beforeParse(w){w.Worker=undefined;}});
const w=dom.window;w.addEventListener('error',e=>console.log('ERR',e.message));
await new Promise(r=>setTimeout(r,2500));const $=s=>w.document.querySelector(s);
for(const f of ['imp5/export.json','imp6/export.json']){const d=JSON.parse(fs.readFileSync(f,'utf8'));for(const k of ['journal','turnLogs','texts','bestiary'])if(f.includes('imp6')&&k==='bestiary')continue;else delete d[k];
$('#importBox').value=JSON.stringify(d);$('#importBtn').click();await new Promise(r=>setTimeout(r,1500));console.log($('#importMsg').textContent.slice(0,90));}
console.log('hidden',$('#bankWrap').hidden);console.log($('#bankNote').textContent.slice(0,300));
const rows=[...$('#bankOut').querySelectorAll('tr')].slice(0,24).map(r=>[...r.children].map(c=>c.textContent.trim()).join(' | '));console.log(rows.join('\n'));
process.exit(0)})();
