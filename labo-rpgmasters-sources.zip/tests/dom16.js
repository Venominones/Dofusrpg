(async()=>{const {JSDOM}=require('jsdom');const fs=require('fs');
const base=JSON.parse(fs.readFileSync('/home/claude/rpg/data.json','utf8'));const exp=JSON.parse(fs.readFileSync('imp/export.json','utf8'));base.bestiary=exp.bestiary;
const dom=new JSDOM(fs.readFileSync('/home/claude/rpg/labo-rpgmasters.html','utf8'),{url:'https://labo.test/',runScripts:'dangerously',pretendToBeVisual:true,beforeParse(w){w.localStorage.setItem('labo-data',JSON.stringify(base))}});
const w=dom.window;w.addEventListener('error',e=>console.log('ERR',e.message));
await new Promise(r=>setTimeout(r,2500));const $=s=>w.document.querySelector(s);
$('#oTarget').checked=true;$('#oRun').click();let t0=Date.now();while($('#oRun').disabled&&Date.now()-t0<580000)await new Promise(r=>setTimeout(r,2000));
const t=$('#oDetails').textContent.replace(/\s+/g,' ');const i=t.indexOf('À farmer');console.log(((Date.now()-t0)/1000|0)+'s',$('#oStatus').textContent);console.log(t.slice(0,500));console.log('FARM:',i>=0?t.slice(i,i+500):'none');const j=t.indexOf('Trois builds');console.log('CHOICES:',j>=0?t.slice(j,j+500):'none');process.exit(0)})();
