(async()=>{const {JSDOM}=require('jsdom');const fs=require('fs');
const dom=new JSDOM(fs.readFileSync('/home/claude/rpg/labo-rpgmasters.html','utf8'),{url:'https://labo.test/',runScripts:'dangerously',pretendToBeVisual:true,beforeParse(w){w.Worker=undefined;}});
const w=dom.window;w.addEventListener('error',e=>console.log('ERR',e.message));
await new Promise(r=>setTimeout(r,2500));const $=s=>w.document.querySelector(s);
const d=JSON.parse(fs.readFileSync(process.argv[2],'utf8'));delete d.turnLogs;delete d.texts;
$('#importBox').value=JSON.stringify(d);$('#importBtn').click();await new Promise(r=>setTimeout(r,1500));
console.log($('#importMsg').textContent.slice(0,120));
const rows=[...$('#cardUse').querySelectorAll('tr')].map(r=>[...r.children].map(c=>c.textContent.trim()).join(' | '));console.log(rows.join('\n'));console.log($('#cardUse').querySelector('.note')?.textContent);
console.log('FREE:',$('#freePts').textContent.replace(/\s+/g,' ').slice(0,200));
const b=$('#freeRun');if(b){const t=Date.now();b.click();for(let i=0;i<120;i++){await new Promise(r=>setTimeout(r,500));if(!/Calcul…/.test($('#freeOut').textContent))break}console.log('plan',((Date.now()-t)/1000).toFixed(1)+'s',$('#freeOut').textContent.replace(/\s+/g,' '))}
process.exit(0)})();
