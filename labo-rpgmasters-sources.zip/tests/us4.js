const fs=require('fs');const src=fs.readFileSync('/home/claude/rpg/labo-rpgmasters.user.js','utf8');
const store={};global.localStorage={getItem:k=>store[k]??null,setItem:(k,v)=>store[k]=v,removeItem:k=>delete store[k]};
let fetchImpl=null;const mkEl=()=>({setAttribute(){},addEventListener(){},remove(){},querySelector:()=>({textContent:''}),set innerHTML(v){this._h=v},get innerHTML(){return this._h},dataset:{}});
global.window={fetch:(...a)=>fetchImpl(...a)};global.navigator={};global.location={pathname:'/combat'};global.setInterval=()=>0;
global.document={readyState:'loading',addEventListener(){},createElement:mkEl,documentElement:{contains:()=>true,appendChild(){}}};
eval(src);
const cards={c0:{name:'Bluff',ap:3},c1:{name:'Berserk',ap:2},c2:{name:'Vertu',ap:2}};
const mk=(status,round,hand,played,cur,log,extra)=>({state:Object.assign({kind:'boss',ascension:true,auto:true,autoUsed:true,status,round,currentId:cur,logCount:log.length,fighters:{p:{kind:'player',hp:4000,maxHp:4800,ap:11,cards,hand,played,cardsThisTurn:played.length},b0:{id:'b0',kind:'monster',name:'Toxoliath',grade:1,maxHp:90000,hp:50000,alive:true,atk:900,element:1,pattern:['attack'],stats:{},isBoss:true}},log},extra||{})});
const send=async o=>{fetchImpl=async()=>({clone:()=>({text:async()=>'1:'+JSON.stringify(o)+'\n'})});await window.fetch('/combat',{method:'POST'});await new Promise(r=>setTimeout(r,50))};
(async()=>{
 await send(mk('ongoing',1,['c0','c1','c2'],[],'p',[]));
 await send(mk('won',1,['c2'],['c1','c0'],'p',[{t:'round',round:1},{t:'play',who:'p',card:'Berserk'},{t:'play',who:'p',card:'Bluff'}]));
 const db=window.LaboRec.db;console.log(JSON.stringify(db.turnLogs));console.log(JSON.stringify(db.fights.map(f=>({auto:f.auto,autoTurns:f.autoTurns,floor:f.floor}))));
})();
