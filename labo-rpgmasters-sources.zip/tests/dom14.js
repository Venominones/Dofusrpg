(async()=>{const {JSDOM}=require('jsdom');const fs=require('fs');
const dom=new JSDOM(fs.readFileSync('/home/claude/rpg/labo-rpgmasters.html','utf8'),{url:'https://labo.test/',runScripts:'dangerously',pretendToBeVisual:true});
const w=dom.window;w.addEventListener('error',e=>console.log('ERR',e.message));
await new Promise(r=>setTimeout(r,2500));const $=s=>w.document.querySelector(s);
w.document.querySelector('#aEffort [data-v="1"]').click();
for(const st of ['ascension-burst']){w.document.querySelector(`#aStyle [data-v="${st}"]`).click();$('#aRun').click();let t0=Date.now();while($('#aRun').disabled&&Date.now()-t0<400000)await new Promise(r=>setTimeout(r,500));
const t=$('#aResult').textContent.replace(/\s+/g,' ');console.log(st,'|',$('#aStyleNote').textContent.slice(0,30),'|',t.slice(0,140),'| PTS',(t.match(/Points de caractéristiques(.{0,80})/)||[])[1])}
process.exit(0)})();
