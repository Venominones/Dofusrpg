const {JSDOM}=require('jsdom');const fs=require('fs');
const html=fs.readFileSync('/home/claude/rpg/labo-rpgmasters.html','utf8');
const dom=new JSDOM(html,{runScripts:'dangerously',pretendToBeVisual:true,url:'file:///C:/labo.html'});
const w=dom.window;w.addEventListener('error',e=>console.log('ERR',e.message));
setTimeout(()=>{const $=s=>w.document.querySelector(s);
 const vis=()=>[...w.document.querySelectorAll('section.tab')].map(s=>s.id+':'+(s.hidden?'off':'ON')).join(' ');
 console.log(vis());$('#t-opt').click();console.log(vis(), 'display', w.getComputedStyle($('#perso')).display);
 const sel=$('#oObj');sel.value='ascension';sel.dispatchEvent(new w.Event('change'));console.log('diff',$('#oDiff').value,$('#oObjNote').textContent.slice(0,60));
 console.log('sim',$('#simKpis').textContent.slice(0,80));process.exit(0)},3500);
