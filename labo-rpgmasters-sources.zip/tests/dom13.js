(async()=>{const {JSDOM}=require('jsdom');const fs=require('fs');
const dom=new JSDOM(fs.readFileSync('/home/claude/rpg/labo-rpgmasters.html','utf8'),{url:'https://labo.test/',runScripts:'dangerously',pretendToBeVisual:true});
const w=dom.window;w.addEventListener('error',e=>console.log('ERR',e.message));
await new Promise(r=>setTimeout(r,2500));const $=s=>w.document.querySelector(s);
console.log('opt:',$('#aPack').selectedOptions[0].textContent,'|',$('#aFloorNote').textContent);console.log('MECH:',$('#aMech').textContent.slice(0,260));
w.document.querySelector('#aEffort [data-v="1"]').click();$('#aRun').click();let t0=Date.now();while($('#aRun').disabled&&Date.now()-t0<400000)await new Promise(r=>setTimeout(r,500));
console.log('RES:',$('#aStatus').textContent,'|',$('#aResult').textContent.replace(/\s+/g,' ').slice(0,600));process.exit(0)})();
