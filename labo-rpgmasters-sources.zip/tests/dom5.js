const {JSDOM}=require('jsdom');const fs=require('fs');
const dom=new JSDOM(fs.readFileSync('/home/claude/rpg/labo-rpgmasters.html','utf8'),{runScripts:'dangerously',pretendToBeVisual:true});
const w=dom.window;w.addEventListener('error',e=>console.log('ERR',e.message,e.filename,e.lineno));
setTimeout(()=>{const $=s=>w.document.querySelector(s);
 console.log('packs',[...$('#aPack').options].map(o=>o.textContent).slice(0,3));
 console.log('boss',$('#aBoss').textContent.slice(0,120));console.log('note',$('#aAscNote').textContent.slice(0,80));
 w.document.querySelector('#aEffort [data-v="1"]').click();$('#aDiff').value=2;$('#aRun').click();
 const iv=setInterval(()=>{if(!$('#aRun').disabled){clearInterval(iv);console.log($('#aStatus').textContent);console.log($('#aResult').textContent.replace(/\s+/g,' ').slice(0,500));$('#aSave').click();console.log('builds',$('#aBuilds').textContent.slice(0,200));process.exit(0)}},500);
},3000);
