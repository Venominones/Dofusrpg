(async()=>{const {JSDOM}=require('jsdom');const fs=require('fs');
const dom=new JSDOM(fs.readFileSync('/home/claude/rpg/labo-rpgmasters.html','utf8'),{url:'https://venominones.github.io/Dofusrpg/',runScripts:'dangerously',pretendToBeVisual:true,beforeParse(w){w.Worker=undefined;}});
const w=dom.window;let errs=0;w.addEventListener('error',e=>{errs++;console.log('ERR',e.message)});await new Promise(r=>setTimeout(r,2500));const $=s=>w.document.querySelector(s);
const k=()=>[...w.document.querySelectorAll('#charKpis .kpi')].slice(0,4).map(x=>x.textContent).join(' | ');
console.log('avant',k(),'|',$('#compInfo').textContent);$('#compPct').value='50';$('#compPct').dispatchEvent(new w.Event('change'));await new Promise(r=>setTimeout(r,300));
console.log('après',k(),'|',$('#compInfo').textContent,'erreurs',errs);process.exit(0)})();
