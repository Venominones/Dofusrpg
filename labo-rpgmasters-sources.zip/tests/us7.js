const fs=require('fs');const src=fs.readFileSync('/home/claude/rpg/labo-rpgmasters.user.js','utf8');
const store={};global.localStorage={getItem:k=>store[k]??null,setItem:(k,v)=>store[k]=String(v),removeItem:k=>delete store[k]};
const mkEl=()=>({setAttribute(){},addEventListener(){},remove(){},querySelector:()=>({textContent:''}),querySelectorAll:()=>[],set innerHTML(v){this._h=v},get innerHTML(){return this._h},dataset:{}});
let payload='';global.window={fetch:async()=>({clone:()=>({text:async()=>payload})})};global.navigator={};global.location={pathname:'/combat'};global.setInterval=()=>0;
global.document={readyState:'loading',addEventListener(){},createElement:mkEl,documentElement:{contains:()=>true,appendChild(){}}};
eval(src);
const fight=(n)=>'1:'+JSON.stringify({state:{kind:'pve',status:'won',round:2,logCount:n,fighters:{p:{kind:'player',hp:100,maxHp:100,hand:[],played:[],cards:{}},m0:{id:'m0',kind:'monster',name:'Bouftou',grade:1,maxHp:50+n,atk:5,element:1,pattern:['attack'],stats:{}}},log:[]}})+'\n';
(async()=>{
payload='0:{"seasonChar":false}\n'+fight(1);await window.fetch('/x',{method:'POST'});await new Promise(r=>setTimeout(r,1700));
payload='0:{"seasonChar":{"id":"abc","level":3}}\n'+fight(2);await window.fetch('/x',{method:'POST'});await new Promise(r=>setTimeout(r,1700));
const a=JSON.parse(store['labo-rec-v1']||'{}'),b=JSON.parse(store['labo-rec-v1-saison']||'{}');console.log('profile',store['labo-profile'],'main fights',(a.fights||[]).length,'saison fights',(b.fights||[]).length);process.exit(0)})();
