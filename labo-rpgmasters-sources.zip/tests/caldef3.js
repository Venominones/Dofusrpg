const R=require("/home/claude/rpg/engine.js");const d=require(process.argv[2]);const MODE=process.env.MODE||'';
const byName={};for(const c of d.cards)byName[c.n]=c;const items=(d.items||[]).concat(d.worn||[]);
const mons={};for(const m of d.monsters)mons[m.name+'#'+m.grade]=m;const B=d.builds;const dofus=(d.worn||[]).filter(w=>w.s==='dofus').map(w=>w.n);
const g={};
for(const f of d.fights){if(f.kind==='boss')continue;const b=B[f.bsig];if(!b)continue;const defs=f.mons.map(x=>mons[x]);if(defs.some(x=>!x))continue;
 const S=R.deriveStats(b.stats,{maxHp:f.maxHp||b.maxHp,basePa:b.basePa,breedId:d.meta.breedId,dofus});
 const red0=S._red;if(MODE==='nored')S._red=0;if(MODE==='dist')S._red=Math.min(50,S.resPctDistance||0);
 const deck=b.deck.map(n=>byName[n]).filter(Boolean).map((c,i)=>R.prepCard(c,'c'+i));const wi=b.weapon&&items.find(i=>i.n===b.weapon&&i.w);
 const r=R.runMany({S,deck,weapon:wi?R.weaponCard(wi,wi.f||0):null,monsters:defs,level:d.meta.level,auto:f.auto!==false,seed:5},150);
 const k=red0>0?'red'+red0:'red0';const o=g[k]=g[k]||{n:0,obsD:0,simD:0,hit:0,simHit:0};o.n++;o.obsD+=f.dmgTaken||0;o.simD+=r.avgHpLost;}
for(const [k,o] of Object.entries(g))console.log(MODE||'actuel',k,o.n,'combats · PV perdus réel',(o.obsD/o.n).toFixed(0),'simulé',(o.simD/o.n).toFixed(0));
