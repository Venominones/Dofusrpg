const R=require("/home/claude/rpg/engine.js");const d=require(process.argv[2]);
const byName={};for(const c of d.cards)byName[c.n]=c;const items=(d.items||[]).concat(d.worn||[]);
const mons={};for(const m of d.monsters)mons[m.name+'#'+m.grade]=m;const B=d.builds;const dofus=(d.worn||[]).filter(w=>w.s==='dofus').map(w=>w.n);
let n=0,obs=0,hits=0,raw=0,lost=0,r1=0,obsR=0,simR=0;
for(const f of d.fights){if(f.kind==='boss')continue;const b=B[f.bsig];if(!b)continue;const defs=f.mons.map(x=>mons[x]);if(defs.some(x=>!x))continue;
 const S=R.deriveStats(b.stats,{maxHp:b.maxHp,basePa:b.basePa,breedId:d.meta.breedId,dofus});
 const deck=b.deck.map(n=>byName[n]).filter(Boolean).map((c,i)=>R.prepCard(c,'c'+i));const wi=b.weapon&&items.find(i=>i.n===b.weapon&&i.w);
 const K=100;const mlog={};let hl=0,rr=0;for(let k=0;k<K;k++){const r=R.simulateFight({S,deck,weapon:wi?R.weaponCard(wi,wi.f||0):null,monsters:defs,level:d.meta.level,auto:f.auto!==false,mlog});hl+=r.hpLost;rr+=r.rounds}
 n++;obs+=f.dmgTaken;hits+=(mlog.hits||0)/K;raw+=(mlog.raw||0)/K;lost+=hl/K;r1+=(mlog.r1||0)/K;obsR+=f.rounds;simR+=rr/K}
console.log('combats',n,'tours réel',(obsR/n).toFixed(2),'sim',(simR/n).toFixed(2));
console.log('PV perdus réel',(obs/n).toFixed(0),'| sim : coups reçus',(hits/n).toFixed(2),'dont tour 1',(r1/n).toFixed(2),'dégâts avant boucliers',(raw/n).toFixed(0),'PV perdus',(lost/n).toFixed(0));
const cards=Object.values(B).slice(-1)[0].deck.map(n=>byName[n]).filter(Boolean);console.log(cards.filter(c=>c.eff.some(l=>/shield|heal/.test(l.k))).map(c=>c.n+':'+JSON.stringify(c.eff.filter(l=>/shield|heal/.test(l.k)))).join('\n'));
