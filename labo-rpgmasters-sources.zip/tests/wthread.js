const {parentPort}=require('worker_threads');const fs=require('fs');
global.self={postMessage:m=>parentPort.postMessage(m)};
const engineSrc=fs.readFileSync('/home/claude/rpg/engine.js','utf8'),optSrc=fs.readFileSync('/home/claude/rpg/optimizer.js','utf8');
// même environnement qu'un Web Worker : pas de module.exports
(new Function('self',engineSrc.replace("typeof self !== 'undefined' ? self : this","self")))(global.self);
global.RPG=self.RPG;(new Function('self','RPG',optSrc.replace("typeof self !== 'undefined' ? self : this","self")))(global.self,self.RPG);
global.OPT=self.OPT;
eval(fs.readFileSync('/tmp/claude-0/whandler.js','utf8'));
parentPort.on('message',d=>self.onmessage({data:d}));
