(async()=>{const {JSDOM}=require('jsdom');const fs=require('fs');
const base=JSON.parse(fs.readFileSync('/home/claude/rpg/data.json','utf8'));
const m0=base.monsters[0];
const mk=(n,mech)=>Object.assign({},m0,{name:n,grade:1,isBoss:true,hpMin:m0.hpMin*6,hpMax:m0.hpMax*6,atk:m0.atk*2,mech});
const mons=[mk('Shogun Tofugawa',{sealCard:true,sealCardFrom:1,texts:['Shogun scelle Pluie pour ce tour']}),mk('Sphincter Cell',{apSteal:1,apStealFrom:1}),mk('Grolloum',{revive:true,invertFrom:2,hints:['à partir du tour 2, vos soins vous blessaient au lieu de vous soigner.']})];
const d=Object.assign({},base,{monsters:base.monsters.concat(mons),
 fights:[{kind:'boss',status:'lost',rounds:11,mons:['Shogun Tofugawa#1','Sphincter Cell#1','Grolloum#1'],ctx:{}},{kind:'boss',status:'won',rounds:15,floor:18,mons:['Shogun Tofugawa#1','Sphincter Cell#1','Grolloum#1'],ctx:{onAscension:true,floor:18}}],
 floors:[{floor:18,bosses:['Shogun Tofugawa','Sphincter Cell','Grolloum'],attempts:2,wins:1,hints:[]},{floor:19,bosses:['Minotot','Gorgouille Gloutonne','Père Ver'],attempts:0,wins:0,hints:[]}]});
const f='labo-rpgmasters.html';
const dom=new JSDOM(fs.readFileSync('/home/claude/rpg/'+f,'utf8'),{url:'https://labo.test/',runScripts:'dangerously',pretendToBeVisual:true,beforeParse(w){w.localStorage.setItem('labo-data',JSON.stringify(d))}});
const w=dom.window;w.addEventListener('error',e=>console.log('ERR',e.message));
await new Promise(r=>setTimeout(r,3000));const $=s=>w.document.querySelector(s);
console.log([...$('#aPack').options].map(o=>(o.disabled?'[x] ':'')+o.value+' => '+o.textContent).join('\n'));
console.log('note:',$('#aAscNote').textContent);console.log('mech:',$('#aMech').textContent);
$('#aAll').checked=true;$('#aAll').dispatchEvent(new w.Event('change'));console.log('with all:',$('#aPack').options.length, $('#aPack').value);
$('#aAll').checked=false;$('#aAll').dispatchEvent(new w.Event('change'));
w.document.querySelector('#aEffort [data-v="1"]').click();$('#aRun').click();
const t0=Date.now();while($('#aRun').disabled&&Date.now()-t0<240000)await new Promise(r=>setTimeout(r,500));
console.log($('#aStatus').textContent);console.log($('#aResult').textContent.slice(0,600));
process.exit(0);})();
