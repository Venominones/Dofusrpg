const {JSDOM}=require('jsdom');const fs=require('fs');const d=require('./imp6/export.json');
const src=fs.readFileSync('/home/claude/rpg/labo-rpgmasters.user.js','utf8');
const page=props=>{const rows=props.map((p,i)=>(i+1)+':'+JSON.stringify(['$','div',null,p])).join('\n')+'\n';return '<html><script>self.__next_f.push([1,'+JSON.stringify(rows)+'])</script></html>'};
const it=x=>({id:x.id,n:x.n,lvl:x.lvl,s:x.s,r:x.r,setId:x.setId,st:x.st,w:x.w});
const pages={
 '/inventaire':page([{entries:d.items.map(x=>({item:it(x),fusion:x.f||0,qty:x.q||1})),slots:d.worn.map(x=>({slot:x.slot,item:it(x),fusion:x.f||0})),level:d.meta.level,scrollValues:d.meta.scrolls,sets:d.setsList}]),
 '/deck':page([{collection:d.cards.map(c=>({key:c.key,card:c})),initialDecks:d.meta.decks,initialActive:d.meta.active,breedId:d.meta.breedId,deckSize:d.meta.deckSize,initialNames:d.meta.deckNames}]),
 '/personnage':page([{rows:d.meta.rows,pointsFree:d.meta.pointsFree},{prestige:d.meta.prestige,level:d.meta.level,equipped:[]}]),
 '/forgemagie':page([{orbs:0,level:d.meta.forge.level,xp:d.meta.forge.xp}])};
const dom=new JSDOM('<!doctype html><body></body>',{url:'https://rpgmasters.houk.fr/inventaire',runScripts:'outside-only',pretendToBeVisual:true});
const w=dom.window;w.localStorage.setItem('labo-profile','saison');
const mons={};for(const m of d.monsters)mons[m.name+'#'+m.grade]=m;
w.localStorage.setItem('labo-rec-v1-saison',JSON.stringify({monsters:mons,fights:d.fights.slice(-80).map(f=>({t:f.t,status:f.status,mons:f.mons,kind:f.kind,boss:f.boss,items:[]})),seen:[],floors:{},bossSamples:{},bossLogs:[]}));
w.localStorage.setItem('labo-dofus-sets-v1',JSON.stringify(d.dofusSets||{}));w.localStorage.setItem('labo-sets-v1',JSON.stringify(d.setBonus||{}));
w.fetch=async(u)=>{const p=Object.keys(pages).find(k=>String(u).startsWith(k));const t=p?pages[p]:'';return {text:async()=>t,json:async()=>({}),clone(){return{text:async()=>''}},headers:{get:()=>'text/html'}}};
w.eval(src);
(async()=>{await new Promise(r=>setTimeout(r,300));const q=s=>w.document.querySelector(s);
const click=a=>{const b=w.document.querySelector(`[data-a="${a}"]`);b.dispatchEvent(new w.MouseEvent('click',{bubbles:true}))};
click('compare');await new Promise(r=>setTimeout(r,100));click('cmprun');const t=Date.now();
for(let i=0;i<60;i++){await new Promise(r=>setTimeout(r,500));if(i%10==0){const pp=[...w.document.querySelectorAll("div")].find(x=>/Comparer mon inventaire/.test(x.textContent||""));console.log(i,pp?pp.textContent.replace(/\s+/g," ").slice(0,200):"-")}const tx=w.document.body.textContent;if(/Relancer|impossible/.test(tx))break}
const p=[...w.document.querySelectorAll('div')].find(x=>/Comparer mon inventaire/.test(x.textContent||'')&&x.querySelector('[data-a="back"]'));
console.log(((Date.now()-t)/1000).toFixed(1)+'s');console.log(p?p.textContent.replace(/\s+/g,' ').slice(0,1500):w.document.body.textContent.slice(0,800));process.exit(0)})();
