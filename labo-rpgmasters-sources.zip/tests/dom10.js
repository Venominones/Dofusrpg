(async()=>{const {JSDOM}=require('jsdom');const fs=require('fs');
const dom=new JSDOM(fs.readFileSync('/home/claude/rpg/labo-rpgmasters.html','utf8'),{url:'https://labo.test/',runScripts:'dangerously',pretendToBeVisual:true});
const w=dom.window;w.addEventListener('error',e=>console.log('ERR',e.message));
await new Promise(r=>setTimeout(r,2000));const $=s=>w.document.querySelector(s);
w.console.error=(...a)=>console.log('CE',...a);
$('#importBox').value=fs.readFileSync('imp/export.json','utf8');
try{$('#importBtn').click()}catch(e){console.log('X',e.stack)}
await new Promise(r=>setTimeout(r,1500));console.log($('#importMsg').textContent);console.log($('#fresh').textContent);process.exit(0)})();
