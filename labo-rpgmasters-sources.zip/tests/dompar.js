(async()=>{const {JSDOM}=require('jsdom');const fs=require('fs');const WT=require('worker_threads');
class FakeWorker{constructor(){this.t=new WT.Worker('/tmp/claude-0/wthread.js');this.t.on('message',m=>this.onmessage&&this.onmessage({data:m}));this.t.on('error',e=>this.onerror&&this.onerror({message:e.message}))}postMessage(m){this.t.postMessage(JSON.parse(JSON.stringify(m)))}terminate(){this.t.terminate()}}
const dom=new JSDOM(fs.readFileSync('/home/claude/rpg/labo-rpgmasters.html','utf8'),{url:'https://labo.test/',runScripts:'dangerously',pretendToBeVisual:true,beforeParse(w){w.Worker=FakeWorker;w.URL.createObjectURL=()=>'blob:fake';Object.defineProperty(w.navigator,'hardwareConcurrency',{value:4})}});
const w=dom.window;w.addEventListener('error',e=>console.log('ERR',e.message));
await new Promise(r=>setTimeout(r,2500));const $=s=>w.document.querySelector(s);
const t0=Date.now();$('#oRun').click();
for(let i=0;i<600;i++){await new Promise(r=>setTimeout(r,500));if(i%10==0)console.log(Math.round((Date.now()-t0)/1000)+'s',$('#oStatus').textContent.slice(0,80),$('#oBar').style.width);if(!$('#oRun').disabled&&/Terminé|échoué/.test($('#oStatus').textContent))break}
console.log('FIN',((Date.now()-t0)/1000).toFixed(1)+'s :',$('#oStatus').textContent.slice(0,120));
console.log('KPI',($('#oKpis')||{}).textContent?.slice(0,200));
process.exit(0)})();
