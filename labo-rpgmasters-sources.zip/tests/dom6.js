(async()=>{const {JSDOM}=require('jsdom');const fs=require('fs');
for(const f of ['labo-rpgmasters-public.html','labo-rpgmasters.html']){
const dom=new JSDOM(fs.readFileSync('/home/claude/rpg/'+f,'utf8'),{runScripts:'dangerously',pretendToBeVisual:true});
const w=dom.window;w.addEventListener('error',e=>console.log('ERR',e.message));
await new Promise(r=>setTimeout(r,3000));const $=s=>w.document.querySelector(s);
console.log(f,'banner hidden:',$('#exampleBanner').hidden,'|',$('#fresh').textContent,'|',$('#aFloors').textContent.slice(0,60),'| us len',$('#src-userscript').textContent.length);
}
process.exit(0);
})();
