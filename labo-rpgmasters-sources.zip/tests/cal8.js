const R=require("/home/claude/rpg/engine.js");R.setAutoOrder(process.env.ORD);R.setTuning({weaponLast:process.env.WL==="true"});const d=require(process.argv[2]);
const byName={};for(const c of d.cards)byName[c.n]=c;const items=d.items.concat(d.worn);
const mons={};for(const m of d.monsters)mons[m.name+'#'+m.grade]=m;const B=d.builds;
let so=0,ss=0,n=0,ae=0,wo=0,ws=0;const rows=[];
for(const f of d.fights){const b=B[f.bsig];if(!b)continue;const defs=f.mons.map(x=>mons[x]);if(defs.some(x=>!x))continue;
 const S=Object.assign({},b.stats);S._maxHp=b.maxHp;S._paTotal=b.basePa;S._dodge=Math.min(50,3+(S.pm||0));S._breed=d.meta.breedId;
 S._spectral=Math.min(50,({9:18}[d.meta.breedId]||0)+0.4*(S.po||0));
 const deck=b.deck.map(n=>byName[n]).filter(Boolean).map((c,i)=>R.prepCard(c,'c'+i));const wi=b.weapon&&items.find(i=>i.n===b.weapon&&i.w);const weapon=wi?R.weaponCard(wi,wi.f||0):null;
 const r=R.runMany({S,deck,weapon,monsters:defs,level:d.meta.level,auto:f.auto!==false},300);
 const won=f.status==='won';n++;so+=f.rounds;ss+=r.avgRounds;ae+=Math.abs(r.avgRounds-f.rounds)/f.rounds;wo+=won?1:0;ws+=r.winRate;
 rows.push([f.rounds,r.avgRounds.toFixed(2),won?'W':'L',(r.winRate*100).toFixed(0)+'%',f.mons.join('+').slice(0,70)]);}
console.log('fights',n,'obs rounds',(so/n).toFixed(2),'sim',(ss/n).toFixed(2),'MAPE',(ae/n*100).toFixed(1)+'%','wins obs',wo,'sim',ws.toFixed(1));
rows.sort((a,b)=>Math.abs(b[1]-b[0])-Math.abs(a[1]-a[0]));for(const r of rows.slice(0,15))console.log(' ',r.join(' | '));
