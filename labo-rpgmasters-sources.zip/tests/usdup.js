const {JSDOM}=require('jsdom');const fs=require('fs');
const src=fs.readFileSync('/home/claude/rpg/labo-rpgmasters.user.js','utf8');
const dom=new JSDOM('<!doctype html><body></body>',{url:'https://rpgmasters.houk.fr/chasse',runScripts:'outside-only'});
const w=dom.window;w.localStorage.setItem('labo-profile','saison');
const mk=v=>'0:'+JSON.stringify({state:{kind:'pve',status:'won',round:1,logCount:3,fighters:{p:{kind:'player',hp:100,maxHp:100,stats:{},cards:{}},m0:{kind:'monster',id:'m0',name:'Kokayou',grade:1,maxHp:1638,hp:0,atk:300,element:1,pattern:['attack'],stats:{},alive:false}},log:[{t:'play',who:'p',card:'Bluff'},{t:'dmg',who:'m0',v:v},{t:'death',who:'m0'}]},rewards:{xp:1000}});
let cur='';w.fetch=async()=>({clone(){return{text:async()=>cur}},headers:{get:()=>'text/x-component'},text:async()=>cur});
w.eval(src);
(async()=>{for(const v of [1700,1650,1650,1702]){cur=mk(v);await w.fetch('/x',{method:'POST'});await new Promise(r=>setTimeout(r,100))}
const p=[...w.document.querySelectorAll('div')].find(d=>/cette session/.test(d.textContent||''));console.log((p.textContent.match(/Combats\s*\d+/)||[])[0]);process.exit(0)})();
