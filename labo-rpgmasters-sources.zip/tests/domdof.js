(async()=>{const {JSDOM}=require('jsdom');const fs=require('fs');
const dom=new JSDOM(fs.readFileSync('/home/claude/rpg/labo-rpgmasters.html','utf8'),{url:'https://venominones.github.io/Dofusrpg/',runScripts:'dangerously',pretendToBeVisual:true,beforeParse(w){w.Worker=undefined;w.localStorage.setItem('labo-data-saison',fs.readFileSync('/tmp/claude-0/imp9/export.json','utf8'));w.localStorage.setItem('labo-lprofile','saison')}});
const w=dom.window;let errs=0;w.addEventListener('error',e=>{errs++;console.log('ERR',e.message)});await new Promise(r=>setTimeout(r,2500));const $=s=>w.document.querySelector(s);
$('#t-items').click();await new Promise(r=>setTimeout(r,500));console.log([...w.document.querySelectorAll('#dofusFx tr')].slice(0,5).map(r=>r.textContent).join('\n'));
$('#tlFor').value='saison';$('#tlFor').dispatchEvent(new w.Event('change'));$('#tlSlot').value='dofus';$('#tlSlot').dispatchEvent(new w.Event('change'));
console.log([...w.document.querySelectorAll('#tlOut tr')].slice(0,6).map(r=>r.textContent).join('\n'));console.log('erreurs',errs);process.exit(0)})();
