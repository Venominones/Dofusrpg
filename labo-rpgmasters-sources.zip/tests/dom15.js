(async()=>{const {JSDOM}=require('jsdom');const fs=require('fs');
const dom=new JSDOM(fs.readFileSync('/home/claude/rpg/labo-rpgmasters.html','utf8'),{url:'https://labo.test/',runScripts:'dangerously',pretendToBeVisual:true});
const w=dom.window;w.addEventListener('error',e=>console.log('ERR',e.message));
await new Promise(r=>setTimeout(r,2500));const $=s=>w.document.querySelector(s);
$('#oRun').click();let t0=Date.now(),last='';while($('#oRun').disabled&&Date.now()-t0<580000){await new Promise(r=>setTimeout(r,2000));const st=$('#oStatus').textContent.split('·')[0];if(st!==last){last=st;console.log(((Date.now()-t0)/1000|0)+'s',st)}}
console.log('RES:',$('#oStatus').textContent,'|',$('#oDetails').textContent.replace(/\s+/g,' ').slice(900,2600));process.exit(0)})();
