(async()=>{const {JSDOM}=require('jsdom');const fs=require('fs');
const base=JSON.parse(fs.readFileSync('/home/claude/rpg/data.json','utf8'));
const m0=base.monsters[0];const P=['attack','attack','heavy','guard','drain','heavy'];
const mk=(n,st)=>Object.assign({},m0,{name:n,grade:5,isBoss:true,hpMin:9000,hpMax:12000,atk:944,pattern:P,stats:st||{}});
const mons=[mk('Koumiho'),mk('Minotot'),mk('Ben le Ripate')];
const best={t:Date.now(),pp:415.8,mech:[{id:1,n:'Koumiho',l:170,t:['chemin','zone','ascension'],u:1,v:4,m:[{mn:'Onde de choc',d:'F',asc:[1,2],oc:15,x:'Deux sorts… 15 %'},{mn:'Miroir',d:'C',ch:82,beyond:106,mi:[3,4],x:'Aux tours 3 à 4, chaque coup que tu lui portes t’est renvoyé.'},{mn:'Fureur',d:'C',second:1,fu:[2,2.5],x:'Si tu joues plus de 2 cartes…×2,5'}]},{id:2,n:'Minotot',l:180,t:['ascension'],u:1,v:1,m:[{mn:'Deuxième souffle',d:'C',second:1,ds:[35,1],x:'Il se relève une fois avec 35 % de ses PV, fou de rage'}]},{id:3,n:'Kimbo',l:190,t:['zone'],u:0,v:0,m:[]}],
 monsters:[{id:10,n:'Bouftou',race:'Bouftous',lo:1,hi:5,z:[450],d:[[2473,1.18,2.5]]}],items:[{id:2473,n:"Cape de l'Aventurier",lvl:8,s:'cape',st:{force:5},setName:'Panoplie du Jeune Aventurier'}],zones:[{id:450,n:'Route des âmes',area:'Incarnam',min:1,max:5}]};
const d=Object.assign({},base,{monsters:base.monsters.concat(mons),bestiary:best,
 fights:[{kind:'boss',status:'lost',rounds:3,floor:23,mons:['Koumiho#5','Minotot#5','Ben le Ripate#5'],ctx:{}}],
 floors:[{floor:23,bosses:['Koumiho','Minotot','Ben le Ripate'],attempts:16,wins:0,hints:[],bossKeys:['Koumiho#5','Minotot#5','Ben le Ripate#5'],bossStats:[{k:'Koumiho#5',maxHp:11850,atk:1122},{k:'Minotot#5',maxHp:11950,atk:1122},{k:'Ben le Ripate#5',maxHp:11950,atk:1122}]}]});
const dom=new JSDOM(fs.readFileSync('/home/claude/rpg/labo-rpgmasters.html','utf8'),{url:'https://labo.test/',runScripts:'dangerously',pretendToBeVisual:true,beforeParse(w){w.localStorage.setItem('labo-data',JSON.stringify(d))}});
const w=dom.window;w.addEventListener('error',e=>console.log('ERR',e.message));
await new Promise(r=>setTimeout(r,2500));const $=s=>w.document.querySelector(s);
console.log('PACK:',$('#aPack').selectedOptions[0]&&$('#aPack').selectedOptions[0].textContent);console.log('MECH:',$('#aMech').textContent);
console.log('BEST:',$('#bInfo').textContent,'|',$('#bOut').textContent.slice(0,300));
const fl=$('#bFloor');fl.value='23';fl.dispatchEvent(new w.Event('input'));console.log('F23:',$('#bOut').textContent.slice(0,400));
w.document.querySelector('#bView [data-v="item"]').click();console.log('ITEM:',$('#bOut').textContent.slice(0,200));
w.document.querySelector('#bView [data-v="mon"]').click();console.log('MON:',$('#bOut').textContent.slice(0,200));
w.document.querySelector('#aEffort [data-v="1"]').click();$('#aRun').click();const t0=Date.now();while($('#aRun').disabled&&Date.now()-t0<300000)await new Promise(r=>setTimeout(r,500));
console.log('RUN:',$('#aStatus').textContent,'|',$('#aResult').textContent.slice(0,250));process.exit(0)})();
