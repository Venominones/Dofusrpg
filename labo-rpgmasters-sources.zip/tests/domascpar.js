(async()=>{const {JSDOM}=require('jsdom');const fs=require('fs');const WT=require('worker_threads');
class FakeWorker{constructor(){this.t=new WT.Worker('/tmp/claude-0/wthread.js');this.t.on('message',m=>this.onmessage&&this.onmessage({data:m}));this.t.on('error',e=>this.onerror&&this.onerror({message:e.message}))}postMessage(m){this.t.postMessage(JSON.parse(JSON.stringify(m)))}terminate(){this.t.terminate()}}
const dom=new JSDOM(fs.readFileSync('/home/claude/rpg/labo-rpgmasters.html','utf8'),{url:'https://labo.test/',runScripts:'dangerously',pretendToBeVisual:true,beforeParse(w){w.Worker=FakeWorker;w.URL.createObjectURL=()=>'blob:fake';Object.defineProperty(w.navigator,'hardwareConcurrency',{value:4})}});
const w=dom.window;w.addEventListener('error',e=>console.log('ERR',e.message));
await new Promise(r=>setTimeout(r,3000));const $=s=>w.document.querySelector(s);

console.log('pack',$('#aPack').value,$('#aRun').disabled);
const t0=Date.now();$('#aRun').click();
for(let i=0;i<600;i++){await new Promise(r=>setTimeout(r,500));if(!$('#aRun').disabled&&/Terminé|échoué/.test($('#aStatus').textContent))break}
console.log('asc 1er',((Date.now()-t0)/1000).toFixed(1)+'s',$('#aStatus').textContent.slice(0,90));
await new Promise(r=>setTimeout(r,200));
const t1=Date.now();$('#aRun').click();await new Promise(r=>setTimeout(r,300));
console.log('asc 2e',((Date.now()-t1)/1000).toFixed(1)+'s',$('#aStatus').textContent.slice(0,90),'|',$('#aReady').textContent,'|',[...$('#aPack').options].filter(o=>o.textContent.startsWith('✓')).map(o=>o.textContent.slice(0,40)));
process.exit(0)})();
