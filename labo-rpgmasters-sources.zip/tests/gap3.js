const R=require("/home/claude/rpg/engine.js");const d=require(process.argv[2]);
const byName={};for(const c of d.cards)byName[c.n]=c;const items=(d.items||[]).concat(d.worn||[]);
const mons={};for(const m of d.monsters)mons[m.name+'#'+m.grade]=m;const B=d.builds;const dofus=(d.worn||[]).filter(w=>w.s==='dofus').map(w=>w.n);
let n=0,pz=0,obsz=0,abs=0,raw=0,shp=0;
for(const f of d.fights){if(f.kind==='boss')continue;const b=B[f.bsig];if(!b)continue;const defs=f.mons.map(x=>mons[x]);if(defs.some(x=>!x))continue;
 const S=R.deriveStats(b.stats,{maxHp:b.maxHp,basePa:b.basePa,breedId:d.meta.breedId,dofus});
 const deck=b.deck.map(n=>byName[n]).filter(Boolean).map((c,i)=>R.prepCard(c,'c'+i));const wi=b.weapon&&items.find(i=>i.n===b.weapon&&i.w);
 const K=100;let z=0;const mlog={};for(let k=0;k<K;k++){const r=R.simulateFight({S,deck,weapon:wi?R.weaponCard(wi,wi.f||0):null,monsters:defs,level:d.meta.level,auto:f.auto!==false,mlog});if(r.hpLost>0)z++}
 n++;pz+=z/K;if(f.dmgTaken>0)obsz++;raw+=(mlog.raw||0)/K}
console.log('combats',n,'réel : part avec PV perdus',(obsz/n*100).toFixed(0)+'%','| sim',(pz/n*100).toFixed(0)+'%','| sim dégâts bruts',(raw/n).toFixed(0));
