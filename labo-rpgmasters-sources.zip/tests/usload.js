const {JSDOM}=require('jsdom');const fs=require('fs');
const src=fs.readFileSync('/home/claude/rpg/labo-rpgmasters.user.js','utf8');
const dom=new JSDOM('<!doctype html><body></body>',{url:'https://rpgmasters.houk.fr/combat',runScripts:'outside-only'});
const w=dom.window;console.log('eval…');
const i=src.indexOf('/*__ENGINE_END__*/');console.log('engine block ends at',i,'of',src.length);
const t=Date.now();try{w.eval(src)}catch(e){console.log('err',e.message)}console.log('eval ok',Date.now()-t);process.exit(0);
