(async()=>{const {JSDOM}=require('jsdom');const fs=require('fs');
const dom=new JSDOM(fs.readFileSync('/home/claude/rpg/site/index.html','utf8'),{url:'https://venominones.github.io/Dofusrpg/',runScripts:'dangerously',pretendToBeVisual:true,beforeParse(w){w.Worker=undefined;w.URL.createObjectURL=b=>{w.__blob=b;return 'blob:x'};w.URL.revokeObjectURL=()=>{}}});
const w=dom.window;w.addEventListener('error',e=>console.log('ERR',e.message));
await new Promise(r=>setTimeout(r,2500));const $=s=>w.document.querySelector(s);
const d=JSON.parse(fs.readFileSync('imp9/export.json','utf8'));const ev=new w.Event('paste',{bubbles:true});ev.clipboardData={getData:()=>JSON.stringify(d)};w.document.body.dispatchEvent(ev);await new Promise(r=>setTimeout(r,1500));
let name='';w.HTMLAnchorElement.prototype.click=function(){name=this.download};
$('#dlClaude').click();await new Promise(r=>setTimeout(r,300));
console.log($('#importMsg').textContent,'|',name,'| export complet',Math.round(JSON.stringify(d).length/1024),'Ko');
const txt=await w.__blob.text();const o=JSON.parse(txt);console.log(Object.keys(o).join(','),'journal',o.journal.length,'fights',o.fights.length,'monstres',o.monsters.length,'cartes',o.cards.length);process.exit(0)})();
