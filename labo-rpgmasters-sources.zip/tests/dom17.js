(async()=>{const {JSDOM}=require('jsdom');const fs=require('fs');const O=require('/home/claude/rpg/optimizer.js');
const d=JSON.parse(fs.readFileSync('/home/claude/rpg/data.json','utf8'));d._cardsByKey=Object.fromEntries(d.cards.map(c=>[c.key,c]));
const gear={};for(const w of d.worn)gear[w.slot]=w;const alloc=Object.fromEntries(d.meta.rows.map(r=>[r.key,r.base]));
const ctx={prestige:d.meta.prestige,discordPct:5,scrolls:d.meta.scrolls,level:200,breedId:d.meta.breedId};
const b=O.buildState(d,{gear,alloc,deck:d.meta.decks[d.meta.active]},ctx);const st={};for(const k in b.S)if(!k.startsWith('_')&&typeof b.S[k]==='number')st[k]=b.S[k];
d.builds={X:{stats:st,deck:d.meta.decks[d.meta.active].map(k=>d._cardsByKey[k].n),weapon:gear.arme&&gear.arme.n,maxHp:b.S._maxHp,basePa:b.S._paTotal}};delete d._cardsByKey;
d.fights=d.fights.map(f=>Object.assign({},f,{bsig:'X',auto:true}));
const dom=new JSDOM(fs.readFileSync('/home/claude/rpg/labo-rpgmasters.html','utf8'),{url:'https://labo.test/',runScripts:'dangerously',pretendToBeVisual:true,beforeParse(w){w.localStorage.setItem('labo-data',JSON.stringify(d))}});const w=dom.window;w.addEventListener('error',e=>console.log('ERR',e.message));await new Promise(r=>setTimeout(r,3000));w.document.getElementById('calRun').click();await new Promise(r=>setTimeout(r,4000));console.log(w.document.getElementById('calOut').textContent.replace(/\s+/g,' ').slice(0,500));process.exit(0)})();
