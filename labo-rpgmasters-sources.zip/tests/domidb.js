(async()=>{const {JSDOM}=require('jsdom');const fs=require('fs');require('fake-indexeddb/auto');
const html=fs.readFileSync('/home/claude/rpg/labo-rpgmasters.html','utf8');
const mk=async(pre)=>{const dom=new JSDOM(html,{url:'https://venominones.github.io/Dofusrpg/',runScripts:'dangerously',pretendToBeVisual:true,beforeParse(w){w.Worker=undefined;w.indexedDB=globalThis.indexedDB;w.IDBKeyRange=globalThis.IDBKeyRange;if(pre)pre(w)}});await new Promise(r=>setTimeout(r,2500));return dom.window};
// 1) ancien stockage localStorage -> migration
let w=await mk(w=>{w.localStorage.setItem('labo-data-saison',fs.readFileSync('/tmp/claude-0/imp8/export.json','utf8'));w.localStorage.setItem('labo-lprofile','saison')});
console.log('1 header',w.document.querySelector('#fresh').textContent.slice(0,70),'| LS restant',w.localStorage.getItem('labo-data-saison')?'oui':'non');
// 2) import d'un gros export
const big=JSON.parse(fs.readFileSync('/tmp/claude-0/imp9/export.json','utf8'));big.fights=big.fights.concat(big.fights,big.fights,big.fights);
w.document.querySelector('#importBox').value=JSON.stringify(big);w.document.querySelector('#importBtn').click();await new Promise(r=>setTimeout(r,800));
console.log('2 header',w.document.querySelector('#fresh').textContent.slice(0,70),'| msg',w.document.querySelector('#importMsg').textContent.slice(0,120));
// 3) nouvelle page (même IndexedDB) : données toujours là
await new Promise(r=>setTimeout(r,500));const w2=await mk(w=>{w.localStorage.setItem('labo-lprofile','saison')});await new Promise(r=>setTimeout(r,1500));
console.log('3 rechargé',w2.document.querySelector('#fresh').textContent.slice(0,70));process.exit(0)})();
