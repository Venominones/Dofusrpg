const fs=require('fs');const src=fs.readFileSync('/home/claude/rpg/labo-rpgmasters.user.js','utf8');
const store={};global.localStorage={getItem:k=>store[k]??null,setItem:(k,v)=>store[k]=v,removeItem:k=>delete store[k]};
let fetchImpl=null;const appended=[];
const mkEl=()=>({setAttribute(){},addEventListener(){},remove(){},querySelector:()=>({textContent:''}),set innerHTML(v){this._h=v},get innerHTML(){return this._h},dataset:{}});
global.window={fetch:(...a)=>fetchImpl(...a)};global.navigator={};
global.document={readyState:'loading',addEventListener(){},createElement:mkEl,documentElement:{contains:()=>true,appendChild(e){appended.push(e)}}};
eval(src);
const boss={id:'m0',kind:'monster',name:'Kralamoure',grade:1,maxHp:9000,atk:500,element:3,pattern:['attack','heavy'],stats:{},isBoss:true};
const mk=(status,round,log)=>'1:'+JSON.stringify({screen:{onAscension:true,ascensionFloor:12},state:{kind:'pve',status,round,logCount:log.length,fighters:{p:{kind:'player',hp:3000,maxHp:4800,sealed:[]},m0:boss},log}})+'\n';
const L=[{t:'round',round:1},{t:'turn',who:'p'},{t:'round',round:3},{t:'mechanic',who:'m0',text:'Inversion : pendant ce tour, tes soins et tes boucliers te blessent au lieu de te protéger.'},{t:'mechanic',who:'m0',text:'Sceau : ton premier sort de chaque tour coûte +2 PA.'}];
(async()=>{
 fetchImpl=async()=>({clone:()=>({text:async()=>mk('lost',5,L)})});await window.fetch('/combat',{method:'POST'});await new Promise(r=>setTimeout(r,500));
 console.log(JSON.stringify(window.LaboRec.db.monsters['Kralamoure#1'].mech.parsed),window.LaboRec.db.fights[0].ctx);
 store['labo-builds-v1']=JSON.stringify({builds:[{label:'Anti-Kralamoure',targets:['Kralamoure#1'],gearCode:'DM-E-X',deckCode:'DM-S-Y',winRate:.82}]});
 boss.id='m0';boss.maxHp=9010;fetchImpl=async()=>({clone:()=>({text:async()=>mk('active',1,[{t:'round',round:1}])})});await window.fetch('/combat',{method:'POST'});await new Promise(r=>setTimeout(r,100));
 const b=appended.find(e=>e._h&&e._h.includes('adversaire connu'));console.log(b?b._h.replace(/<[^>]+>/g,' ').replace(/\s+/g,' ').slice(0,400):'NO BANNER');
})();
