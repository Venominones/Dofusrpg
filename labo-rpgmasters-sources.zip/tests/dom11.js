(async()=>{const {JSDOM}=require('jsdom');const fs=require('fs');
const exp=JSON.parse(fs.readFileSync('imp/export.json','utf8'));const main=JSON.parse(fs.readFileSync('/home/claude/rpg/data.json','utf8'));main.bestiary=exp.bestiary;main.meta.profile='principal';
const dom=new JSDOM(fs.readFileSync('/home/claude/rpg/labo-rpgmasters.html','utf8'),{url:'https://labo.test/',runScripts:'dangerously',pretendToBeVisual:true,beforeParse(w){w.localStorage.setItem('labo-data',JSON.stringify(main))}});
const w=dom.window;w.addEventListener('error',e=>console.log('ERR',e.message));
await new Promise(r=>setTimeout(r,2500));const $=s=>w.document.querySelector(s);
w.document.querySelector('#profMode [data-v="saison"]').click();await new Promise(r=>setTimeout(r,800));
$('#importBox').value=JSON.stringify(exp);$('#importBtn').click();await new Promise(r=>setTimeout(r,1500));
console.log($('#importMsg').textContent);console.log($('#bInfo').textContent);process.exit(0)})();
