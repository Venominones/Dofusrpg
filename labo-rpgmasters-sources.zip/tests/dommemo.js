(async()=>{const {JSDOM}=require('jsdom');const fs=require('fs');
const dom=new JSDOM(fs.readFileSync('/home/claude/rpg/labo-rpgmasters.html','utf8'),{url:'https://labo.test/',runScripts:'dangerously',pretendToBeVisual:true,beforeParse(w){w.Worker=undefined;}});
const w=dom.window;w.addEventListener('error',e=>console.log('ERR',e.message));
await new Promise(r=>setTimeout(r,3000));
const $=s=>w.document.querySelector(s);
const eff=$('#oEffort [data-v="1"]');if(eff)eff.click();
const t0=Date.now();$('#oRun').click();
for(let i=0;i<600;i++){await new Promise(r=>setTimeout(r,500));if(!$('#oRun').disabled&&/Terminé|échoué/.test($('#oStatus').textContent))break}
console.log('1er calcul',((Date.now()-t0)/1000).toFixed(1)+'s :',$('#oStatus').textContent.slice(0,120));
const r1=$('#oKpis').textContent;$('#oKpis').innerHTML='';
const t1=Date.now();$('#oRun').click();await new Promise(r=>setTimeout(r,300));
console.log('2e clic',((Date.now()-t1)/1000).toFixed(1)+'s :',$('#oStatus').textContent.slice(0,140),'| même résultat réaffiché',$('#oKpis').textContent===r1&&r1.length>0);
const mem=w.localStorage.getItem('labo-memo-principal');console.log('mémoire',mem?Math.round(mem.length/1024)+' Ko':'vide');
process.exit(0)})();
