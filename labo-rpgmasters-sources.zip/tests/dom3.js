const {JSDOM}=require('jsdom');const fs=require('fs');
const dom=new JSDOM(fs.readFileSync('/home/claude/rpg/labo-rpgmasters.html','utf8'),{runScripts:'dangerously',pretendToBeVisual:true});
const w=dom.window;w.addEventListener('error',e=>console.log('ERR',e.message));
setTimeout(()=>{const $=s=>w.document.querySelector(s);
 const sel=$('#oObj');sel.value='pp';sel.dispatchEvent(new w.Event('change'));
 w.document.querySelector('#oEffort [data-v="1"]').click();
 $('#oRun').click();
 const iv=setInterval(()=>{if(!$('#oRun').disabled){clearInterval(iv);console.log($('#oStatus').textContent);console.log($('#oKpis').textContent);console.log($('#oDetails').textContent.slice(0,700));process.exit(0)}},500);
},3000);
