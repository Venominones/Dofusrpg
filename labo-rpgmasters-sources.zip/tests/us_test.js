const fs=require('fs');const src=fs.readFileSync('/home/claude/rpg/labo-rpgmasters.user.js','utf8');
const store={};global.localStorage={getItem:k=>store[k]??null,setItem:(k,v)=>store[k]=v};
let fetchImpl=null;
global.window={fetch:(...a)=>fetchImpl(...a)};global.document={readyState:'loading',addEventListener(){} ,documentElement:{contains:()=>true,appendChild(){}}};
eval(src);
const d=require('/home/claude/rpg/data.json');
// fake payload: a won fight state + rewards
const state={kind:'pve',status:'won',round:3,logCount:3,auto:true,autoAfk:true,fighters:{p:{kind:'player',hp:4800,maxHp:4847,level:200},m0:{id:'m0',kind:'monster',name:'Test',grade:1,maxHp:1000,atk:300,element:2,pattern:['attack','heavy'],stats:{resPctFeu:5},isBoss:false},m1:{id:'m1',kind:'monster',name:'Test',grade:1,maxHp:1010,atk:300,element:2,pattern:'$1:state:fighters:m0:pattern',stats:'$1:state:fighters:m0:stats'}},log:[{t:'turn',who:'p'},{t:'play',who:'p',card:'Bluff',crit:true},{t:'dmg',who:'m0',v:500,el:3},{t:'turn',who:'m0'},{t:'dmg',who:'p',v:47,el:2}]};
const body='0:{"a":"$@1"}\n1:'+JSON.stringify({state,rewards:{xp:1000,kamas:12,items:[{n:'Cape X'}],card:null,newLevel:200}})+'\n';
fetchImpl=async()=>({clone:()=>({text:async()=>body})});
(async()=>{await window.fetch('/combat',{method:'POST'});await window.fetch('/combat',{method:'POST'});await new Promise(r=>setTimeout(r,600));
const db=window.LaboRec.db;console.log(db.fights.length,JSON.stringify(db.fights[0]),Object.keys(db.monsters),window.LaboRec.summary(0));})();
