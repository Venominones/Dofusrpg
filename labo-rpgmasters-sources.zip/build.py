import json,re,sys
# Copie le moteur dans le script Tampermonkey (garde-fou : simulation locale avant un boss)
_us=open('labo-rpgmasters.user.js').read()
_eng=open('engine.js').read().rstrip()
_tail="})(typeof self !== 'undefined' ? self : this);"
assert _eng.endswith(_tail)
_eng=_eng[:-len(_tail)]+"})(__labo);"
_block="/*__ENGINE_BEGIN__*/ const LR = (function () { const __labo = {};\n"+_eng+"\n  return __labo.RPG; })(); /*__ENGINE_END__*/"
_us=re.sub(r"/\*__ENGINE_BEGIN__\*/.*?/\*__ENGINE_END__\*/",lambda m:_block,_us,flags=re.S)
open('labo-rpgmasters.user.js','w').write(_us)
t=open('template.html').read()
d=json.load(open('data.json'))
safe=lambda s:s.replace('</script','<\\/script')
def make(mode,data):
    x=t.replace('__DATA__',safe(json.dumps(data,ensure_ascii=False,separators=(',',':')))).replace('__ENGINE__',safe(open('engine.js').read())).replace('__OPT__',safe(open('optimizer.js').read())).replace('__SNIPPET__',safe(open('snippet.js').read())).replace('__USERSCRIPT__',safe(open('labo-rpgmasters.user.js').read())).replace('__MODE__',mode)
    return x
def standalone(x):
    he=x.index('<div class="wrap">')
    return '<!doctype html>\n<html lang="fr">\n<head>\n<meta charset="utf-8">\n<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">\n'+x[:he]+'</head>\n<body>\n'+x[he:]+'\n</body>\n</html>\n'
p=make('perso',d); open('labo.html','w').write(p); open('labo-rpgmasters.html','w').write(standalone(p))
# Version publique : personnage d'exemple (équipement porté et deck seulement), sans inventaire, combats, builds ni historique
pub=dict(d); pub['playerStats']={}; pub['fights']=[]; pub['builds']={}; pub['floors']=[]; pub['items']=[]
pub['meta']=dict(d['meta']); pub['meta']['decks']=[d['meta']['decks'][d['meta']['active']]]+[[] for _ in d['meta']['decks'][1:]]; pub['meta']['active']=0; pub['meta']['deckNames']=['Exemple']+['' for _ in d['meta']['decks'][1:]]
pub['meta'].pop('forge',None)
q=make('public',pub); open('labo-public.html','w').write(q); open('labo-rpgmasters-public.html','w').write(standalone(q))
open('/tmp/claude-0/m.js','w').write(re.findall(r'<script>(.*?)</script>',p,re.S)[-1])
print('ok',len(p),len(q))
import os,shutil
os.makedirs('site',exist_ok=True); shutil.copy('labo-rpgmasters-public.html','site/index.html'); shutil.copy('labo-rpgmasters.user.js','site/labo-rpgmasters.user.js'); open('site/.nojekyll','w').close()
