// Optimiseur : stuff + points de caractéristiques + deck
(function (root) {
  'use strict';
  const R = (typeof module !== 'undefined' && module.exports) ? require('./engine.js') : root.RPG;

  const SLOTS = [
    ['chapeau', 'chapeau'], ['cape', 'cape'], ['amulette', 'amulette'], ['anneau1', 'anneau'], ['anneau2', 'anneau'],
    ['ceinture', 'ceinture'], ['bottes', 'bottes'], ['arme', 'arme'], ['bouclier', 'bouclier'], ['familier', 'familier'],
    ['dofus1', 'dofus'], ['dofus2', 'dofus'], ['dofus3', 'dofus'], ['dofus4', 'dofus'], ['dofus5', 'dofus'], ['dofus6', 'dofus']];
  const CARACS = ['force', 'intelligence', 'chance', 'agilite'];

  // Orientations : vitesse, survie, sagesse, pp, mono:<el>, multi, ascension
  const ORIENT = {
    equilibre: { label: 'Polyvalent (tank + dégâts)' }, vitesse: { label: 'Finir vite' }, survie: { label: 'Survivre' }, sagesse: { label: 'Sagesse (XP)', focus: 'sagesse' },
    pp: { label: 'Prospection (butin)', focus: 'chance' }, multi: { label: 'Multi-élément' }, ascension: { label: 'Ascension' }, 'ascension-tank': { label: 'Ascension · Tank' }, 'ascension-burst': { label: 'Ascension · Dégâts' },
    'mono:1': { label: 'Mono Terre', el: 1 }, 'mono:2': { label: 'Mono Feu', el: 2 }, 'mono:3': { label: 'Mono Eau', el: 3 }, 'mono:4': { label: 'Mono Air', el: 4 }
  };
  function winGate(r) { return r.winRate >= 0.95 ? 1000 : r.winRate * 1000 - 200; }
  function score(r, S, objective) {
    const hpPct = r.avgHpLost / S._maxHp * 100;
    const rounds = isFinite(r.avgRounds) ? r.avgRounds : 30;
    if (objective === 'ascension') return r.winRate * 1000 + 150 * (r.progress || 0) + 15 * (r.avgKills || 0) - hpPct * 0.5 - rounds * 1;
    // Styles d'Ascension : tank (survie, PV gardés, boucliers) ou burst (finir vite avant les mécaniques des tours 3-4)
    if (objective === 'ascension-tank') return r.winRate * 1000 + 100 * (r.progress || 0) - hpPct * 4 - rounds * 0.5;
    if (objective === 'ascension-burst') return r.winRate * 1000 + 200 * (r.progress || 0) + 20 * (r.avgKills || 0) - hpPct * 0.3 - rounds * 15;
    if (objective === 'equilibre') return r.winRate * 1000 - rounds * 22 - hpPct * 3.5;
    if (objective === 'survie') return r.winRate * 1000 - hpPct * 6 - rounds * 4;
    if (objective === 'sagesse') return winGate(r) + 500 * Math.log((1 + (S.sagesse || 0) / 100) / rounds);
    if (objective === 'pp') return winGate(r) + 500 * Math.log((S._pp || 100) / rounds);
    return r.winRate * 1000 - rounds * 40 - hpPct * 2; // vitesse, mono, multi
  }
  function cardEls(c) { return [...new Set((c.eff || []).filter(l => l.k === 'dmg' || l.k === 'steal' || l.k === 'bomb').map(l => l.el || 0))]; }
  // sustain : 'all' | 'shield' (pas de soin) | 'none' (ni soin ni bouclier) | {heal, shield, steal} (cases à cocher)
  function normSus(sustain, noSteal) {
    if (sustain && typeof sustain === 'object') return { heal: sustain.heal !== false, shield: sustain.shield !== false, steal: sustain.steal !== false && !noSteal };
    const s = sustain || 'all';
    return { heal: s === 'all', shield: s !== 'none', steal: !noSteal };
  }
  function sustainAllowed(c, sustain, noSteal) {
    const ks = (c.eff || []).map(l => l.k), A = normSus(sustain, noSteal);
    if (!A.steal && ks.includes('steal')) return false; // le vol de vie reste permis (c'est des dégâts) sauf exclusion explicite ou mécanique qui inverse les soins
    if (!A.heal && ks.some(k => k === 'heal' || k === 'healPct')) return false;
    if (!A.shield && ks.some(k => k === 'shieldHp' || k === 'shieldLvl')) return false;
    return true;
  }
  function cardAllowed(c, objective, sustain, noSteal) {
    if (!c || !sustainAllowed(c, sustain, noSteal)) return false;
    const o = ORIENT[objective] || {};
    const els = cardEls(c);
    if (o.el !== undefined) return els.length === 0 || els.every(e => e === o.el);
    if (objective === 'multi') return els.length === 0 || els.length >= 2;
    return true;
  }

  // Tous les objets possédés, regroupés par emplacement (instances distinctes via qty)
  function itemPool(data) {
    const pool = {};
    const seen = new Set();
    for (const it of data.items.concat(data.worn.map(w => Object.assign({ q: 1 }, w)))) {
      const key = it.id + ':' + (it.f || 0);
      if (seen.has(key)) continue; seen.add(key);
      if (!it.st || typeof it.st !== 'object') continue;
      (pool[it.s] = pool[it.s] || []).push(it);
    }
    return pool;
  }

  // Poids des stats pour pré-filtrer les objets (dérivés du deck)
  const CRIT_GAIN = 0.2;
  function statWeights(deck, weapon, S, defensive) {
    const w = { puissance: 0, dommages: 0, critique: 0, vitalite: defensive ? 0.6 : 0.25, dommagesCritiques: 0 };
    for (const c of deck.concat(weapon ? [weapon] : [])) {
      let first = true;
      for (const l of c.dmgLines) {
        const avg = (l.min + l.max) / 2 * (l.zone ? 2 : 1);
        const car = R.CARAC_OF_EL[l.el || 0];
        w[car] = (w[car] || 0) + avg / 100;
        w.puissance += avg / 100;
        if (c.weapon || first) { w.dommages += 1; const k = 'dommages' + R.EL_NAMES[l.el || 0]; w[k] = (w[k] || 0) + 1; }
        first = false;
      }
      if (c.cc > 0) w.critique += 0.35 * c.dmgLines.length;
      // dommages critiques : ajoutés aux lignes qui portent les dommages fixes, quand le coup est critique
      const pc = Math.min(1, Math.max(0, ((S && S.critique) || 0) + (c.cc || 0)) / 100);
      w.dommagesCritiques += pc * (c.weapon ? c.dmgLines.length : (c.dmgLines.length ? 1 : 0));
    }
    // dégâts totaux d'un tour de deck (base × caracs/puissance + fixes) : sert à valoriser ce qui multiplie tout
    let tot = 0;
    for (const c of deck.concat(weapon ? [weapon] : [])) { let first = true; for (const l of c.dmgLines) { const car = R.CARAC_OF_EL[l.el || 0]; tot += (l.min + l.max) / 2 * (l.zone ? 2 : 1) * (1 + Math.max(0, ((S && S[car]) || 0) + ((S && S.puissance) || 0)) / 100) + ((c.weapon || first) ? (((S && S.dommages) || 0) + ((S && S['dommages' + R.EL_NAMES[l.el || 0]]) || 0)) : 0); first = false; } }
    w.dmgPctSorts = tot / 100;                                                       // % dommages aux sorts : +1 % de tout
    const penLeft = Math.max(0, 50 - (((S && S.dmgPctDistance) || 0) + ((S && S.dmgPctMelee) || 0)));
    w.dmgPctDistance = w.dmgPctMelee = penLeft > 0 ? tot * 0.8 / 100 * 0.25 * 2 : 0;  // pénétration (×Prestige, plafond 50)
    const res = defensive ? 1.2 : 0.4;
    for (let e = 0; e < 5; e++) { w[R.RES_PCT[e]] = res * 6; w[R.RES_FIX[e]] = res * 0.6; }
    const redLeft = Math.max(0, 50 - (((S && S.resPctDistance) || 0) + ((S && S.resPctMelee) || 0)));
    w.resPctDistance = w.resPctMelee = redLeft > 0 ? res * 6 * 5 * 2 : 0;           // réduction : vaut une résistance sur les 5 éléments
    // PA : une carte de plus par tour ≈ dégâts d'un tour ÷ PA totaux ; critique : +1 % → +0,2 % des dégâts (×1,2 en critique), tant qu'on n'est pas à 100 %
    const paT = Math.max(6, (S && S._paTotal) || 10);
    w.pa = Math.max(60, tot / paT); w.pm = 3;
    if (((S && S.critique) || 0) < 100) w.critique = Math.max(w.critique, tot * (CRIT_GAIN) / 100);
    w.po = 2 + (S && S._breed === 9 && (S._spectral || 0) < 60 ? tot * 0.4 / 100 : 0); // Crâ : chaque PO = +0,4 % de vision spectrale
    return w;
  }
  function orientWeights(w, objective) {
    const o = ORIENT[objective] || {};
    if (objective === 'sagesse') w.sagesse = (w.sagesse || 0) + 1.5;
    if (objective === 'pp') { w.prospection = (w.prospection || 0) + 1.5; w.chance = (w.chance || 0) + 0.15; }
    if (o.el !== undefined) { for (let e = 1; e <= 4; e++) if (e !== o.el) { const car = R.CARAC_OF_EL[e]; if (car !== R.CARAC_OF_EL[o.el]) w[car] = (w[car] || 0) * 0.2; } }
    return w;
  }
  function dominates(a, b) {
    const sa = R.itemStats(a, a.f || 0), sb = R.itemStats(b, b.f || 0); let strict = false;
    for (const k of new Set(Object.keys(sa).concat(Object.keys(sb)))) { const x = sa[k] || 0, y = sb[k] || 0; if (x < y) return false; if (x > y) strict = true; }
    return strict;
  }
  function itemHeur(it, weights) {
    const st = R.itemStats(it, it.f || 0); let v = 0;
    for (const k in st) v += (weights[k] || 0) * st[k];
    if (it.w) { for (const l of R.weaponWithFusion(it.w, it.f || 0).lines) if (l.k === 'dmg' || l.k === 'steal') v += (l.min + l.max) / 2 * 3 / Math.max(3, it.w.ap); }
    return v;
  }

  function weaponSteals(it) { return !!(it && it.w && it.w.lines && it.w.lines.some(l => l.k === 'steal')); }
  function gearValid(gear) {
    const used = {};
    for (const s of SLOTS) {
      const it = gear[s[0]]; if (!it) continue;
      const key = it.id + ':' + (it.f || 0);
      used[key] = (used[key] || 0) + 1;
      if (used[key] > (it.q || 1)) return false;
    }
    const ids = SLOTS.filter(s => s[1] === 'dofus').map(s => gear[s[0]] && gear[s[0]].id).filter(Boolean);
    if (new Set(ids).size !== ids.length) return false;
    if (gear.arme && gear.arme.w && gear.arme.w.twoHanded && gear.bouclier) return false;
    return true;
  }

  // Répartition des points : modèles testés par simulation
  function allocTemplates(total, deck, weapon, focus, archCars) {
    const w = {}; for (const c of deck.concat(weapon ? [weapon] : [])) for (const l of c.dmgLines) { const car = R.CARAC_OF_EL[l.el || 0]; w[car] = (w[car] || 0) + (l.min + l.max) / 2; }
    const ranked = CARACS.slice().sort((a, b) => (w[b] || 0) - (w[a] || 0));
    const out = [];
    const fill = (alloc, stat, budget) => { let n = 0; while (R.tierCost(R.STAT_TIERS[stat], alloc[stat] || 0, 1) <= budget) { budget -= R.tierCost(R.STAT_TIERS[stat], (alloc[stat] || 0), 1); alloc[stat] = (alloc[stat] || 0) + 1; if (++n > 5000) break; } return budget; };
    for (const vitaShare of [0, 0.25, 0.5, 1]) {
      // tout sur la meilleure carac
      let a = {}, b = total; a.vitalite = Math.floor(total * vitaShare); b -= a.vitalite; b = fill(a, ranked[0], b); a.vitalite += b; out.push(a);
      // réparti sur les 2 meilleures (paliers à 100)
      a = {}; b = total; a.vitalite = Math.floor(total * vitaShare); b -= a.vitalite;
      for (let step = 0; step < 600 && b > 0; step++) { const s = (a[ranked[0]] || 0) <= (a[ranked[1]] || 0) ? ranked[0] : ranked[1]; const c = R.tierCost(R.STAT_TIERS[s], a[s] || 0, 1); if (c > b) break; a[s] = (a[s] || 0) + 1; b -= c; }
      a.vitalite += b; out.push(a);
      // à 100 sur les 4 (palier 1:1), reste sur la meilleure
      a = {}; b = total; a.vitalite = Math.floor(total * vitaShare); b -= a.vitalite;
      for (const s of ranked) { const n = Math.min(100, b); a[s] = n; b -= n; }
      b = fill(a, ranked[0], b); a.vitalite += b; out.push(a);
    }
    if (archCars && archCars.length) {
      // caracs de l'archétype montées ensemble (les paliers rendent la répartition rentable), avec plusieurs parts de Vitalité
      for (const vitaShare of [0, 0.15, 0.3, 0.5]) {
        const a = {}; let b = total; a.vitalite = Math.floor(total * vitaShare); b -= a.vitalite;
        for (let step = 0; step < 5000 && b > 0; step++) { const s = archCars.reduce((x, y) => ((a[x] || 0) <= (a[y] || 0) ? x : y)); const c = R.tierCost(R.STAT_TIERS[s], a[s] || 0, 1); if (c > b) break; a[s] = (a[s] || 0) + 1; b -= c; }
        a.vitalite += b; out.push(a);
      }
    }
    if (focus) {
      for (const share of [0.25, 0.5, 0.75, 1]) {
        let a = {}, b = total; const fb = Math.floor(total * share);
        let spent = 0; while (spent < fb) { const c = R.tierCost(R.STAT_TIERS[focus], a[focus] || 0, 1); if (spent + c > fb) break; a[focus] = (a[focus] || 0) + 1; spent += c; }
        b -= spent; if (focus !== ranked[0]) b = fill(a, ranked[0], b); a.vitalite = (a.vitalite || 0) + b; out.push(a);
      }
    }
    return out;
  }

  function buildState(data, st, ctx) {
    const gear = SLOTS.map(s => st.gear[s[0]] ? { item: st.gear[s[0]], f: st.gear[s[0]].f || 0 } : null);
    const S = R.computeStats(gear, Object.assign({}, ctx, { alloc: st.alloc }));
    const cardsByKey = data._cardsByKey;
    const deck = st.deck.map((k, i) => R.prepCard(cardsByKey[k], 'c' + i));
    const weapon = st.gear.arme ? R.weaponCard(st.gear.arme, st.gear.arme.f || 0) : null;
    return { S, deck, weapon };
  }
  // Mémoire des évaluations : un build déjà simulé (mêmes objets, points, deck, adversaires, nombre de combats) n'est pas resimulé
  function stateKey(st) {
    const g = st.gear || {}; const gk = Object.keys(g).sort().map(k => k + ':' + (g[k] ? g[k].id + '/' + (g[k].f || 0) : '-')).join(',');
    const a = st.alloc || {}; const ak = Object.keys(a).sort().map(k => k + a[k]).join(',');
    return gk + '|' + ak + '|' + (st.deck || []).slice().sort().join(',');
  }
  function evaluate(data, st, ctx, monsters, n, objective, fight) {
    if (!data._memo || data._memoFor !== monsters) { data._memo = new Map(); data._memoFor = monsters; data._memoHits = data._memoHits || 0; }
    const mk = stateKey(st) + '#' + n + '#' + objective + '#' + JSON.stringify(fight || {}) + (fight && fight.ranked ? '#' + (st.deck || []).join(',') : '');
    const hit = data._memo.get(mk);
    if (hit) { data._memoHits++; return { r: hit.r, S: hit.S, score: hit.score }; }
    const res = evaluateRaw(data, st, ctx, monsters, n, objective, fight);
    if (data._memo.size > 30000) data._memo.clear();
    data._memo.set(mk, { r: res.r, S: res.S, score: res.score });
    return { r: res.r, S: res.S, score: res.score };
  }
  function evaluateRaw(data, st, ctx, monsters, n, objective, fight) {
    const b = buildState(data, st, ctx);
    if (monsters && monsters.scenarios) return evaluateMulti(b, ctx, monsters.scenarios, n, objective, fight);
    const r = R.runMany(Object.assign({ S: b.S, deck: b.deck, weapon: b.weapon, monsters, level: ctx.level }, fight || {}), n);
    return { r, S: b.S, score: score(r, b.S, objective) };
  }
  // Build polyvalent : moyenne pondérée sur plusieurs adversaires, en pénalisant le pire cas
  function evaluateMulti(b, ctx, scenarios, n, objective, fight) {
    const per = Math.max(30, Math.round(n / scenarios.length));
    const rs = scenarios.map(sc => R.runMany(Object.assign({ S: b.S, deck: b.deck, weapon: b.weapon, monsters: sc.monsters, level: ctx.level }, fight || {}, sc.fo || {}), per));
    const W = scenarios.reduce((a, sc) => a + (sc.w || 1), 0) || 1;
    const wavg = f => scenarios.reduce((a, sc, i) => a + (sc.w || 1) * f(rs[i]), 0) / W;
    const fin = rs.filter(r => isFinite(r.avgRounds));
    const perCard = {}; rs.forEach((r, i) => { for (const k in r.perCard) perCard[k] = (perCard[k] || 0) + r.perCard[k] * (scenarios[i].w || 1) / W; });
    const r = { n: per * rs.length, winRate: wavg(r => r.winRate), avgRounds: fin.length ? fin.reduce((a, r) => a + r.avgRounds, 0) / fin.length : Infinity, avgHpLost: wavg(r => r.avgHpLost), avgDmg: wavg(r => r.avgDmg), perCard, hist: {}, progress: wavg(r => r.progress || 0), avgKills: wavg(r => r.avgKills || 0), minWin: Math.min(...rs.map(r => r.winRate)), scenarios: rs.map((r, i) => ({ label: scenarios[i].label, winRate: r.winRate, avgRounds: r.avgRounds, avgHpLost: r.avgHpLost })) };
    const scs = rs.map(x => score(x, b.S, objective));
    const sc = scenarios.reduce((a, s, i) => a + (s.w || 1) * scs[i], 0) / W + 0.5 * Math.min(...scs);
    return { r, S: b.S, score: sc };
  }

  // opts: {optGear, optAlloc, optDeck, objective, effort(1..3), monsters, ctx, start:{gear,alloc,deck}, onProgress}
  function optimize(data, opts) {
    data._cardsByKey = data._cardsByKey || Object.fromEntries(data.cards.map(c => [c.key, c]));
    const ctx = opts.ctx, mons = opts.monsters, obj = opts.objective || 'vitesse';
    const effort = opts.effort || 2;
    const N = [80, 140, 220][effort - 1], NF = opts.NF || 2500;
    const budget = { gearIter: [120, 260, 500][effort - 1], deckIter: [40, 90, 160][effort - 1] };
    let cur = { gear: Object.assign({}, opts.start.gear), alloc: Object.assign({}, opts.start.alloc), deck: opts.start.deck.slice() };
    let ev = 0;
    const total = R.pointsTotal(ctx.level);
    const tick = (phase, done, of, best) => opts.onProgress && opts.onProgress({ phase, done, of, best, evals: ev });
    const FO = { invertFrom: opts.invertFrom || 0, invertShields: !!opts.invertShields, auto: !!opts.auto, weaponMode: opts.weaponMode, plan: (opts.effort || 2) >= 3, seed: 1 }; const SU = opts.sustain || 'all', NS = !normSus(opts.sustain, opts.noSteal).steal;
    const s0 = opts.start0 || opts.start; const start0 = { gear: Object.assign({}, s0.gear), deck: s0.deck.slice() };
    const changes = st => SLOTS.filter(([s]) => (st.gear[s] && st.gear[s].id) !== (start0.gear[s] && start0.gear[s].id)).length + st.deck.filter(k => !start0.deck.includes(k)).length;
    // Ascension : à efficacité égale, on préfère le build qui change le moins de choses
    const E = (st, n) => { ev++; const e = evaluate(data, st, ctx, mons, n || N, obj, FO); e.score -= (String(obj).startsWith('ascension') ? 3 : 1.5) * changes(st); return e; };
    const start = evaluate(data, cur, ctx, mons, NF, obj, FO);
    // Cible trop facile : tout est déjà gagné en un tour sans dégâts, les différences ne seraient que du bruit de simulation
    if ((['survie', 'vitesse', 'equilibre', 'mono', 'multi'].includes(obj) || String(obj).startsWith('ascension')) && start.r.winRate >= 0.999 && start.r.avgRounds <= 1.25 && start.r.avgHpLost / start.S._maxHp < 0.03) {
      return { start, final: start, state: cur, evals: ev, saturated: true };
    }
    if (NS && weaponSteals(cur.gear.arme)) {
      // Arme à vol de vie interdite : on la remplace par la meilleure arme sans vol de vie du stock (jamais d'emplacement vide si une arme existe)
      const g = Object.assign({}, cur.gear); delete g.arme; cur = Object.assign({}, cur, { gear: g });
      const wType = (SLOTS.find(([s]) => s === 'arme') || [])[1];
      const ws = ((itemPool(data)[wType]) || []).filter(it => (it.lvl || 0) <= ctx.level && !weaponSteals(it));
      let bw = null, bs = -Infinity;
      for (const w of ws.slice(0, 40)) { const cand = Object.assign({}, cur, { gear: Object.assign({}, cur.gear, { arme: w }) }); const e = evaluate(data, cand, ctx, mons, Math.max(40, Math.floor(N / 3)), obj, FO); ev++; if (e.score > bs) { bs = e.score; bw = w; } }
      if (bw) cur = Object.assign({}, cur, { gear: Object.assign({}, cur.gear, { arme: bw }) });
    }
    let best = E(cur);
    const owned = data.cards.filter(c => c.eff && c.eff.length);
    // Archétype d'élément imposé (recherche approfondie) : sorts de ces éléments, sorts multi-éléments (3+) et sorts utilitaires
    const ARCH = opts.arch || null;
    const archOk = c => { if (!ARCH) return true; const els = cardEls(c); return !els.length || els.length >= 3 || els.every(e => ARCH.els.includes(e)); };
    const allowed = c => cardAllowed(c, obj, SU, NS) && archOk(c);
    const useful = owned.filter(c => allowed(c) && c.eff.some(l => ['dmg', 'steal', 'bomb', 'dmgCasterHp', 'buff', 'shieldHp', 'shieldLvl', 'heal', 'healPct', 'apRemove', 'apGain'].includes(l.k)));
    function deckPass(iters) {
      if (!useful.length) return;
      for (let it = 0; it < iters; it++) {
        const inC = useful[Math.floor(Math.random() * useful.length)];
        if (cur.deck.includes(inC.key)) continue;
        const d2 = cur.deck.slice();
        if (d2.length < (opts.deckSize || d2.length)) d2.push(inC.key); else d2[Math.floor(Math.random() * d2.length)] = inC.key;
        const cand = Object.assign({}, cur, { deck: d2 });
        const e = E(cand);
        if (e.score > best.score) { best = e; cur = cand; }
        if (it % 3 === 0) tick('Deck', it, iters, best);
      }
    }
    // Deck plus court : retirer une carte peut aider (on pioche plus souvent ses meilleurs sorts) ; les meilleurs decks du jeu ont 4 à 7 sorts
    function pruneDeck() {
      if (!opts.optDeck) return;
      for (let round = 0; round < 12; round++) {
        if (cur.deck.length <= (opts.minDeck || 4)) return;
        let bi = -1, be = best;
        for (let i = 0; i < cur.deck.length; i++) { const d2 = cur.deck.slice(0, i).concat(cur.deck.slice(i + 1)); const e = E(Object.assign({}, cur, { deck: d2 })); if (e.score > be.score + 0.5) { be = e; bi = i; } }
        if (bi < 0) return;
        cur = Object.assign({}, cur, { deck: cur.deck.slice(0, bi).concat(cur.deck.slice(bi + 1)) }); best = be; tick('Deck plus court', round, 12, best);
      }
    }
    // Recherche par archétype : on part des caracs de l'élément et du meilleur deck « dégâts par PA » pour ces caracs
    function cardPower(c, S) {
      let v = 0;
      for (const l of (c.eff || [])) if (l.k === 'dmg' || l.k === 'steal') { const el = l.el || 0; v += ((l.min + l.max) / 2) * (1 + ((S[R.CARAC_OF_EL[el]] || 0) + (S.puissance || 0)) / 100) + (S.dommages || 0) + (S['dommages' + R.EL_NAMES[el]] || 0); }
      return v / Math.max(1, c.ap);
    }
    if (ARCH && opts.optDeck) {
      if (opts.optAlloc) { const a = {}; let b = total; a.vitalite = Math.floor(total * 0.25); b -= a.vitalite; for (let step = 0; step < 3000 && b > 0; step++) { const s = ARCH.cars.reduce((x, y) => ((a[x] || 0) <= (a[y] || 0) ? x : y)); const c = R.tierCost(R.STAT_TIERS[s], a[s] || 0, 1); if (c > b) break; a[s] = (a[s] || 0) + 1; b -= c; } a.vitalite += b; cur = Object.assign({}, cur, { alloc: a }); }
      const S0 = buildState(data, cur, ctx).S;
      const size = opts.deckSize || cur.deck.length;
      const dmg = useful.filter(c => cardEls(c).length).sort((x, y) => cardPower(y, S0) - cardPower(x, S0));
      const util = useful.filter(c => !cardEls(c).length);
      const pickU = util.filter(c => c.eff.some(l => l.k === 'shieldHp' || l.k === 'shieldLvl' || l.k === 'apGain')).slice(0, 2);
      const d2 = dmg.slice(0, Math.max(1, size - pickU.length)).map(c => c.key).concat(pickU.map(c => c.key));
      for (const c of dmg) { if (d2.length >= size) break; if (!d2.includes(c.key)) d2.push(c.key); }
      cur = Object.assign({}, cur, { deck: d2.slice(0, size) }); best = E(cur);
    }
    // Orientation à deck contraint (mono / multi) : on remplace d'abord les cartes interdites
    const needFix = !ARCH && cur.deck.some(k => !data._cardsByKey[k] || !allowed(data._cardsByKey[k]));
    if (needFix) {
      const dmgPool = useful.filter(c => cardEls(c).length && !cur.deck.includes(c.key));
      const d2 = cur.deck.filter(k => data._cardsByKey[k] && allowed(data._cardsByKey[k]));
      while (d2.length < (opts.deckSize || cur.deck.length) && dmgPool.length) d2.push(dmgPool.splice(Math.floor(Math.random() * dmgPool.length), 1)[0].key);
      cur = Object.assign({}, cur, { deck: d2 }); best = E(cur);
      deckPass(budget.deckIter);
    }
    // Emplacements libres (ex. après un Prestige) : on les remplit avec la meilleure carte disponible
    if (opts.optDeck && opts.deckSize && cur.deck.length < opts.deckSize) {
      while (cur.deck.length < opts.deckSize) {
        const pool = useful.filter(c => !cur.deck.includes(c.key));
        if (!pool.length) break;
        const sample = pool.sort(() => Math.random() - 0.5).slice(0, 14);
        let bc = null, be = null;
        for (const c of sample) { const cand = Object.assign({}, cur, { deck: cur.deck.concat([c.key]) }); const e = E(cand, Math.max(40, Math.floor(N / 2))); if (!be || e.score > be.score) { be = e; bc = cand; } }
        if (!bc) break;
        cur = bc;
      }
      best = E(cur);
    }

    // --- 1. Points de caractéristiques ---
    const doAlloc = () => {
      if (!opts.optAlloc) return;
      const b = buildState(data, cur, ctx);
      let tpl = allocTemplates(total, b.deck, b.weapon, (ORIENT[obj] || {}).focus, ARCH && ARCH.cars);
      // archétype : les points ne vont que dans ses caracs (+ Vitalité, + carac d'orientation comme Sagesse ou Chance)
      if (ARCH) { const ok = ARCH.cars.concat(['vitalite', (ORIENT[obj] || {}).focus].filter(Boolean)); tpl = tpl.filter(a => Object.keys(a).every(k => !a[k] || ok.includes(k))); }
      if (!ARCH || Object.keys(cur.alloc).every(k => !cur.alloc[k] || ARCH.cars.includes(k) || k === 'vitalite' || k === 'sagesse')) tpl.push(Object.assign({}, cur.alloc));
      let i = 0;
      for (const a of tpl) {
        const cand = Object.assign({}, cur, { alloc: a });
        const e = E(cand);
        if (e.score > best.score) { best = e; cur = cand; }
        tick('Points de caractéristiques', ++i, tpl.length, best);
      }
      // affinage point par point : on déplace des paquets de points entre caracs utiles tant que ça améliore
      const keys = [...new Set(['vitalite'].concat(ARCH ? ARCH.cars : CARACS.filter(k => (cur.alloc[k] || 0) > 0 || k === (ORIENT[obj] || {}).focus)))].filter(Boolean);
      for (const step of [60, 25]) {
        let improved = true, guard = 0;
        while (improved && guard++ < 4) {
          improved = false;
          for (const from of keys) for (const to of keys) {
            if (from === to || (cur.alloc[from] || 0) < step) continue;
            const a = Object.assign({}, cur.alloc); a[from] -= step;
            // les points libérés sont réinvestis dans « to » au coût des paliers
            let pts = R.tierCost(R.STAT_TIERS[from], a[from], step), n = 0;
            while (pts > 0) { const c = R.tierCost(R.STAT_TIERS[to], (a[to] || 0), 1); if (c > pts) break; a[to] = (a[to] || 0) + 1; pts -= c; if (++n > 2000) break; }
            if (pts > 0) a.vitalite = (a.vitalite || 0) + pts;
            const cand = Object.assign({}, cur, { alloc: a }); const e = E(cand);
            if (e.score > best.score + 0.5) { best = e; cur = cand; improved = true; }
          }
        }
      }
    };
    doAlloc();

    // --- 2. Équipement (recuit simulé sur les meilleurs candidats par emplacement) ---
    const gearStage = () => { if (!opts.optGear) return;
      const pool = itemPool(data);
      const b = buildState(data, cur, ctx);
      const wts = orientWeights(statWeights(b.deck, b.weapon, b.S, obj === 'survie' || obj === 'equilibre' || obj === 'ascension' || obj === 'ascension-tank'), obj);
      const cands = {};
      for (const [slot, type] of SLOTS) {
        const list = (pool[type] || []).filter(it => (it.lvl || 0) <= ctx.level && !(NS && it.w && it.w.lines.some(l => l.k === 'steal')));
        // objets dominés : un autre objet du même emplacement fait au moins aussi bien sur chaque stat (hors armes et panoplies) → inutile de les tester
        const pruned = list.filter(it => it.w || it.setId || (it.s === 'dofus' && Object.keys(R.dofusFx([it.n || ''])).length) || !list.some(o => o !== it && !o.w && dominates(o, it)));
        pruned.sort((x, y) => itemHeur(y, wts) - itemHeur(x, wts));
        cands[slot] = pruned.slice(0, type === 'dofus' ? 12 : 10);
        // Dofus à effet spécial : leurs stats seules ne disent rien, on les teste toujours en simulation
        if (type === 'dofus') for (const it of list) if (Object.keys(R.dofusFx([it.n || ''])).some(k => k !== 'kaliptus' && k !== 'dofawa') && !cands[slot].includes(it)) cands[slot].push(it);
        if (cur.gear[slot] && !cands[slot].some(it => it.id === cur.gear[slot].id) && !(NS && slot === 'arme' && weaponSteals(cur.gear[slot]))) cands[slot].push(cur.gear[slot]);
      }
      // panoplies : on essaie exprès de porter ensemble les pièces possédées d'une même panoplie
      const bySet = {};
      for (const [slot, type] of SLOTS) for (const it of (pool[type] || [])) if (it.setId && (it.lvl || 0) <= ctx.level) (bySet[it.setId] = bySet[it.setId] || new Map()).set(it.id + ':' + (it.f || 0), it);
      // panoplies trop faibles (ex. bas niveau) : on ne les essaie que si leurs pièces valent au moins 60 % de ce qu'elles remplaceraient
      const curHeur = it => it ? itemHeur(it, wts) : 0;
      for (const items of Object.values(bySet)) {
        const list = [...items.values()]; if (list.length < 2) continue;
        { const h = list.reduce((a, it) => a + itemHeur(it, wts), 0); const ref = list.reduce((a, it) => { const sl = SLOTS.find(([, ty]) => ty === it.s); return a + curHeur(sl && cur.gear[sl[0]]); }, 0); if (ref > 0 && h < 0.6 * ref) continue; }
        const g2 = Object.assign({}, cur.gear); const usedSlots = new Set();
        for (const it of list.sort((a, b) => (b.f || 0) - (a.f || 0))) {
          const slot = SLOTS.find(([sl, ty]) => ty === it.s && !usedSlots.has(sl) && !(it.s === 'arme' && NS && weaponSteals(it)));
          if (!slot) continue; usedSlots.add(slot[0]); g2[slot[0]] = it;
        }
        if (usedSlots.size < 2 || !gearValid(g2)) continue;
        const cand = Object.assign({}, cur, { gear: g2 }); const e = E(cand);
        if (e.score > best.score) { best = e; cur = cand; }
      }
      // départ glouton : meilleur heuristique par emplacement si valide
      let T = 40;
      for (let it = 0; it < budget.gearIter; it++) {
        const [slot] = SLOTS[Math.floor(Math.random() * SLOTS.length)];
        const list = cands[slot]; if (!list.length) continue;
        const pick = list[Math.floor(Math.random() * list.length)];
        if (cur.gear[slot] && pick.id === cur.gear[slot].id && (pick.f || 0) === (cur.gear[slot].f || 0)) continue;
        const g2 = Object.assign({}, cur.gear, { [slot]: pick });
        if (!gearValid(g2)) continue;
        const cand = Object.assign({}, cur, { gear: g2 });
        const e = E(cand);
        if (e.score > best.score || Math.random() < Math.exp((e.score - best.score) / T)) {
          if (e.score > best.score) { best = e; cur = cand; }
        }
        T = Math.max(2, T * 0.985);
        if (it % 5 === 0) tick('Équipement', it, budget.gearIter, best);
      }
      doAlloc(); // les caracs dépendent du stuff
    };
    gearStage();

    // --- 3. Deck (échanges gloutons) ---
    if (opts.optDeck) { deckPass(budget.deckIter); pruneDeck(); if (opts.optAlloc) doAlloc(); }
    // Passes supplémentaires : équipement, caracs et sorts se répondent (nouveau deck → nouveaux objets utiles → …)
    for (let p = 1; p < (opts.passes || 1); p++) { tick('Passe ' + (p + 1), p, opts.passes, best); gearStage(); if (opts.optDeck) { deckPass(budget.deckIter); pruneDeck(); if (opts.optAlloc) doAlloc(); } }

    // --- 4. Emplacements restés vides : plus rien n'y améliore le combat, mais un objet utile hors combat vaut mieux que rien
    //     (prospection pour le butin, sagesse pour l'XP, puis vitalité), à condition de ne rien perdre en combat.
    if (opts.optGear && opts.fillEmpty !== false) fillEmpty();
    function fillEmpty() {
      const pool = itemPool(data), filled = [];
      const util = it => { const t = it.st || {}; const pp = (t.prospection || 0) + (t.chance || 0) / 10 + (/kaliptus/i.test(it.n || '') ? 100 : 0), sg = t.sagesse || 0; // Kaliptus : +20 % de chances d'un butin de plus sur les boss
        return obj === 'sagesse' ? sg * 2 + pp : pp * 2 + sg + 0.05 * (t.vitalite || 0) + 0.01 * Object.values(t).reduce((a, v) => a + Math.max(0, v), 0); };
      let base = evaluate(data, cur, ctx, mons, N, obj, FO).score;
      for (const [slot, type] of SLOTS) {
        if (cur.gear[slot]) continue;
        const usedIds = new Set(SLOTS.map(([sl]) => cur.gear[sl] && cur.gear[sl].id).filter(Boolean));
        const list = (pool[type] || []).filter(it => (it.lvl || 0) <= ctx.level && util(it) > 0 && !(type === 'dofus' && usedIds.has(it.id)) && !(NS && it.w && weaponSteals(it)))
          .sort((x, y) => util(y) - util(x)).slice(0, 6);
        for (const it of list) {
          const g2 = Object.assign({}, cur.gear, { [slot]: it }); if (!gearValid(g2)) continue;
          const cand = Object.assign({}, cur, { gear: g2 }); ev++;
          const e = evaluate(data, cand, ctx, mons, N, obj, FO);
          if (e.score >= base - 0.5) { cur = cand; base = Math.max(base, e.score); const t = it.st || {}; filled.push({ slot, id: it.id, n: it.n, why: /kaliptus/i.test(it.n || '') ? 'butin de boss' : (t.prospection || 0) + (t.chance || 0) / 10 >= (t.sagesse || 0) && ((t.prospection || 0) || (t.chance || 0)) ? 'prospection' : (t.sagesse || 0) ? 'sagesse' : 'vitalité' }); break; }
        }
      }
      if (filled.length) cur = Object.assign({}, cur, { _filled: filled });
    }
    // --- 5. Ordre de l'Auto (page Deck, « Régler un ordre ») : en mode Auto, on cherche la meilleure priorité des sorts
    //     et on compare avec « sans ordre » (l'Auto choisit seule). L'ordre du deck = l'ordre de priorité.
    if (opts.optDeck !== false && FO.auto && cur.deck.length > 1 && opts.autoOrder !== false) orderPass();
    function orderPass() {
      const FR = Object.assign({}, FO, { ranked: true });
      const evR = d => { ev++; return evaluate(data, Object.assign({}, cur, { deck: d }), ctx, mons, N, obj, FR).score; };
      const free = evaluate(data, cur, ctx, mons, N, obj, FO).score;
      const cards = cur.deck.map(k => data._cardsByKey[k]).filter(Boolean);
      const b0 = buildState(data, cur, ctx).S;
      const kind = c => { const ks = (c.eff || []).map(l => l.k); const gain = (c.eff || []).filter(l => l.k === 'apGain').reduce((a, l) => a + (l.max || 0), 0);
        if (gain > c.ap) return 0; if (ks.includes('shieldHp') || ks.includes('shieldLvl')) return 1; if (ks.includes('buff') && !ks.some(k => k === 'dmg' || k === 'steal')) return 2; if (ks.some(k => k === 'dmg' || k === 'steal' || k === 'bomb')) return 3; return 4; };
      const dmgPerAp = c => (c.eff || []).filter(l => l.k === 'dmg' || l.k === 'steal').reduce((a, l) => a + ((l.min + l.max) / 2) * (1 + ((b0[R.CARAC_OF_EL[l.el || 0]] || 0) + (b0.puissance || 0)) / 100) * (l.zone ? 1.6 : 1), 0) / Math.max(1, c.ap);
      let order = cards.slice().sort((a, b) => kind(a) - kind(b) || dmgPerAp(b) - dmgPerAp(a)).map(c => c.key);
      let bs = evR(order);
      for (let sweep = 0; sweep < 3; sweep++) {
        let moved = false;
        for (let i = 0; i < order.length - 1; i++) { const o2 = order.slice(); [o2[i], o2[i + 1]] = [o2[i + 1], o2[i]]; const sc = evR(o2); if (sc > bs + 0.3) { bs = sc; order = o2; moved = true; } }
        // déplacer une carte tout en haut (bonus, PA, bouclier placés trop bas)
        for (let i = 1; i < order.length; i++) { const o2 = [order[i]].concat(order.slice(0, i), order.slice(i + 1)); const sc = evR(o2); if (sc > bs + 0.3) { bs = sc; order = o2; moved = true; } }
        if (!moved) break;
        tick('Ordre de l\'Auto', sweep, 3, best);
      }
      const ranked = bs > free + 0.5;
      cur = Object.assign({}, cur, { deck: order, _autoOrder: { ranked, gain: bs - free, free, ordered: bs } });
    }
    const FOF = cur._autoOrder && cur._autoOrder.ranked ? Object.assign({}, FO, { ranked: true }) : FO;
    const fin = evaluate(data, cur, ctx, mons, NF, obj, FOF);
    tick('Terminé', 1, 1, fin);
    return { state: cur, start, final: fin, evals: ev };
  }


  // ---------- Recherche approfondie : un build complet par élément, puis comparaison ----------
  // Pour chaque archétype (Terre, Feu, Eau, Air, multi-éléments, libre), on cherche ensemble caracs, équipement et sorts,
  // puis on compare les meilleurs builds de chaque archétype sur les mêmes combats.
  const ARCHS = [
    { id: 'terre', label: 'Terre (Force)', els: [0, 1], cars: ['force'] },
    { id: 'feu', label: 'Feu (Intelligence)', els: [2], cars: ['intelligence'] },
    { id: 'eau', label: 'Eau (Chance)', els: [3], cars: ['chance'] },
    { id: 'air', label: 'Air (Agilité)', els: [4], cars: ['agilite'] },
    { id: 'multi', label: 'Multi-éléments (sorts multi + 4 caracs)', els: [0, 1, 2, 3, 4], cars: ['force', 'intelligence', 'chance', 'agilite'] }
  ];
  function sanitizeSeed(data, opts) {
    const sd = opts.seed; if (!sd || !sd.gear || !sd.deck || !opts.start) return null;
    const own = new Set(data.items.concat(data.worn || []).map(i => i.id));
    const gear = {}; let kept = 0;
    for (const [slot] of SLOTS) { const it = sd.gear[slot]; if (it && own.has(it.id)) { gear[slot] = it; kept++; } else gear[slot] = opts.start.gear[slot]; }
    const deck = sd.deck.filter(k => data._cardsByKey[k]); for (const k of opts.start.deck) if (deck.length < (opts.deckSize || opts.start.deck.length) && !deck.includes(k)) deck.push(k);
    const alloc = sd.alloc && R.allocCost(sd.alloc) <= R.pointsTotal(opts.ctx.level) ? sd.alloc : opts.start.alloc;
    return kept ? { gear, alloc, deck } : null;
  }
  // Liste des recherches (une par archétype d'élément) ; partagée entre le calcul en une fois et le calcul réparti sur plusieurs cœurs
  function deepRuns(data, opts) {
    data._cardsByKey = data._cardsByKey || Object.fromEntries(data.cards.map(c => [c.key, c]));
    const o = ORIENT[opts.objective] || {};
    const owned = data.cards.filter(c => c.eff && c.eff.length && sustainAllowed(c, opts.sustain, opts.noSteal));
    const count = a => owned.filter(c => { const e = cardEls(c); return e.length && (e.length >= 3 || e.every(x => a.els.includes(x))); }).length;
    const multiCount = owned.filter(c => cardEls(c).length >= 3).length;
    let archs = ARCHS.filter(a => a.id === 'multi' ? multiCount >= 2 : count(a) >= 4);
    if (o.el !== undefined) archs = archs.filter(a => a.els.includes(o.el));           // orientation mono : seulement l'élément choisi
    if (opts.objective === 'multi') archs = archs.filter(a => a.id === 'multi');
    const runs = [{ id: 'libre', label: 'Libre (sans contrainte d\'élément)', arch: null }].concat(archs.map(a => ({ id: a.id, label: a.label, arch: a })));
    // Reprise : le dernier build trouvé (mémorisé par le Labo) sert de point de départ supplémentaire, s'il est encore possible
    const seed = sanitizeSeed(data, opts);
    if (seed) runs.unshift({ id: 'memo', label: 'Reprise du dernier build trouvé', arch: null, start: seed });
    return runs;
  }
  const FINAL_FO = opts => ({ invertFrom: opts.invertFrom || 0, invertShields: !!opts.invertShields, auto: !!opts.auto, weaponMode: opts.weaponMode, plan: true, seed: 7919 }); // autre graine que la recherche : pas de build « chanceux »
  // Une partie des recherches (ids), avec confirmation (Approfondi) et vérification sur 2 500 combats de ses meilleurs résultats
  function deepPart(data, opts, ids, keep) {
    data._cardsByKey = data._cardsByKey || Object.fromEntries(data.cards.map(c => [c.key, c]));
    const all = deepRuns(data, opts); const runs = ids ? all.filter(r => ids.includes(r.id)) : all;
    const passes = opts.effort >= 3 ? 2 : 1;
    let evals = 0, results = [];
    runs.forEach((run, i) => {
      const r = optimize(data, Object.assign({}, opts, run.start ? { start: run.start, start0: opts.start } : {}, { arch: run.arch, passes, NF: opts.NFdeep || 600, onProgress: p => opts.onProgress && opts.onProgress(Object.assign({}, p, { phase: `${run.label} (${i + 1}/${runs.length}) · ${p.phase}`, done: i + Math.min(1, (p.done || 0) / Math.max(1, p.of || 1)), of: runs.length + 1 })) }));
      evals += r.evals || 0;
      results.push(Object.assign({ id: run.id, label: run.label }, r));
    });
    if (results.some(r => r.saturated)) return { results: results.filter(r => r.saturated).slice(0, 1), evals, saturated: true };
    results.sort((a, b) => b.final.score - a.final.score);
    if (opts.effort >= 3) {
      for (const r of results.slice(0, 2)) {
        const run = runs.find(x => x.id === r.id);
        const r2 = optimize(data, Object.assign({}, opts, { arch: run.arch, passes: 1, NF: 600, start: { gear: r.state.gear, alloc: r.state.alloc, deck: r.state.deck }, onProgress: p => opts.onProgress && opts.onProgress(Object.assign({}, p, { phase: `Confirmation · ${run.label} · ${p.phase}`, done: runs.length, of: runs.length + 1 })) }));
        evals += r2.evals || 0;
        r.confirmed = r2.final.score <= r.final.score + 5;
        if (r2.final.score > r.final.score) { r.state = r2.state; r.final = r2.final; }
      }
    }
    const FO = FINAL_FO(opts);
    for (const r of results.slice(0, keep || 3)) r.final = evaluate(data, r.state, opts.ctx, opts.monsters, 2500, opts.objective, r.state._autoOrder && r.state._autoOrder.ranked ? Object.assign({}, FO, { ranked: true }) : FO);
    return { results, evals };
  }
  function deepStart(data, opts) { data._cardsByKey = data._cardsByKey || Object.fromEntries(data.cards.map(c => [c.key, c])); return evaluate(data, { gear: opts.start.gear, alloc: opts.start.alloc, deck: opts.start.deck }, opts.ctx, opts.monsters, 2500, opts.objective, FINAL_FO(opts)); }
  // Assemble les résultats (d'un ou plusieurs cœurs) au format habituel
  function deepMerge(parts, start, opts) {
    let evals = 0; let results = [];
    for (const p of parts) { evals += p.evals || 0; results = results.concat(p.results); }
    const sat = parts.find(p => p.saturated); if (sat) return Object.assign(sat.results[0], { evals });
    results.sort((a, b) => (b.final.r.n >= 2000) - (a.final.r.n >= 2000) || b.final.score - a.final.score);
    const best = results[0];
    opts.onProgress && opts.onProgress({ phase: 'Terminé', done: 1, of: 1, evals });
    return { state: best.state, start, final: best.final, evals, archetype: best.label,
      archs: results.map(r => ({ id: r.id, label: r.label, state: r.state, confirmed: r.confirmed, score: r.final.score, winRate: r.final.r.winRate, avgRounds: r.final.r.avgRounds, avgHpLost: r.final.r.avgHpLost, maxHp: r.final.S._maxHp, verified: r.final.r.n >= 2000 })) };
  }
  function optimizeDeep(data, opts) {
    data._cardsByKey = data._cardsByKey || Object.fromEntries(data.cards.map(c => [c.key, c]));
    if ((opts.effort || 2) <= 1 || !opts.optDeck) return optimize(data, opts);
    const part = deepPart(data, opts, null, 4);
    if (part.saturated) return deepMerge([part], null, opts);
    return deepMerge([part], deepStart(data, opts), opts);
  }

  // ---------- Codes de partage du jeu (DM-E équipement, DM-S deck) ----------
  const B32 = '0123456789ABCDEFGHJKMNPQRSTVWXYZ';
  function fnv1a(bytes) { let h = 0x811c9dc5; for (const c of bytes) { h ^= c; h = Math.imul(h, 0x01000193) >>> 0; } return h >>> 0; }
  function varint(n, out) { do { let b = n & 0x7f; n = Math.floor(n / 128); if (n) b |= 0x80; out.push(b); } while (n); }
  function toB32(bytes) { let bits = ''; for (const b of bytes) bits += b.toString(2).padStart(8, '0'); while (bits.length % 5) bits += '0'; let s = ''; for (let i = 0; i < bits.length; i += 5) s += B32[parseInt(bits.slice(i, i + 5), 2)]; return s; }
  function fromB32(s) { let bits = ''; for (const ch of s) { const i = B32.indexOf(ch); if (i < 0) throw new Error('caractère invalide « ' + ch + ' »'); bits += i.toString(2).padStart(5, '0'); } const out = []; for (let i = 0; i + 8 <= bits.length; i += 8) out.push(parseInt(bits.slice(i, i + 8), 2)); return out; }
  function checksum(kind, bytes) { const h = fnv1a([kind.charCodeAt(0)].concat(bytes)); let v = (h >>> 12) & 0xfffff, s = ''; for (let i = 0; i < 4; i++) { s = B32[v % 32] + s; v = Math.floor(v / 32); } return s; }
  function pack(kind, bytes) { return 'DM-' + kind + '-' + toB32(bytes) + '-' + checksum(kind, bytes); }
  function encodeGear(gear) {
    const pairs = []; SLOTS.forEach(([slot], i) => { const it = gear[slot]; if (it) pairs.push([i * 8 + Math.min(7, it.f || 0), it.id]); });
    const b = [2]; varint(pairs.length, b); for (const [k, id] of pairs) { varint(k, b); varint(id, b); } return pack('E', b);
  }
  function encodeDeck(keys, breedId) { const b = [2]; varint(breedId || 0, b); varint(keys.length, b); for (const k of keys) varint(parseInt(k, 10), b); return pack('S', b); }
  function decodeCode(code) {
    const m = String(code).trim().toUpperCase().match(/^DM-([A-Z])-([0-9A-Z]+)-([0-9A-Z]{4})$/);
    if (!m) throw new Error('format attendu : DM-E-… ou DM-S-…');
    const bytes = fromB32(m[2]);
    if (checksum(m[1], bytes) !== m[3]) throw new Error('code abîmé (somme de contrôle invalide)');
    let i = 0; const rd = () => { let v = 0, sh = 0, x; do { x = bytes[i++]; v += (x & 0x7f) * Math.pow(2, sh); sh += 7; } while (x & 0x80); return v; };
    const ver = bytes[i++];
    if (m[1] === 'E') { const n = rd(); const items = []; for (let k = 0; k < n; k++) { const sf = rd(), id = rd(); items.push({ slot: SLOTS[sf >> 3] ? SLOTS[sf >> 3][0] : null, f: sf & 7, id }); } return { kind: 'E', ver, items }; }
    if (m[1] === 'S') { const breedId = rd(), n = rd(); const ids = []; for (let k = 0; k < n; k++) ids.push(rd()); return { kind: 'S', ver, breedId, ids }; }
    throw new Error('type de code inconnu : ' + m[1]);
  }


  // ---------- Valeur d'un objet (tier list, Banque) ----------
  // Modèle tiré des formules du moteur : dégâts par tour (Off) et PV effectifs (Def) d'un perso de référence
  // du niveau de l'objet, puis gain relatif quand on lui ajoute l'objet. Valeur = 100·[ln(Off'/Off) + λ·ln(Def'/Def)].
  const IV_CAR = ['force', 'force', 'intelligence', 'chance', 'agilite'], IV_DOM = ['dommagesNeutre', 'dommagesTerre', 'dommagesFeu', 'dommagesEau', 'dommagesAir'];
  const IV_RES = ['resPctNeutre', 'resPctTerre', 'resPctFeu', 'resPctEau', 'resPctAir'], IV_RFX = ['resNeutre', 'resTerre', 'resFeu', 'resEau', 'resAir'];
  const IV_PREST = [{ pa: 1 }, { po: 2 }, { pm: 2 }, { pa: 1 }, { po: 3 }, { pm: 3 }, { pa: 1 }], IV_CAPS = [[2, 13], [5, 14], [8, 15]];
  // Profil d'un perso : répartition élémentaire de ses dégâts (deck actif), dégâts de base par PA, coût moyen d'une carte
  function valueProfile(cards, deck, meta) {
    const byKey = {}; for (const c of cards || []) byKey[c.key] = c;
    const w = [0, 0, 0, 0, 0]; let base = 0, ap = 0, n = 0;
    for (const k of deck || []) {
      const c = byKey[k]; if (!c) continue;
      const ls = (c.eff || []).filter(l => l.k === 'dmg' || l.k === 'steal' || l.k === 'bomb'); if (!ls.length) continue;
      for (const l of ls) { const b = ((l.min || 0) + (l.max || 0)) / 2; w[l.el || 0] += b; base += b; }
      ap += c.ap || 0; n++;
    }
    const tw = w.reduce((a, b) => a + b, 0);
    if (!tw) { const car = (meta && meta.rows || []).reduce((o, r) => (o[r.key] = r.base || 0, o), {}); IV_CAR.forEach((k, i) => { if (i) w[i] = car[k] || 0; }); }
    const t2 = w.reduce((a, b) => a + b, 0) || 1;
    return { w: w.map(x => x / t2), bap: ap ? base / ap : 15, avgAP: n ? ap / n : 3, breedId: meta && meta.breedId, prestige: (meta && meta.prestige) || 0, discord: 1 + ((meta && meta.discordBonus) || 0) / 100 };
  }
  function valueRef(L, P) {
    const f = Math.max(0.05, L / 200), pm = (1 + 0.25 * P.prestige) * P.discord;
    const S = { puissance: 280 * f * pm, dommages: 20 * f * pm, critique: 30 * f * pm + 5, dommagesCritiques: 50 * f * pm, vitalite: 3000 * f * pm, pa: Math.round(3 * f), pm: Math.round(1 * f), po: Math.round(2 * f) };
    IV_CAR.forEach(k => { S[k] = 250 * f * pm + 300 * f; }); IV_DOM.forEach(k => { S[k] = 60 * f * pm; });
    IV_RES.forEach(k => { S[k] = 18 * f * pm; }); IV_RFX.forEach(k => { S[k] = 10 * f * pm; });
    for (let i = 0; i < Math.min(P.prestige, IV_PREST.length); i++) for (const k in IV_PREST[i]) S[k] += IV_PREST[i][k];
    return { S, L, pm };
  }
  function valueOff(S, L, P, weapon, pm) {
    let cap = 12; for (const [p, c] of IV_CAPS) if (P.prestige >= p) cap = Math.max(cap, c);
    const PAt = Math.min(cap, (L >= 100 ? 7 : 6) + (S.pa || 0));
    const cc = Math.min(1, Math.max(0, (S.critique || 0) / 100));
    const sp = Math.min(60, (P.breedId === 9 ? 26 : 0) + 0.4 * (S.po || 0)) / 100;
    const pen = Math.min(50, (S.dmgPctDistance || 0) + (S.dmgPctMelee || 0)) * 0.8 / 100;
    const glob = (1 + sp) * (1 + (S.dmgPctSorts || 0) / 100) * (1 - 0.2 * (1 - pen)) / 0.8;
    const M = e => (1 + Math.max(0, (S[IV_CAR[e]] || 0) + (S.puissance || 0)) / 100) * (1 + 0.2 * cc);
    const F = e => (S.dommages || 0) + (S[IV_DOM[e]] || 0) + cc * (S.dommagesCritiques || 0);
    let perPA = 0; for (let e = 0; e < 5; e++) if (P.w[e]) perPA += P.w[e] * (P.bap * M(e) + F(e) / P.avgAP);
    let off = PAt * perPA * glob;
    if (weapon && weapon.lines) {
      let wt = 0; for (const l of weapon.lines) if (l.k === 'dmg' || l.k === 'steal') { const e = l.el || 0; wt += (((l.min || 0) + (l.max || 0)) / 2) * M(e) * (1 + 0.2 * Math.min(1, (weapon.cc || 0) / 100)) + F(e); }
      wt *= glob * (weapon.perTurn || 1) * (1 + (S.dmgPctArmes || 0) / 100) / (1 + (S.dmgPctSorts || 0) / 100);
      off += Math.max(0, wt - (weapon.ap || 0) * (weapon.perTurn || 1) * off / PAt);
    }
    return off;
  }
  function valueDef(S, L) {
    const hp = 50 + 5 * L + (S.vitalite || 0), A = Math.max(60, 4 * L);
    const res = IV_RES.reduce((a, k) => a + Math.min(50, Math.max(-50, S[k] || 0)), 0) / 500;
    const fix = IV_RFX.reduce((a, k) => a + (S[k] || 0), 0) / 5;
    const dodge = Math.min(50, Math.max(0, 3 + (S.pm || 0))) / 100, red = Math.min(50, (S.resPctDistance || 0) + (S.resPctMelee || 0)) / 100;
    const hit = Math.max(A * 0.05, A * (1 - red) - fix) * (1 - res) * (1 - dodge);
    return hp / hit;
  }
  const IV_UNSC = ['pa', 'pm', 'po', 'invocations'], IV_CAP3 = ['dmgPctDistance', 'dmgPctMelee', 'resPctDistance', 'resPctMelee'];
  // it : objet (st, w, lvl) ; P : profil ; o.level : niveau du perso de référence (défaut : niveau de l'objet) ; o.lambda : poids de la survie
  function itemValue(it, P, o) {
    o = o || {};
    const L = Math.max(1, Math.min(200, o.level || it.lvl || 1)), lam = o.lambda == null ? 0.6 : o.lambda;
    const R0 = valueRef(L, P), S0 = R0.S, S1 = Object.assign({}, S0), parts = {};
    const st = it.f ? R.itemStats(it, it.f) : (it.st || {}), wpn = it.w && it.f ? R.weaponWithFusion(it.w, it.f) : it.w;
    for (const [k, v] of Object.entries(st)) { const x = IV_UNSC.includes(k) ? v : IV_CAP3.includes(k) ? (v > 0 ? v * Math.min(3, R0.pm) : 0) : v * R0.pm; S1[k] = (S1[k] || 0) + x; }
    const o0 = valueOff(S0, L, P, null), d0 = valueDef(S0, L);
    const o1 = valueOff(S1, L, P, wpn || null), d1 = valueDef(S1, L);
    const off = 100 * Math.log(o1 / o0), def = 100 * Math.log(d1 / d0);
    return { v: off + lam * def, off, def };
  }
  const api = { statWeights, valueProfile, itemValue, optimizeDeep, deepRuns, deepPart, deepStart, deepMerge, ARCHS, weaponSteals, normSus, encodeGear, encodeDeck, decodeCode, sustainAllowed, SLOTS, ORIENT, optimize, evaluate, buildState, itemPool, allocTemplates, score, cardAllowed };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.OPT = api;
})(typeof self !== 'undefined' ? self : this);
