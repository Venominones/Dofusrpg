# Labo RpgMasters — sources

- `engine.js` : moteur de combat (formules, simulation)
- `optimizer.js` : optimiseur (builds, Ascension) + valeur des objets (tier list, Banque)
- `template.html` : interface du Labo, remplie par build.py
- `labo-rpgmasters.user.js` : script Tampermonkey (lecture seule), moteur injecté par build.py
- `data.json` : instantané embarqué (perso principal)
- `build.py` : `python3 build.py` → labo.html (perso), labo-public.html, site/index.html + site/labo-rpgmasters.user.js
- `tests/` : vérifications (node + jsdom) et calibration (`node cal8.js export.json`, `node caldef.js export.json`)
