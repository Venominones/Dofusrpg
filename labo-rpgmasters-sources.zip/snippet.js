// Labo RpgMasters — export en lecture seule (Inventaire, Deck, Personnage)
(async () => {
  const rsc = async (path) => {
    const h = await fetch(path, { credentials: 'include' }).then(r => r.text());
    const txt = [...h.matchAll(/self\.__next_f\.push\(\[1,"((?:[^"\\]|\\.)*)"\]\)/g)].map(m => JSON.parse('"' + m[1] + '"')).join('');
    const rows = {};
    for (const l of txt.split('\n')) { const m = l.match(/^([0-9a-f]+):([\[{].*)$/); if (m) { try { rows[m[1]] = JSON.parse(m[2]); } catch (e) {} } }
    const res = (v) => { if (typeof v === 'string' && /^\$[0-9a-f]+:/.test(v)) { const p = v.slice(1).split(':'); let c = rows[p[0]]; for (const k of p.slice(1)) c = (Array.isArray(c) && c[0] === '$' && k === 'props') ? c[3] : c?.[k]; return c; } return v; };
    const deep = (v, d = 0) => { v = res(v); if (d > 9 || !v || typeof v !== 'object') return v; if (Array.isArray(v)) return v.map(x => deep(x, d + 1)); const o = {}; for (const k in v) o[k] = deep(v[k], d + 1); return o; };
    const found = [];
    const walk = (v, d) => { if (d > 16 || !v || typeof v !== 'object') return; if (Array.isArray(v) && v[0] === '$' && v[3] && typeof v[3] === 'object') found.push(v[3]); (Array.isArray(v) ? v : Object.values(v)).forEach(x => walk(x, d + 1)); };
    Object.values(rows).forEach(v => walk(v, 0));
    return { find: (pred) => { const p = found.find(pred); return p ? deep(p) : null; } };
  };
  const inv = await rsc('/inventaire'), deck = await rsc('/deck'), perso = await rsc('/personnage');
  const I = inv.find(p => p.entries && p.slots);
  const D = deck.find(p => p.collection && p.initialDecks);
  const P = perso.find(p => p.rows && 'pointsFree' in p);
  const H = perso.find(p => 'prestige' in p && 'level' in p && 'equipped' in p) || {};
  if (!I || !D || !P) { console.error('Labo : page introuvable, es-tu connecté ?'); return; }
  const it = (x) => ({ id: x.item.id, n: x.item.n, lvl: x.item.lvl, s: x.item.s, r: x.item.r, setId: x.item.setId || null, st: x.item.st, w: x.item.w || null });
  const out = {
    meta: {
      level: I.level || 200, prestige: H.prestige ?? 0, breedId: D.breedId, deckSize: D.deckSize, discordBonus: 5,
      scrolls: I.scrollValues || {}, rows: P.rows.map(r => ({ key: r.key, base: r.base, bonus: r.bonus, tiers: r.tiers })), pointsFree: P.pointsFree,
      decks: D.initialDecks, deckNames: D.initialNames, active: D.initialActive
    },
    worn: I.slots.filter(s => s.item).map(s => Object.assign(it(s), { slot: s.slot, f: s.fusion })),
    items: I.entries.map(e => Object.assign(it(e), { f: e.fusion, q: e.qty })),
    cards: D.collection.map(c => ({ key: c.key, id: c.card.id, n: c.card.n, ap: c.card.ap, cc: c.card.cc, cls: c.card.cls, r: c.card.r, f: c.card.f, eff: c.card.eff, crit: c.card.crit || null, sig: !!c.card.sig, d: (c.card.d || '').slice(0, 180) }))
  };
  const json = JSON.stringify(out);
  try { copy(json); console.log('Labo : export copié (' + out.items.length + ' objets, ' + out.cards.length + ' cartes). Colle-le dans le Labo.'); }
  catch (e) { console.log(json); console.log('Labo : copie la ligne ci-dessus.'); }
})();
