// RpgMasters — moteur de simulation (reconstitué à partir des échanges observés)
// Utilisable dans le navigateur (window.RPG) et dans Node (module.exports).
(function (root) {
  'use strict';

  // ---------- Constantes du jeu (lues dans le bundle client) ----------
  const FUSION_BONUS = [0, 10, 20, 25, 30, 35, 40, 45];
  const FUSION_EXCLUDED = ['pa', 'pm', 'po', 'invocations'];
  const NOT_SCALED = ['pa', 'pm', 'po', 'invocations'];
  const CARAC_OF_EL = ['force', 'force', 'intelligence', 'chance', 'agilite'];
  const EL_NAMES = ['Neutre', 'Terre', 'Feu', 'Eau', 'Air'];
  const RES_FIX = ['resNeutre', 'resTerre', 'resFeu', 'resEau', 'resAir'];
  const RES_PCT = ['resPctNeutre', 'resPctTerre', 'resPctFeu', 'resPctEau', 'resPctAir'];
  const PRESTIGE_COMBAT = [{ pa: 1 }, { po: 2 }, { pm: 2 }, { pa: 1 }, { po: 3 }, { pm: 3 }, { pa: 1 }];
  // Sorts de zone : la cible principale prend 100 %, chaque autre cible 60 % (mesuré dans le journal, résistances retirées)
  // critiques des monstres : fréquence observée dans le journal, multiplicateur supposé égal à celui du joueur
  const MON_CRIT_P = 0.06, MON_CRIT_MULT = 1.2;
  let ZONE_SEC = 0.6, WEAPON_LAST = false, WEAPON_MODE = 'normal';
  let AUTO_ORDER = 'eff';
  const CAP3 = ['dmgPctDistance', 'dmgPctMelee', 'resPctDistance', 'resPctMelee'];
  const PA_CAPS = [[2, 13], [5, 14], [8, 15]];
  const SUSTAIN = { maxPctHp: 25, perTurn: 2 };
  const RES_PCT_CAP_PLAYER = 50;
  const HAND_SIZE = 5;
  const DRAWS_MAX = 3;
  const CLASS_SPECTRAL = { 9: 26 }; // Crâ : Œil de lynx (patch du 10/10 : 18 → 26 %, plafond 60 %)
  // Passifs de classe observés en combat : 8 = « Enchaînement » (+15 % sur les sorts de dégâts suivants du tour, cumulable)
  const CLASS_PASSIVE = { 8: { chainPct: 15 } };
  // Passifs de classe (texte du client, patch du 10/10) — clé par breedId
  const BREED_KEY = { 1: 'feca', 2: 'osamodas', 3: 'enutrof', 4: 'sram', 5: 'xelor', 6: 'ecaflip', 7: 'eniripsa', 8: 'iop', 9: 'cra', 10: 'sadida', 11: 'sacrieur', 12: 'pandawa', 13: 'roublard', 14: 'zobal', 15: 'steamer', 16: 'eliotrope', 17: 'huppermage', 18: 'ouginak', 20: 'forgelance' };
  const BREED_NAME = { 1: 'Féca', 2: 'Osamodas', 3: 'Enutrof', 4: 'Sram', 5: 'Xélor', 6: 'Ecaflip', 7: 'Eniripsa', 8: 'Iop', 9: 'Crâ', 10: 'Sadida', 11: 'Sacrieur', 12: 'Pandawa', 13: 'Roublard', 14: 'Zobal', 15: 'Steamer', 16: 'Eliotrope', 17: 'Huppermage', 18: 'Ouginak', 20: 'Forgelance' }; const CHAIN_MAX = 3; const CARACS_ALL = ['force', 'intelligence', 'chance', 'agilite'];
  const SPECTRAL_PER_PO = 0.4, SPECTRAL_MAX = 60;
  const POINTS_PER_LEVEL = 5;
  const CARAC_TIERS = [[0, 1], [100, 2], [200, 3], [300, 4]];
  const STAT_TIERS = { vitalite: [[0, 1]], sagesse: [[0, 3]], force: CARAC_TIERS, intelligence: CARAC_TIERS, chance: CARAC_TIERS, agilite: CARAC_TIERS };
  // Monstres (observés)
  const INTENT_MULT = { attack: 1, heavy: 1.7, drain: 0.8 };
  // Calibré sur les journaux de combat : un critique sans valeurs critiques propres multiplie la base du sort par ~1,15
  let CRIT_MULT = 1.2;
  const RAGE_STEP = 0.3, GUARD_PCT = 0.97, WEAKEN_PER_PA = 15;

  const jsRound = Math.round;

  // ---------- Statistiques ----------
  function itemStats(it, f) {
    f = f || 0;
    if (!f) return Object.assign({}, it.st);
    const o = {};
    if (it.s === 'dofus' && f >= 7) {
      for (const k in it.st) o[k] = it.st[k] > 0 ? jsRound(it.st[k] * 2) : it.st[k];
      return o;
    }
    const m = 1 + FUSION_BONUS[Math.min(7, f)] / 100;
    for (const k in it.st) {
      const v = it.st[k];
      o[k] = v > 0 && !FUSION_EXCLUDED.includes(k) ? Math.max(v + 1, jsRound(v * m)) : v;
    }
    if (f >= 2 && it.s !== 'dofus' && (o.pa || 0) > 0) o.pa = Math.max(o.pa, 2);
    return o;
  }
  function weaponWithFusion(w, f) {
    if (!f || !w) return w;
    const m = 1 + FUSION_BONUS[Math.min(7, f)] / 100;
    const a = v => Math.max(v + 1, jsRound(v * m));
    return Object.assign({}, w, { lines: w.lines.map(l => l.k === 'apRemove' ? l : Object.assign({}, l, { min: l.min > 0 ? a(l.min) : l.min, max: l.max > 0 ? a(l.max) : l.max })) });
  }
  function tierCost(tiers, from, n) {
    let cost = 0, cur = from, left = n;
    while (left > 0) {
      let t = tiers[0];
      for (const s of tiers) if (cur >= s[0]) t = s;
      cost += t[1]; cur += 1; left -= 1;
    }
    return cost;
  }
  // Bouclier de forge (page Forgemagie, « Paliers du bouclier ») : courbe exponentielle, ×1,287 tous les 10 niveaux,
  // +1,25 % au niv. 10, +12,1 % au niv. 100, +150 % au niv. 200 (écart < 0,05 point sur les 20 paliers). Additif au Prestige, hors PA/PM/PO/invocations.
  const FORGE_K = Math.log(150 / 1.25) / 190;
  // XP de l'Infini cumulée pour atteindre chaque dizaine de niveaux (page Forgemagie) ; plafond 2 500 orbes/jour
  const FORGE_XP = { 1: 0, 10: 247, 20: 816, 30: 1606, 40: 2580, 50: 3717, 60: 5003, 70: 6428, 80: 7982, 90: 9659, 100: 11453, 110: 13359, 120: 15374, 130: 17492, 140: 19712, 150: 22029, 160: 24442, 170: 26948, 180: 29544, 190: 32229, 200: 35000 };
  function forgeXpAt(level) { const L = Math.max(1, Math.min(200, level)); const a = L <= 10 ? 1 : Math.floor(L / 10) * 10, b = Math.min(200, a === 1 ? 10 : a + 10); if (L === a) return FORGE_XP[a]; return FORGE_XP[a] + (FORGE_XP[b] - FORGE_XP[a]) * (L - a) / (b - a); }
  function forgeDaysTo(target, level, xp) { const need = Math.max(0, forgeXpAt(target) - forgeXpAt(level) - (xp || 0)); return Math.ceil(need / 2500); }
  function forgePctFor(level, known) {
    if (known != null && isFinite(known)) return known;
    const L = Math.max(0, Math.min(200, level || 0));
    return L < 1 ? 0 : Math.round(150 * Math.exp(FORGE_K * (L - 200)) * 100) / 100;
  }
  function pointsTotal(level) { return (level - 1) * POINTS_PER_LEVEL; }
  function allocCost(alloc) {
    let c = 0;
    for (const k in STAT_TIERS) c += tierCost(STAT_TIERS[k], 0, alloc[k] || 0);
    return c;
  }

  // gear : [{item, f}] ; ctx : {prestige, discordPct, scrolls, alloc, level, breedId}
  // Dofus à effet spécial (patch du 10/10) : repérés par leur nom
  const DOFUS_FX = { emeraude: /meraude/i, pourpre: /pourpre/i, turquoise: /turquoise/i, ocre: /ocre/i, vulbis: /vulbis/i, ivoire: /ivoire/i, glaces: /glace/i, ebene: /b[eè]ne/i, kaliptus: /kaliptus/i, tachete: /tachet/i, dofawa: /dofawa/i };
  function dofusFx(names) { const o = {}; for (const n of names) { if (!/dofus|dofawa|kaliptus/i.test(n)) continue; for (const [k, re] of Object.entries(DOFUS_FX)) if (re.test(n)) o[k] = true; } return o; }
  function computeStats(gear, ctx) {
    // Prestige : +25 % par Prestige ; Bouclier de forge : jusqu'à +150 % au niveau 200 (cumul supposé additif, à confirmer)
    const pMult = 1 + 0.25 * (ctx.prestige || 0) + (ctx.forgePct || 0) / 100 + (ctx.companionPct || 0) / 100; // Compagnon (patch du 10/10) : jusqu'à +100 % au niveau 400, cumul supposé additif comme le Bouclier
    const tot = {}, raw3 = {};
    for (const g of gear) {
      if (!g || !g.item) continue;
      const st = itemStats(g.item, g.f);
      for (const k in st) {
        const v = st[k];
        // Pénétration / Réduction : seuls les bonus comptent, multiplicateur total plafonné à ×3
        if (CAP3.includes(k)) { if (v > 0) raw3[k] = (raw3[k] || 0) + v; continue; }
        if (NOT_SCALED.includes(k)) { tot[k] = (tot[k] || 0) + v; continue; }
        tot[k] = (tot[k] || 0) + (v > 0 ? jsRound(v * pMult) : v);
      }
    }
    // Bonus de panoplie : traités comme un objet de plus (même effet du Prestige), palier connu le plus proche
    if (ctx.setTiers) {
      const cnt = {};
      for (const g of gear) if (g && g.item && g.item.setId) cnt[g.item.setId] = (cnt[g.item.setId] || 0) + 1;
      for (const id in cnt) {
        const tiers = ctx.setTiers[id]; if (!tiers || cnt[id] < 2) continue;
        let k = cnt[id]; while (k >= 2 && !tiers[k]) k--;
        const st = tiers[k]; if (!st) continue;
        for (const key in st) { const v = st[key]; tot[key] = (tot[key] || 0) + (NOT_SCALED.includes(key) || v <= 0 ? v : jsRound(v * pMult)); }
      }
    }
    const d = 1 + (ctx.discordPct || 0) / 100;
    const s = {};
    for (const k in tot) s[k] = (tot[k] > 0 && !NOT_SCALED.includes(k)) ? jsRound(tot[k] * d) : tot[k];
    const m3 = Math.min(3, pMult * d);
    for (const k of CAP3) if (raw3[k]) s[k] = jsRound(raw3[k] * m3);
    for (const k in (ctx.scrolls || {})) s[k] = (s[k] || 0) + (ctx.scrolls[k] || 0);
    for (const k in (ctx.alloc || {})) s[k] = (s[k] || 0) + (ctx.alloc[k] || 0);
    const pb = { pa: 0, pm: 0, po: 0 };
    for (let i = 0; i < Math.min(ctx.prestige || 0, PRESTIGE_COMBAT.length); i++) for (const k in PRESTIGE_COMBAT[i]) pb[k] += PRESTIGE_COMBAT[i][k];
    s.pa = (s.pa || 0) + pb.pa; s.pm = (s.pm || 0) + pb.pm; s.po = (s.po || 0) + pb.po;
    let cap = 12; for (const [p, c] of PA_CAPS) if ((ctx.prestige || 0) >= p) cap = Math.max(cap, c);
    s._paTotal = Math.min(cap, ((ctx.level || 200) >= 100 ? 7 : 6) + s.pa);
    s._maxHp = 50 + 5 * (ctx.level || 200) + (s.vitalite || 0);
    s._breed = ctx.breedId;
    s._spectral = Math.min(SPECTRAL_MAX, (CLASS_SPECTRAL[ctx.breedId] || 0) + SPECTRAL_PER_PO * (s.po || 0));
    s._dodge = Math.min(50, Math.max(0, 3 + (s.pm || 0)));
    // Règles de la fiche personnage
    s._pen = Math.min(50, (s.dmgPctDistance || 0) + (s.dmgPctMelee || 0)) * 0.8;   // % de résistance élémentaire ignorée
    s._red = Math.min(50, (s.resPctDistance || 0) + (s.resPctMelee || 0));          // % de dégâts subis en moins, avant résistances
    s._perfo = Math.max(0, Math.min(25, ((s.fuite || 0) + (s.tacle || 0)) * 0.05));  // % des dégâts qui traversent les boucliers ennemis
    s._ero = Math.max(0, Math.min(25, ((s.dommagesPoussee || 0) + (s.resPoussee || 0)) * 0.05)); // % des dégâts retirés aux PV max
    s._pp = 100 + (s.prospection || 0) + Math.floor((s.chance || 0) / 10);
    s._dofus = dofusFx(gear.filter(g => g && g.item && (g.item.s === 'dofus' || /dofus/i.test(g.item.n || ''))).map(g => g.item.n || ''));
    if (s._dofus.ebene) s._perfo = Math.min(32.5, s._perfo * 1.3);
    return s;
  }

  // Stats de combat telles que le jeu les envoie (combat en cours, builds enregistrés) → champs dérivés du moteur
  function deriveStats(stats, o) {
    o = o || {}; const S = Object.assign({}, stats);
    if (o.maxHp) S._maxHp = o.maxHp; if (o.basePa) S._paTotal = o.basePa; S._breed = o.breedId;
    S._dodge = Math.min(50, Math.max(0, 3 + (S.pm || 0)));
    S._spectral = Math.min(SPECTRAL_MAX, (CLASS_SPECTRAL[o.breedId] || 0) + SPECTRAL_PER_PO * (S.po || 0));
    S._pp = 100 + (S.prospection || 0) + Math.floor((S.chance || 0) / 10);
    S._pen = Math.min(50, (S.dmgPctDistance || 0) + (S.dmgPctMelee || 0)) * 0.8;
    S._red = Math.min(50, (S.resPctDistance || 0) + (S.resPctMelee || 0));
    S._perfo = Math.max(0, Math.min(25, ((S.fuite || 0) + (S.tacle || 0)) * 0.05));
    S._ero = Math.max(0, Math.min(25, ((S.dommagesPoussee || 0) + (S.resPoussee || 0)) * 0.05));
    S._dofus = dofusFx(o.dofus || []); if (S._dofus.ebene) S._perfo = Math.min(32.5, S._perfo * 1.3);
    return S;
  }

  // ---------- Dégâts ----------
  function dmgLine(S, line, crit, buffPuiss, dmgPct, spectral, resPct, withFixed, isWeapon, extra) {
    const base = line.min + RND() * (line.max - line.min + 1);
    const b = Math.min(line.max, Math.floor(base));
    const carac = (S[CARAC_OF_EL[line.el || 0]] || 0) + (S.puissance || 0) + buffPuiss + ((S._cb && S._cb[CARAC_OF_EL[line.el || 0]]) || 0);
    let fixed = 0;
    if (withFixed) fixed = (S.dommages || 0) + (S['dommages' + EL_NAMES[line.el || 0]] || 0) + (crit ? (S.dommagesCritiques || 0) : 0);
    let v = (b * (1 + carac / 100) * (crit === 'boost' ? CRIT_MULT : 1) + fixed) * (1 + ((isWeapon ? (S.dmgPctArmes || 0) : dmgPct) + (extra || 0)) / 100) * (spectral ? 2 : 1) * (1 - resPct / 100);
    return Math.max(0, Math.floor(v));
  }
  // Valeur moyenne attendue d'une ligne (pour la politique de jeu)
  function expLine(S, line, critP, buffPuiss, dmgPct, specP, resPct, withFixed, isWeapon, critLine, extra) {
    const avg = l => (l.min + l.max) / 2;
    const carac = (S[CARAC_OF_EL[line.el || 0]] || 0) + (S.puissance || 0) + buffPuiss + ((S._cb && S._cb[CARAC_OF_EL[line.el || 0]]) || 0);
    const fixed = withFixed ? (S.dommages || 0) + (S['dommages' + EL_NAMES[line.el || 0]] || 0) : 0;
    const nc = avg(line) * (1 + carac / 100) + fixed;
    const cl = critLine || line;
    const cr = avg(cl) * (1 + carac / 100) * (critLine ? 1 : CRIT_MULT) + fixed + (withFixed ? (S.dommagesCritiques || 0) : 0);
    const v = ((1 - critP) * nc + critP * cr) * (1 + ((isWeapon ? (S.dmgPctArmes || 0) : dmgPct) + (extra || 0)) / 100) * (1 + (isWeapon ? 0 : specP)) * (1 - resPct / 100);
    return Math.max(0, v);
  }

  // ---------- Préparation des cartes ----------
  function prepCard(c, uid) {
    const isDmg = l => l.k === 'dmg' || l.k === 'steal';
    // Gain de PA : immédiat (Précipitation, vérifié en jeu), sauf si la description dit « au tour suivant » (Odorat)
    const apLater = /PA au tour suivant|augmenter les PA au tour suivant/i.test(String(c.d || c.desc || ''));
    const eff = (c.eff || []).map(l => l.k === 'apGain' ? Object.assign({}, l, { now: !apLater }) : l);
    const chanceLines = eff.filter(l => l.chance);
    return {
      uid, id: c.id, name: c.n || c.name, ap: c.ap, cc: c.cc || 0, eff, crit: c.crit || null,
      weapon: !!c.weapon, chanceLines,
      dmgLines: eff.filter(isDmg),
      isSustain: eff.some(l => ['heal', 'healPct', 'shieldHp', 'shieldLvl'].includes(l.k)) && !eff.some(isDmg),
      hasDmg: eff.some(l => isDmg(l) || l.k === 'bomb' || l.k === 'dmgCasterHp'),
      isBuff: eff.some(l => l.k === 'buff') && !eff.some(isDmg),
    };
  }
  function weaponCard(item, f) {
    const w = weaponWithFusion(item.w, f);
    if (!w) return null;
    const lines = w.lines.map(l => Object.assign({ tgt: 'enemy' }, l));
    const cl = lines.map(l => l.k === 'apRemove' ? l : Object.assign({}, l, { min: l.min + (w.ccBonus || 0), max: l.max + (w.ccBonus || 0) }));
    return prepCard({ id: item.id, n: item.n, ap: w.ap, cc: w.cc, eff: lines, crit: cl, weapon: true }, 'w');
  }

  // ---------- Combat ----------
  function makeMonster(m, i) {
    const hp = Math.round((m.hpMin + m.hpMax) / 2);
    return { mech: m.mech || null, id: 'm' + i, name: m.name, hp, maxHp: hp, cap: hp, atk: m.atk, el: m.element, pattern: m.pattern, idx: (m.pattern && m.pattern.length > 1 && !m.fixedStart) ? Math.floor(RND() * m.pattern.length) : 0, /* le cycle d'intentions ne commence pas toujours au début (observé : 15 combats sur 18) */ res: m.stats || {}, rage: 0, weaken: 0, shield: 0, alive: true, isBoss: !!m.isBoss, bombs: [] };
  }

  // opts: {S, deck:[cards], weapon, monsters:[defs], maxRounds}
  function simulateFight(opts) {
    const S = opts.S, maxHp = S._maxHp;
    const P = { hp: Math.min(maxHp, opts.startHp > 0 ? opts.startHp : maxHp), shields: [], apNext: 0 };
    const mons = opts.monsters.map(makeMonster);
    let pile = shuffle(opts.deck.slice()), discard = [], hand = [];
    const shieldCap = Math.floor(maxHp * SUSTAIN.maxPctHp / 100);
    const specP = S._spectral / 100;
    let dmgDone = 0, hpLost = 0;
    const perCard = {};
    const trace = {};
    const er = r => r > 0 ? r * (1 - (S._pen || 0) / 100) : r; // Pénétration : jamais sous 0, les faiblesses restent entières
    const wMode = opts.weaponMode || (WEAPON_LAST ? 'last' : WEAPON_MODE);
    const chainPct = opts.chainPct != null ? opts.chainPct : ((CLASS_PASSIVE[S._breed] || {}).chainPct || 0);
    const T = { buffP: 0, buffC: 0, dmgPct: 0, sustainLeft: 0, weaponUsed: false, inv: false, invS: false, half: false, cards: 0, lastEl: null, round: 0 };
    const DF = S._dofus || {}; const pers = []; S._cb = {}; /* bonus qui durent plusieurs tours (Prélude au Fer, Évolution…) et caracs volées (Drain Élémentaire) */ let vulb = 0, critTurn = false, pourpreUsed = !DF.pourpre, emeraudeUsed = !DF.emeraude;
    // ----- passif de classe -----
    const PK = opts.passive !== undefined ? opts.passive : (BREED_KEY[S._breed] || null);
    const C = { n: 0, prey: null, preyN: 0, att: 0, runes: new Set(), cur: null, firstDone: false, ougPa: false, bombN: 0 };
    const missPct = () => Math.max(0, 100 - P.hp * 100 / maxHp);
    // bonus % de dégâts du passif contre m (c = carte jouée, null pour une bombe qui explose)
    const clsPct = (m, c, bomb) => {
      if (!PK) return 0; const w = c && c.weapon, cur = C.cur || {};
      switch (PK) {
        case 'feca': return 6 * C.n;
        case 'enutrof': return 5 * C.n;
        case 'xelor': return 6 * C.n;
        case 'eniripsa': return 9 * C.n;
        case 'pandawa': return 5 * C.n;
        case 'sram': { const r = m ? m.hp / m.maxHp : 1; return r < 0.25 ? 60 : r < 0.5 ? 30 : 0; }
        case 'sacrieur': return Math.min(63, 7 * Math.floor(missPct() / 10));
        case 'roublard': return (bomb ? 50 : 0) + 10 * Math.min(3, C.bombN);
        case 'zobal': { const k = (T.round - 1) % 3; return k === 0 ? 10 : k === 1 ? 25 : 0; }
        case 'steamer': return 7 * Math.min(6, Math.max(0, T.round - 1));
        case 'eliotrope': return cur.portal ? 50 : 0;
        case 'huppermage': return 11 * Math.min(4, C.runes.size);
        case 'ouginak': return m && m === C.prey ? 12 * C.preyN : 0;
        case 'forgelance': return cur.lance && !w ? 45 : 0;
      }
      return 0;
    };
    const clsTaken = () => PK === 'feca' ? 6 * C.n : PK === 'zobal' ? [10, 0, 25][(T.round - 1) % 3] : 0; // % de dégâts subis en moins
    const ECA = PK === 'ecaflip';
    const saved = () => { if (P.hp <= 0 && !emeraudeUsed) { emeraudeUsed = true; P.hp = Math.max(1, Math.round(maxHp * 0.2)); } return P.hp > 0; }; // Émeraude : survit une fois avec 20 % de PV
    // Mécaniques de boss : chaque boss encore debout applique les siennes (bestiaire + mécaniques apprises en combat)
    const alive = () => mons.filter(x => x.alive);
    const mk = (k) => { for (const m of mons) if (m.alive && m.mech && m.mech[k] != null && m.mech[k] !== false) return m.mech; return null; };
    const mv = (k, d) => { const x = mk(k); return x ? x[k] : d; };
    const every = (k, round) => k > 0 && round % k === 0;
    const rageAt = opts.rageTurn || 0;
    for (let round = 1; round <= (opts.maxRounds || 30); round++) {
      T.round = round;
      // échange de vie au début du tour
      for (const m of alive()) if (m.mech && m.mech.swapTurn === round) {
        const mp = m.hp / m.maxHp, pp = P.hp / maxHp;
        if (mp < pp) { const nm = m.mech.swapHalf ? mp + (pp - mp) / 2 : pp, np = m.mech.swapHalf ? pp - (pp - mp) / 2 : mp; m.hp = Math.max(1, Math.round(nm * m.maxHp)); const nh = Math.max(1, Math.round(np * maxHp)); if (nh < P.hp) hpLost += P.hp - nh; P.hp = nh; }
      }
      // ----- tour du joueur -----
      let ap = S._paTotal + P.apNext + (critTurn ? 1 : 0); P.apNext = 0; critTurn = false; // Turquoise : +1 PA (au-delà du plafond) le tour après un critique
      while (hand.length < HAND_SIZE + (round === 1 && DF.ocre ? 1 : 0)) { const c = draw(); if (!c) break; hand.push(c); }
      C.firstDone = false; C.ougPa = false; if (PK === 'pandawa' && C.n) P.hp = Math.min(maxHp, P.hp + Math.floor(maxHp * C.n / 100)); // Ivresse : soin non réductible
      T.buffP = 0; T.buffC = 0; T.chainN = 0; T.dmgPct = S.dmgPctSorts || 0; S._cb = {};
      for (const b of pers) if (b.until >= round) { if (b.stat === 'puissance') T.buffP += b.v; else if (b.stat === 'critique') T.buffC += b.v; else if (b.stat === 'dmgPctSorts') T.dmgPct += b.v; else S._cb[b.stat] = (S._cb[b.stat] || 0) + b.v; } T.sustainLeft = SUSTAIN.perTurn; T.weaponUsed = false; T.cards = 0; let drawsLeft = DRAWS_MAX;
      const invFrom = opts.invertFrom || mv('invertFrom', 0), sealPa = opts.sealPa || mv('sealPa', 0), sealFrom = opts.sealFrom || mv('sealFrom', 1);
      const halfFrom = mv('healHalfFrom', 0);
      T.inv = invFrom > 0 && round >= invFrom; T.invS = T.inv && !!(opts.invertShields || mv('invertShields', false)); T.seal = (sealPa > 0 && round >= sealFrom) ? sealPa : 0;
      T.half = halfFrom > 0 && round >= halfFrom;
      // vol de PA
      const stealEvery = mv('apStealEvery', 0); let tachete = !!DF.tachete; // Tacheté : annule le premier effet de contrôle du tour
      if (stealEvery ? every(stealEvery, round) : (mv('apSteal', 0) && round >= mv('apStealFrom', 1))) { if (tachete) tachete = false; else ap = Math.max(0, ap - (mv('apSteal', 0) || 1)); }
      // carte scellée pour le tour : la plus chère de la main
      const sealEvery = mv('sealEvery', 0);
      const sealOn = sealEvery ? every(sealEvery, round) : (mv('sealCard', false) && round >= mv('sealCardFrom', 1));
      const sealedCard = sealOn && hand.length && !(tachete && !(tachete = false)) ? hand.reduce((a, c) => (c.ap > a.ap ? c : a), hand[0]) : null;
      // PA comptés : finir le tour avec exactement N PA
      const paM = mk('paTurn'), paNeed = paM && paM.paTurn === round ? paM.paLeft : null;
      // Fureur : au-delà de N cartes (hors arme) dans le tour, sa prochaine attaque est multipliée
      const furyCap = Math.min(99, ...alive().filter(m => m.mech && m.mech.furyCards).map(m => m.mech.furyCards));
      // bombes posées au tour précédent
      for (const m of mons) if (m.alive && m.bombs.length) { for (const b of m.bombs) { C.cur = null; hit(m, b, 'Bombe', { bomb: true }); if (PK === 'roublard') C.bombN++; } m.bombs = []; }
      for (let guard = 0; guard < 20; guard++) {
        if (!mons.some(m => m.alive)) break;
        const cost = c => c.ap + (T.seal && !c.weapon ? T.seal : 0);
        const room = paNeed != null && !opts.auto ? ap - paNeed : ap;
        const capped = !opts.auto && T.cards >= furyCap;
        const opts2 = capped ? [] : hand.filter(c => c !== sealedCard).map(c => ({ c, v: opts.auto ? 0 : valueOf(c) })) /* en auto, l'ordre vient de rank() : inutile d'estimer chaque carte deux fois */.filter(o => cost(o.c) <= room && (opts.auto || o.v > 0));
        if (!T.weaponUsed && opts.weapon && opts.weapon.ap <= room && !(opts.auto && wMode === 'never')) { const wv = opts.auto ? 0 : valueOf(opts.weapon); if (opts.auto || wv > 0) opts2.push({ c: opts.weapon, v: wv }); }
        if (!opts2.length) {
          if (!capped && drawsLeft > 0 && hand.length < 8) { const c = draw(); drawsLeft--; if (c) { hand.push(c); continue; } }
          break;
        }
        if (opts.auto) {
          // Ordre observé du mode auto : boucliers/soins d'abord, puis dégâts du plus fort au plus faible
          // (cartes de PA au milieu), bonus purs en dernier ; il joue tout ce qui est payable, même inutile.
          const maxD = Math.max(1, ...opts2.map(o => o.c.hasDmg ? dmgCardValue(o.c, T.buffP, T.buffC, T.dmgPct) : 0));
          // Ordre réglé par le joueur (page Deck, « Ordre de l'Auto ») : premier sort utile de la liste, arme après les sorts sauf « Prioritaire »
          if (opts.ranked) { const idx = c => c.weapon ? (wMode === 'prio' ? -1 : 1e6) : (parseInt(String(c.uid).slice(1), 10) || 0); const useless = c => c.isSustain && T.sustainLeft <= 0; const rk2 = new Map(opts2.map(o => [o, useless(o.c) ? 2e6 : idx(o.c)])); opts2.sort((a, b) => rk2.get(a) - rk2.get(b)); } else {
          const rank = c => (T.sustainLeft > 0 && c.eff && c.eff.some(l => /^(shieldHp|shieldLvl|heal|healPct)$/.test(l.k))) ? 3e9
            // Réglage « Arme en auto » du jeu : Prioritaire / Normale (selon l'efficacité) / En dernier / Jamais
            : c.weapon && wMode === 'prio' ? 2e9
            : c.weapon && wMode === 'last' ? -1
            : c.hasDmg ? 1e9 + (AUTO_ORDER === 'hand' ? 1e6 - hand.indexOf(c) : AUTO_ORDER === 'eff' ? dmgCardValue(c, T.buffP, T.buffC, T.dmgPct) / Math.max(1, c.ap) : AUTO_ORDER === 'effmono' ? dmgCardValue(c, T.buffP, T.buffC, T.dmgPct, true) / Math.max(1, c.ap) : AUTO_ORDER === 'mono' ? dmgCardValue(c, T.buffP, T.buffC, T.dmgPct, true) : dmgCardValue(c, T.buffP, T.buffC, T.dmgPct))
            : (c.eff && c.eff.some(l => l.k === 'apGain' && l.now && l.max > c.ap)) ? 2.5e9 // gain de PA immédiat : d'abord, il paie les sorts suivants
            : (c.eff && c.eff.some(l => l.k === 'apGain' || l.k === 'apRemove')) ? 1e9 + (AUTO_ORDER === 'eff' ? 0 : maxD * 0.5) : 0;
          const rk = new Map(opts2.map(o => [o, rank(o.c)])); opts2.sort((a, b) => rk.get(b) - rk.get(a)); } // valeur calculée une fois par carte
        } else opts2.sort((a, b) => b.v / Math.max(1, cost(b.c)) - a.v / Math.max(1, cost(a.c)) || b.v - a.v);
        let pick = opts2[0].c;
        // À la main : rotation optimale du tour (ordre bonus → dégâts, PA gardés, arme au bon moment)
        if (!opts.auto && opts.plan !== false && opts2.length > 1) {
          const seq = planTurn(opts2.map(o => o.c), room, cost, capped ? 0 : furyCap - T.cards, paNeed != null ? paNeed : null, ap);
          if (seq && seq.length) pick = seq[0];
        }
        play(pick); passiveAfter(pick); if (chainPct && (T.chainN || 0) < CHAIN_MAX) { T.dmgPct += chainPct; T.chainN = (T.chainN || 0) + 1; } // Enchaînement (Iop) : chaque sort lancé (et l'arme, observé) +15 % aux suivants du tour, 3 fois au plus (+45 %) — texte du jeu // l'arme compte aussi dans l'Enchaînement (observé)
        if (opts.trace) (trace[round] = trace[round] || []).push(pick.name + (pick.weapon ? ' (arme)' : ''));
        if (!pick.weapon) T.cards++;
        if (T.apNow) { ap += T.apNow; T.apNow = 0; } // PA gagnés tout de suite (Précipitation)
        if (P.hp <= 0 && !saved()) return result(false, round);
        ap -= cost(pick); if (!pick.weapon) T.seal = 0;
        if (pick.weapon) T.weaponUsed = true; else { hand.splice(hand.indexOf(pick), 1); discard.push(pick); }
      }
      if (!mons.some(m => m.alive)) return result(true, round);
      // PA comptés : sinon il te pulvérise
      if (paNeed != null && ap !== paNeed && (opts.auto || ap < paNeed)) { hpLost += P.hp; P.hp = 0; return result(false, round); }
      // Fureur déclenchée ?
      for (const m of alive()) if (m.mech && m.mech.furyCards && T.cards > m.mech.furyCards) m.furyNext = Math.max(m.furyNext || 1, m.mech.furyMult || 1.5);
      // expiration boucliers
      P.shields = P.shields.filter(s => (s.turns -= 1) >= 0 && s.value > 0);
      // Rage : au tour N il t'achève
      const rg = rageAt || mv('rageTurn', 0);
      if (rg && round >= rg) { hpLost += P.hp; P.hp = 0; return result(false, round); }
      // ----- tour des monstres -----
      for (const m of mons) {
        if (!m.alive) continue;
        if (m.poison && m.poison.length) { // Sadida : poison en % des PV max au début du tour du monstre
          const pct = Math.min(m.isBoss ? 3 : 12, m.poison.length * 3); // 3 % par charge, 12 % max (boss : 3 %)
          const d = Math.min(m.hp, Math.floor(m.maxHp * pct / 100)); m.hp -= d; dmgDone += d; perCard['Poison (passif)'] = (perCard['Poison (passif)'] || 0) + d;
          m.poison = m.poison.map(x => x - 1).filter(x => x > 0);
          if (m.hp <= 0) { m.hp = 0; down(m); if (!m.alive) continue; }
        }
        const intent = m.pattern[m.idx % m.pattern.length]; m.idx++;
        m.shield = 0;
        if (intent === 'rage') { m.rage++; continue; }
        if (intent === 'guard') { m.shield = Math.round(m.atk * GUARD_PCT); continue; }
        const fury = intent === 'drain' ? 1 : (m.furyNext || 1); if (intent !== 'drain') m.furyNext = 0;
        // Fureur : observé en Ascension, le coup « déchaîné » vaut ~×fureur l'attaque de base (il remplace le bonus de l'intention)
        const mult = (fury > 1 && intent !== 'drain' ? fury : (INTENT_MULT[intent] || 1)) * (1 + RAGE_STEP * m.rage) * (1 - Math.min(100, m.weaken) / 100) * (DF.glaces && (m.glaces || 0) >= round ? 0.9 : 1); // Glaces : la cible touchée frappe 10 % moins fort pendant 2 tours
        m.weaken = 0;
        if (RND() * 100 < Math.min(DF.vulbis ? 75 : 100, S._dodge + vulb)) continue;
        if (DF.vulbis) vulb += 2; // Vulbis : +2 % d'esquive par coup non esquivé
        const rf = S[RES_FIX[m.el]] || 0, rp = Math.min(RES_PCT_CAP_PLAYER, S[RES_PCT[m.el]] || 0);
        let dmg = Math.max(0, Math.floor((m.atk * mult * (1 - (S._red || 0) / 100) * (1 - clsTaken() / 100) - rf) * (1 - rp / 100)));
        // coup critique du monstre (rare, observé ~6 %) : la Résistance Critiques retire sa valeur au coup critique reçu
        if (RND() < MON_CRIT_P) dmg = Math.max(0, Math.floor(dmg * MON_CRIT_MULT) - (S.resCritiques || 0));
        if (opts.mlog) { opts.mlog.hits = (opts.mlog.hits || 0) + 1; opts.mlog.raw = (opts.mlog.raw || 0) + dmg; if (round === 1) opts.mlog.r1 = (opts.mlog.r1 || 0) + 1; }
        for (const s of P.shields) { const a = Math.min(s.value, dmg); s.value -= a; dmg -= a; if (!dmg) break; }
        if (DF.ivoire) dmg = Math.min(dmg, Math.floor(maxHp * 0.35)); // Ivoire : aucun coup ordinaire au-delà de 35 % des PV max
        P.hp -= dmg; hpLost += dmg;
        if (intent === 'drain') m.hp = Math.min(m.cap, m.hp + dmg);
        if (S.renvoi > 0 && dmg > 0) { const r = Math.min(m.hp, S.renvoi, dmg); /* au plus les dégâts reçus */ m.hp -= r; dmgDone += r; if (m.hp <= 0) { m.hp = 0; down(m); } }
        if (P.hp <= 0 && !saved()) return result(false, round);
      }
      if (!mons.some(m => m.alive)) return result(true, round);
    }
    return result(false, opts.maxRounds || 30);

    function result(win, rounds) { const tm = mons.reduce((a, m) => a + m.maxHp, 0) || 1; return { trace, win, rounds, hpLost, dmgDone, perCard, progress: win ? 1 : 1 - mons.reduce((a, m) => a + (m.alive ? Math.max(0, m.hp) + (m.mech && m.mech.revive && !m.revived ? m.maxHp * (m.mech.revivePct != null ? m.mech.revivePct / 100 : 0.5) : 0) : 0), 0) / tm, kills: mons.filter(m => !m.alive).length }; }
    function healP(a) { if (T.inv) { P.hp -= a; hpLost += a; } else P.hp = Math.min(maxHp, P.hp + (T.half ? Math.floor(a / 2) : a)); }
    function draw() { if (!pile.length) { if (!discard.length) return null; pile = shuffle(discard); discard = []; } return pile.pop(); }
    function reflects(m) { return !!(m.mech && m.mech.reflectFrom && T.round >= m.mech.reflectFrom && (!m.mech.reflectTo || T.round <= m.mech.reflectTo)); }
    // Mode auto : le jeu vise le premier boss encore debout. Mode manuel : le plus entamé, en évitant celui qui renvoie les coups.
    function target() {
      if (opts.auto) return mons.find(m => m.alive) || null;
      let t = null; for (const m of mons) if (m.alive && !reflects(m) && (!t || m.hp < t.hp)) t = m;
      return t || mons.find(m => m.alive) || null;
    }
    function shieldTotal() { return P.shields.reduce((a, s) => a + s.value, 0); }
    function incomingNext() {
      let tot = 0;
      for (const m of mons) {
        if (!m.alive) continue;
        const intent = m.pattern[m.idx % m.pattern.length];
        if (intent === 'rage' || intent === 'guard') continue;
        const mult = (INTENT_MULT[intent] || 1) * (1 + RAGE_STEP * m.rage) * (1 - Math.min(100, m.weaken) / 100);
        const rf = S[RES_FIX[m.el]] || 0, rp = Math.min(RES_PCT_CAP_PLAYER, S[RES_PCT[m.el]] || 0);
        tot += Math.max(0, (m.atk * mult * (1 - (S._red || 0) / 100) * (1 - clsTaken() / 100) - rf) * (1 - rp / 100));
      }
      return tot;
    }
    function dmgCardValue(c, puiss, crit, dpct, mono) {
      const t = target(); if (!t) return 0;
      const critP = c.cc > 0 ? Math.min(1, (c.cc + (S.critique || 0) + crit) / 100) : 0;
      const lines = c.chanceLines.length ? [c.chanceLines[0]] : c.dmgLines;
      let v = 0, first = true;
      if (!c._clMap) { c._clMap = new Map(); for (const l of lines) c._clMap.set(l, c.crit ? c.crit.filter(x => x.k === l.k)[c.dmgLines.indexOf(l) >= 0 ? c.dmgLines.filter(x => x.k === l.k).indexOf(l) : 0] || null : null); }
      lines.forEach((l, i) => {
        const cl = c._clMap.has(l) ? c._clMap.get(l) : null;
        const withFixed = c.weapon ? true : first; first = false;
        let lv = 0;
        if (l.zone && !mono) { for (const m of mons) if (m.alive) lv += Math.min(m.hp + m.shield, (m === t ? 1 : ZONE_SEC) * expLine(S, l, critP, puiss, dpct, c.weapon ? 0 : specP, er(m.res[RES_PCT[l.el || 0]] || 0), withFixed, c.weapon, cl, estPct(m, c)) * ecaF(c)); }
        else lv = expLine(S, l, critP, puiss, dpct, c.weapon ? 0 : specP, er(t.res[RES_PCT[l.el || 0]] || 0), withFixed, c.weapon, cl, estPct(t, c)) * ecaF(c);
        v += lv;
      });
      for (const l of c.eff) if (l.k === 'bomb') v += 0.8 * expLine(S, l, 0, puiss, dpct, 0, er(t.res[RES_PCT[l.el || 0]] || 0), true, false, null, PK ? clsPct(t, null, true) : 0);
      return v;
    }
    // Recherche de la meilleure séquence de cartes pour le tour (profondeur limitée), avec les bonus appliqués aux cartes suivantes
    function planTurn(cands, apRoom, cost, cardsLeft, paNeed, apNow) {
      const tot = mons.filter(m => m.alive).reduce((a, m) => a + m.hp + m.shield, 0);
      const base = new Map(cands.map(c => [c, valueOf(c)]));
      const dmgNow = new Map(cands.map(c => [c, c.hasDmg ? Math.min(dmgCardValue(c, T.buffP, T.buffC, T.dmgPct), tot) : 0]));
      const buffOnly = c => !c.hasDmg && c.eff.every(l => l.k === 'buff' && l.tgt === 'self');
      let best = { v: -Infinity, seq: null }, nodes = 0;
      const seq = [], used = new Set();
      const rec = (apLeft, bp, bc, dp, v, dealt, nCards) => {
        if (++nodes > (opts.planNodes || 120)) return;
        const endOk = paNeed == null || apNow - (apRoom - apLeft) === paNeed || apLeft < Math.min(...cands.map(cost));
        if (seq.length && endOk && v > best.v) best = { v, seq: seq.slice() };
        for (const c of cands) {
          if (used.has(c)) continue;
          const k = cost(c); if (k > apLeft) continue;
          if (!c.weapon && nCards >= cardsLeft) continue;
          let dv, nbp = bp, nbc = bc, ndp = dp, nd = dealt;
          for (const l of c.eff) if (l.k === 'buff' && l.tgt === 'self') { if (l.stat === 'puissance') nbp += l.max; else if (l.stat === 'critique') nbc += l.max; else if (l.stat === 'dmgPctSorts') ndp += l.max; }
          if (buffOnly(c)) dv = 0;
          else if (c.hasDmg) { const raw = Math.min(dmgCardValue(c, bp, bc, dp), Math.max(0, tot - dealt)); nd += raw; dv = raw + (base.get(c) - dmgNow.get(c)); ndp += chainPct; }
          else dv = base.get(c);
          used.add(c); seq.push(c);
          rec(apLeft - k, nbp, nbc, ndp, v + dv, nd, nCards + (c.weapon ? 0 : 1));
          seq.pop(); used.delete(c);
        }
      };
      rec(apRoom, T.buffP, T.buffC, T.dmgPct, 0, 0, 0);
      return best.v > 0 ? best.seq : null;
    }
    function valueOf(c) {
      let v = 0;
      if (c.hasDmg) {
        const raw = dmgCardValue(c, T.buffP, T.buffC, T.dmgPct);
        const tot = mons.filter(m => m.alive).reduce((a, m) => a + m.hp + m.shield, 0);
        v += Math.min(raw, tot);
      }
      for (const l of c.eff) {
        if (l.k === 'buff' && l.tgt === 'self') {
          const others = hand.filter(h => h !== c && h.hasDmg);
          if (!others.length && !(opts.weapon && !T.weaponUsed)) continue;
          const pool = others.concat(opts.weapon && !T.weaponUsed ? [opts.weapon] : []);
          let gain = 0;
          for (const o of pool.slice(0, 3)) {
            const base = dmgCardValue(o, T.buffP, T.buffC, T.dmgPct);
            const withB = dmgCardValue(o, T.buffP + (l.stat === 'puissance' ? l.max : 0), T.buffC + (l.stat === 'critique' ? l.max : 0), T.dmgPct + (l.stat === 'dmgPctSorts' ? l.max : 0));
            gain += withB - base;
          }
          v += gain * 0.9;
        }
        if ((l.k === 'shieldHp' || l.k === 'shieldLvl') && T.invS) { v -= (l.k === 'shieldHp' ? maxHp * l.max / 100 : (opts.level || 200) * l.max / 100); continue; }
        if ((l.k === 'heal' || l.k === 'healPct') && l.tgt === 'self' && T.inv) { v -= (l.k === 'healPct' ? maxHp * l.max / 100 : (l.max + (S.soins || 0))); continue; }
        if (l.k === 'steal' && T.inv) { v -= 0.5 * expLine(S, l, 0, T.buffP, T.dmgPct, 0, 0, false, c.weapon); }
        if ((l.k === 'shieldHp' || l.k === 'shieldLvl') && T.sustainLeft > 0) {
          const amount = l.k === 'shieldHp' ? maxHp * l.max / 100 : (opts.level || 200) * l.max / 100;
          const room = Math.max(0, shieldCap - shieldTotal());
          v += Math.min(amount, room, incomingNext()) * 0.8;
        }
        if ((l.k === 'heal' || l.k === 'healPct') && l.tgt === 'self' && T.sustainLeft > 0 && !c.hasDmg) {
          const amount = l.k === 'healPct' ? maxHp * l.max / 100 : (l.max + (S.soins || 0));
          v += Math.min(amount, maxHp - P.hp) * 0.8;
        }
        if (l.k === 'apRemove' && l.tgt === 'enemy') {
          const t = c.weapon ? null : target();
          if (t) v += incomingNext() / Math.max(1, mons.filter(m => m.alive).length) * (WEAKEN_PER_PA * Math.max(0, l.max)) / 100 * 0.8;
        }
        if (l.k === 'apGain') v += l.max * 60;
      }
      if (c.hasDmg && !c.weapon) {
        // Onde de choc : deux sorts de dégâts du même élément d'affilée te blessent
        const sh = mv('shockPct', 0);
        if (sh && T.lastEl != null && mainEl(c) === T.lastEl) v -= maxHp * sh / 100 * 1.5;
        // Miroir : une zone qui touche le boss qui renvoie te blesse
        const rf = alive().find(reflects);
        if (rf && c.dmgLines.some(l => l.zone)) v -= dmgCardValue(c, T.buffP, T.buffC, T.dmgPct) / Math.max(1, alive().length) * 1.5;
      }
      // Peau dure : sans bouclier, tes dégâts sont réduits ; le bouclier devient prioritaire
      if (shieldTotal() <= 0 && alive().some(m => m.mech && m.mech.hardSkin) && c.eff.some(l => l.k === 'shieldHp' || l.k === 'shieldLvl')) v += 5000;
      return v;
    }
    // estimation du bonus de passif si on joue c maintenant (planification)
    function estPct(m, c) {
      if (!PK) return 0; const sv = C.cur; const w = c.weapon;
      C.cur = { portal: PK === 'eliotrope' && (C.att + 1) % 2 === 0, lance: PK === 'forgelance' && !C.firstDone && !w };
      let v = clsPct(m, c);
      if (PK === 'huppermage' && !w && c.hasDmg && !C.runes.has(mainEl(c)) && C.runes.size < 4) v += 11;
      if (PK === 'ouginak' && !w && m !== C.prey) v = 0;
      C.cur = sv; return v;
    }
    function ecaF(c) { return ECA && !c.weapon && c.hasDmg ? 1.31 : 1; }
    // charges du passif après un sort
    function passiveAfter(c) {
      if (!PK) return; const w = c.weapon;
      const has = k => c.eff.some(l => k.includes(l.k));
      if (PK === 'feca' && !w && (has(['shieldHp', 'shieldLvl', 'heal', 'healPct']) || c.eff.some(l => l.k === 'buff' && /^res/.test(l.stat || '')))) C.n = Math.min(5, C.n + 1);
      else if (PK === 'enutrof' && !w && c.ap <= 2) C.n = Math.min(10, C.n + 1);
      else if (PK === 'xelor') { const n = c.eff.filter(l => l.k === 'apRemove' || l.k === 'apSteal').reduce((a, l) => a + (l.max || 0), 0); C.n = Math.min(10, C.n + n); }
      else if (PK === 'eniripsa' && !w && has(['shieldHp', 'shieldLvl', 'heal', 'healPct'])) C.n = Math.min(5, C.n + 1);
      else if (PK === 'pandawa' && !w) C.n = Math.min(6, C.n + 1);
      else if (PK === 'huppermage' && !w && c.hasDmg) C.runes.add(mainEl(c));
      else if (PK === 'ouginak' && !w && c.hasDmg && C.lastTgt) { if (C.prey !== C.lastTgt) { C.prey = C.lastTgt; C.preyN = 0; } C.preyN = Math.min(5, C.preyN + 1); }
      if (PK === 'forgelance' && !w && c.hasDmg) C.firstDone = true;
      C.cur = null;
    }
    function mainEl(c) { const l = c.dmgLines && c.dmgLines[0]; return l ? (l.el || 0) : null; }
    // Mort d'un monstre ; certains boss se relèvent une fois (« se relève, fou de rage ») avec une part de leurs PV (inconnue : 50 % par défaut)
    function down(m) {
      if (m.mech && m.mech.revive && !m.revived) { m.revived = true; m.hp = Math.max(1, Math.round(m.cap * (m.mech.revivePct != null ? m.mech.revivePct / 100 : opts.revivePct != null ? opts.revivePct : 0.5))); m.rage += m.mech.reviveRage === 0 ? 0 : 2; m.shield = 0; m.bombs = []; return; }
      m.alive = false;
      if (PK === 'ouginak' && m === C.prey && C.inTurn && !C.ougPa) { C.ougPa = true; T.apNow = (T.apNow || 0) + 2; } // Proie tuée pendant son tour : +2 PA
    }
    function hit(m, line, label, opt) {
      opt = opt || {};
      const rp = er(m.res[RES_PCT[line.el || 0]] || 0);
      let d = dmgLine(S, line, opt.crit, T.buffP, T.dmgPct, opt.spec, rp, opt.fixed !== false, opt.weapon, PK ? clsPct(m, opt.card || null, opt.bomb) : 0);
      if (opt.luck) d = Math.floor(d * opt.luck);
      if (opt.sec) d = Math.floor(d * ZONE_SEC);
      if (opt.x2) d *= 2;
      if (m.mech && m.mech.hardSkin && shieldTotal() <= 0) d = Math.floor(d * m.mech.hardSkin / 100);
      if (reflects(m)) {
        // « renvoie le coup » : le monstre ne prend rien et te renvoie les dégâts (tes boucliers absorbent)
        let back = d; for (const s of P.shields) { const a = Math.min(s.value, back); s.value -= a; back -= a; if (!back) break; }
        P.hp -= back; hpLost += back; return 0;
      }
      const absorbed = Math.min(m.shield, Math.floor(d * (1 - (S._perfo || 0) / 100))); m.shield -= absorbed; const real = Math.min(m.hp, d - absorbed);
      if (opts.log) opts.log.push([T.round, label, m.name, d, !!opt.crit, !!opt.sec]);
      if (DF.glaces && real > 0) m.glaces = T.round + 1;
      m.hp -= real; if (S._ero) m.cap = Math.max(1, m.cap - real * S._ero / 100); dmgDone += real; perCard[label] = (perCard[label] || 0) + real;
      if (m.hp <= 0) { m.hp = 0; down(m); }
      return real;
    }
    function play(c) {
      const critP = c.cc > 0 ? Math.min(100, c.cc + (S.critique || 0) + T.buffC) : 0;
      const crit = RND() * 100 < critP;
      if (crit && DF.turquoise) critTurn = true;
      const x2 = !pourpreUsed && c.hasDmg && !c.weapon; if (x2) pourpreUsed = true; // Pourpre : le premier sort de dégâts du combat ×2
      const critArg = crit ? ((c.crit && c.crit.length) ? true : 'boost') : false;
      const lines = crit && c.crit ? c.crit : c.eff;
      if (PK && c.hasDmg) { C.att++; C.cur = { portal: PK === 'eliotrope' && C.att % 2 === 0, lance: PK === 'forgelance' && !C.firstDone && !c.weapon }; } else C.cur = null;
      C.inTurn = true;
      let luck = 1; if (ECA && !c.weapon && c.hasDmg) { const r = RND(); luck = r < 0.32 ? 2 : r < 0.34 ? 0.5 : 1; } // Chance d'Ecaflip
      const spec = !c.weapon && c.hasDmg && RND() < specP;  // Vision spectrale : tout le sort est doublé (toutes cibles et lignes, vérifié dans le journal)
      if (c.hasDmg && !c.weapon) {
        const el = mainEl(c), sh = mv('shockPct', 0);
        if (sh && T.lastEl != null && el === T.lastEl) { let d = Math.floor(maxHp * sh / 100); for (const s2 of P.shields) { const a = Math.min(s2.value, d); s2.value -= a; d -= a; if (!d) break; } P.hp -= d; hpLost += d; }
        T.lastEl = el;
      }
      let first = true; let tgt = target();
      const chosen = c.chanceLines.length ? [c.chanceLines[Math.floor(RND() * c.chanceLines.length)]] : null;
      let sustainUsed = false;
      for (const l of lines) {
        if (chosen && l.chance && l !== chosen[0] && !(crit && c.crit)) continue;
        if (l.k === 'dmg' || l.k === 'steal') {
          const withFixed = c.weapon ? true : first; first = false;
          if (l.zone) { if (!tgt || !tgt.alive) tgt = target(); for (const m of [tgt, ...mons.filter(x => x !== tgt)]) if (m && m.alive) { hit(m, l, c.name, { crit: critArg, spec, fixed: withFixed, weapon: c.weapon, sec: m !== tgt, x2, card: c, luck }); } }
          else {
            if (!tgt || !tgt.alive) tgt = target(); if (!tgt) break;
            const r = hit(tgt, l, c.name, { crit: critArg, spec, fixed: withFixed, weapon: c.weapon, x2, card: c, luck });
            if (l.k === 'steal') healP(Math.floor(r / 2));
          }
        } else if (l.k === 'dmgCasterHp') {
          if (!tgt || !tgt.alive) tgt = target(); if (!tgt) break;
          const d = Math.floor(maxHp * l.max / 100 * (1 - (tgt.res.resPctNeutre || 0) / 100));
          const real = Math.min(tgt.hp, d); tgt.hp -= real; dmgDone += real; perCard[c.name] = (perCard[c.name] || 0) + real; if (tgt.hp <= 0) { tgt.hp = 0; down(tgt); }
        } else if (l.k === 'bomb') {
          if (!tgt || !tgt.alive) tgt = target(); if (tgt) tgt.bombs.push(l);
        } else if (l.k === 'buff' && l.tgt === 'self') {
          if (l.stat === 'puissance') T.buffP += l.max; else if (l.stat === 'critique') T.buffC += l.max; else if (l.stat === 'dmgPctSorts') T.dmgPct += l.max; else if (CARACS_ALL.includes(l.stat)) S._cb[l.stat] = (S._cb[l.stat] || 0) + l.max;
          if ((l.dur || 1) > 1) pers.push({ stat: l.stat, v: l.max, until: T.round + l.dur - 1 });
        } else if (l.k === 'stealStat' && CARACS_ALL.includes(l.stat)) {
          // Vol de caractéristique : la carac volée s'ajoute à la tienne pendant la durée (dès ce tour)
          S._cb[l.stat] = (S._cb[l.stat] || 0) + l.max; if ((l.dur || 1) > 1) pers.push({ stat: l.stat, v: l.max, until: T.round + l.dur - 1 });
        } else if (l.k === 'shieldHp' || l.k === 'shieldLvl') {
          if (T.sustainLeft <= 0 && !sustainUsed) continue;
          sustainUsed = true;
          const amount = Math.floor(l.k === 'shieldHp' ? maxHp * l.max / 100 : (opts.level || 200) * l.max / 100);
          if (T.invS) { P.hp -= amount; hpLost += amount; continue; }
          const room = Math.max(0, shieldCap - shieldTotal());
          P.shields.push({ value: Math.min(amount, room), turns: l.dur || 1 });
        } else if ((l.k === 'heal' || l.k === 'healPct') && l.tgt === 'self') {
          if (!c.hasDmg) { if (T.sustainLeft <= 0 && !sustainUsed) continue; sustainUsed = true; }
          const amount = Math.floor((l.k === 'healPct' ? maxHp * l.max / 100 : (l.max + (S.soins || 0))) * (PK === 'eniripsa' ? 1 + 0.09 * C.n : 1));
          healP(amount);
        } else if (l.k === 'apRemove' && l.tgt === 'enemy') {
          const n = l.max; if (n <= 0) continue;
          if (l.zone || !c.weapon) { for (const m of mons) if (m.alive && (l.zone || m === tgt || !tgt)) m.weaken = Math.min(100, m.weaken + WEAKEN_PER_PA * n); }
          else if (tgt) tgt.weaken = Math.min(100, tgt.weaken + WEAKEN_PER_PA * n);
        } else if (l.k === 'apGain') { if (l.now) T.apNow = (T.apNow || 0) + l.max; else P.apNext += l.max; }
      }
      if (sustainUsed) T.sustainLeft--;
      if (PK && c.hasDmg && !c.weapon) { const t0 = tgt && tgt.alive ? tgt : null; C.lastTgt = tgt || null;
        if (PK === 'sadida' && t0) { t0.poison = t0.poison || []; if (t0.poison.length < 4) t0.poison.push(3); else { t0.poison.sort((a, b) => a - b); t0.poison[0] = 3; } } }
      C.inTurn = false;
    }
  }

  // Tirages : aléatoires par défaut ; avec une graine, chaque combat i rejoue les mêmes tirages d'un build à l'autre
  // (nombres aléatoires communs : les écarts mesurés entre deux builds viennent du build, pas de la chance)
  let RND = Math.random;
  function mulberry32(a) { return function () { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
  function shuffle(a) { for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(RND() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; }

  function runMany(opts, n) {
    let wins = 0, rounds = 0, hp = 0, dmg = 0, prog = 0, kills = 0; const per = {}; const hist = {};
    const seeded = opts.seed != null;
    for (let i = 0; i < n; i++) {
      if (seeded) RND = mulberry32(opts.seed * 1000003 + i);
      let r; try { r = simulateFight(opts); } finally { if (seeded) RND = Math.random; }
      if (r.win) { wins++; rounds += r.rounds; hist[r.rounds] = (hist[r.rounds] || 0) + 1; }
      hp += r.hpLost; dmg += r.dmgDone; prog += r.progress || 0; kills += r.kills || 0;
      for (const k in r.perCard) per[k] = (per[k] || 0) + r.perCard[k];
    }
    for (const k in per) per[k] = per[k] / n;
    return { n, winRate: wins / n, avgRounds: wins ? rounds / wins : Infinity, avgHpLost: hp / n, avgDmg: dmg / n, perCard: per, hist, progress: prog / n, avgKills: kills / n };
  }


  // ---------- Mécaniques cachées du bestiaire ----------
  // Une entrée : {mn, d:'F'|'N'|'D'|'C'|combinaisons, asc:[a,b], ch, beyond, zone, second, + un code (fu, pd, oc, ms, sc, ds, mi, pa, ra, vp, ev)}
  function diffForFloor(fl) { return fl <= 2 ? 'F' : fl <= 5 ? 'N' : fl <= 8 ? 'D' : 'C'; }
  function bestiaryEntries(card, ctx) {
    if (!card || !card.m) return [];
    ctx = ctx || {};
    if (ctx.floor) {
      const d = diffForFloor(ctx.floor);
      const asc = card.m.filter(e => e.asc && ctx.floor >= e.asc[0] && ctx.floor <= e.asc[1]);
      if (asc.length) return asc;
      return card.m.filter(e => !e.asc && String(e.d).includes(d));
    }
    if (ctx.diff) return card.m.filter(e => String(e.d).includes(ctx.diff) && (!ctx.second || true));
    return card.m;
  }
  function mechFromEntries(list) {
    const o = {};
    for (const e of list || []) {
      if (e.fu) { o.furyCards = e.fu[0]; o.furyMult = e.fu[1]; }
      if (e.pd) o.hardSkin = e.pd;
      if (e.oc) o.shockPct = e.oc;
      if (e.ms) { if (e.ms[1] === 'half') o.healHalfFrom = e.ms[0]; else o.invertFrom = e.ms[0]; }
      if (e.sc) o.sealEvery = e.sc;
      if (e.ds) { o.revive = true; o.revivePct = e.ds[0]; o.reviveRage = e.ds[1] ? 1 : 0; }
      if (e.mi) { o.reflectFrom = e.mi[0]; o.reflectTo = e.mi[1]; }
      if (e.pa) { o.paTurn = e.pa[0]; o.paLeft = e.pa[1]; }
      if (e.ra) o.rageTurn = e.ra;
      if (e.vp) { o.apStealEvery = e.vp; o.apSteal = 1; }
      if (e.ev) { o.swapTurn = e.ev[0]; o.swapHalf = !!e.ev[1]; }
    }
    return o;
  }
  function mechText(e) {
    const t = [];
    if (e.fu) t.push(`Fureur : plus de ${e.fu[0]} cartes dans le tour (arme exclue) → sa prochaine attaque ×${String(e.fu[1]).replace('.', ',')}`);
    if (e.pd) t.push(`Peau dure : sans bouclier sur toi, seuls ${e.pd} % de tes dégâts passent`);
    if (e.oc) t.push(`Onde de choc : deux sorts de dégâts du même élément d'affilée → ${e.oc} % de tes PV max`);
    if (e.ms) t.push(e.ms[1] === 'half' ? `Malédiction : soins divisés par deux dès le tour ${e.ms[0]}` : `Malédiction : tes soins te blessent dès le tour ${e.ms[0]}`);
    if (e.sc) t.push(`Sceau : ${e.sc === 1 ? 'à chaque tour' : 'tous les ' + e.sc + ' tours'}, ta carte la plus chère est scellée`);
    if (e.ds) t.push(`Deuxième souffle : se relève avec ${e.ds[0]} % de PV${e.ds[1] ? ', fou de rage' : ''}`);
    if (e.mi) t.push(`Miroir : ${e.mi[0] === e.mi[1] ? 'au tour ' + e.mi[0] : 'aux tours ' + e.mi[0] + ' à ' + e.mi[1]}, chaque coup porté t'est renvoyé`);
    if (e.pa) t.push(`PA comptés : au tour ${e.pa[0]}, finis avec exactement ${e.pa[1]} PA`);
    if (e.ra) t.push(`Rage : au tour ${e.ra}, il t'achève`);
    if (e.vp) t.push(`Vol de PA : ${e.vp === 1 ? 'à chaque tour' : 'tous les ' + e.vp + ' tours'}, −1 PA`);
    if (e.ev) t.push(`Échange de vie au tour ${e.ev[0]}${e.ev[1] ? ' (à moitié)' : ''} s'il est plus entamé que toi`);
    return t.join(' · ');
  }
  // Ce que le mode auto ne sait pas gérer (le jeu à la main est alors conseillé)
  function autoWarnings(mech) {
    const w = [];
    if (mech.furyCards) w.push(`l'auto joue toutes ses cartes : la Fureur (> ${mech.furyCards} cartes) se déclenche à chaque tour`);
    if (mech.reflectFrom) w.push(`l'auto continue de frapper pendant le Miroir (tour${mech.reflectTo && mech.reflectTo !== mech.reflectFrom ? 's ' + mech.reflectFrom + '-' + mech.reflectTo : ' ' + mech.reflectFrom})`);
    if (mech.paTurn) w.push(`l'auto ne compte pas ses PA au tour ${mech.paTurn}`);
    if (mech.shockPct) w.push(`l'auto n'alterne pas les éléments (Onde de choc)`);
    return w;
  }
  const api = { BREED_KEY, BREED_NAME, CLASS_SPECTRAL, deriveStats, setAutoOrder: v => { AUTO_ORDER = v; }, setTuning: o => { if (o.crit != null) CRIT_MULT = o.crit; if (o.zoneSec != null) ZONE_SEC = o.zoneSec; if (o.weaponLast != null) WEAPON_LAST = o.weaponLast; if (o.weaponMode) WEAPON_MODE = o.weaponMode; }, CLASS_PASSIVE, dofusFx, forgePctFor, forgeDaysTo, forgeXpAt, diffForFloor, bestiaryEntries, mechFromEntries, mechText, autoWarnings, itemStats, weaponWithFusion, tierCost, allocCost, pointsTotal, computeStats, prepCard, weaponCard, simulateFight, runMany, STAT_TIERS, CARAC_OF_EL, EL_NAMES, RES_PCT, RES_FIX };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.RPG = api;
})(typeof self !== 'undefined' ? self : this);
