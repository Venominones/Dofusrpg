# Labo RpgMasters — mise en ligne (GitHub Pages)

## Fichiers à déposer dans le dépôt
- `index.html` : le Labo
- `labo-rpgmasters.user.js` : le script, pour qu'il se mette à jour tout seul dans Tampermonkey
- `.nojekyll` : déjà présent dans ton dépôt (sinon, crée-le vide)

## Mise à jour automatique du script (une seule fois)
1. Dépose `labo-rpgmasters.user.js` dans le dépôt (**Add file → Upload files** → **Commit changes**).
2. Ouvre `https://venominones.github.io/Dofusrpg/labo-rpgmasters.user.js` (ou le bouton « Installer / mettre à jour le script » dans l'onglet Mes données du Labo en ligne) → Tampermonkey propose l'installation → **Mettre à jour**.
3. C'est tout : Tampermonkey vérifie ensuite tout seul (environ une fois par jour) et installe les nouvelles versions déposées dans le dépôt. Pour forcer : tableau de bord Tampermonkey → *Rechercher des mises à jour*.

## À chaque nouvelle version que je t'envoie
Dépose les fichiers reçus (`index.html`, `labo-rpgmasters.user.js`) dans le dépôt → **Commit changes**. Le Labo en ligne et le script se mettent à jour, tes données restent dans ton navigateur.

## Utilisation
Dans le jeu : **Envoyer au Labo ↗** (adresse réglée avec ⚙ : `https://venominones.github.io/Dofusrpg/`).

## À savoir
- Le Labo en ligne est la version publique : un personnage d'exemple (équipement porté et deck), sans ton inventaire, tes combats ni ton historique. Tes propres données arrivent par « Envoyer au Labo » et restent dans ton navigateur.
- Le Labo n'accepte les données envoyées que depuis rpgmasters.houk.fr.
